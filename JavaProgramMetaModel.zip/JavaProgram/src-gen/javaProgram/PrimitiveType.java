/**
 */
package javaProgram;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see javaProgram.JavaProgramPackage#getPrimitiveType()
 * @model
 * @generated
 */
public interface PrimitiveType extends Type {
} // PrimitiveType
