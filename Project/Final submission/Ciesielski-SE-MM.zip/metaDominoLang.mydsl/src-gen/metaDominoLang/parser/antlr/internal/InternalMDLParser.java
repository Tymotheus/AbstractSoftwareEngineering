package metaDominoLang.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import metaDominoLang.services.MDLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMDLParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'dominiongame'", "'card_libraries'", "'{'", "','", "'}'", "'Strategy'", "':'", "'DominionGame'", "'playersplayarea'", "'players_turns'", "'avaialble_abilities'", "'trashpile'", "'supply_piles'", "'CardLibrary'", "'card'", "'abilities'", "'Action'", "'phase'", "'Buy'", "'PlayersPlayArea'", "'playersName'", "'actionsLeft'", "'buysLeft'", "'cards_played_this_turn'", "'players_deck'", "'players_hand'", "'discard_pile'", "'PlayersTurn'", "'turnNumber'", "'player'", "'action_phase'", "'buyphase'", "'cleanupphase'", "'TrashPile'", "'cards'", "'SupplyPile'", "'cardsNumber'", "'CardsPlayedThisTurn'", "'PlayersDeck'", "'PlayersHand'", "'DiscardPile'", "'-'", "'isPubliclyVisible'", "'isVisibleToOwner'", "'TreasureCard'", "'cost'", "'value'", "'VictoryCard'", "'victoryPoints'", "'ActionCard'", "'ability'", "'('", "')'", "'CleanupPhase'", "'put_cards_from_hand_to_discard'", "'buy'", "'play'", "'If'", "'While'", "'you'", "'have'", "'coins'", "'PutCardFromHandToDiscard'", "'PutCardInTrash'", "'DrawCards'", "'cardNumber'", "'PutCardFromPileToDiscard'", "'ExtraBuys'", "'buyNumber'", "'ExtraCoins'", "'coinNumber'", "'ExtraActions'", "'actionNumber'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__59=59;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__58=58;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__60=60;
    public static final int T__61=61;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int T__66=66;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__67=67;
    public static final int T__24=24;
    public static final int T__68=68;
    public static final int T__25=25;
    public static final int T__69=69;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int T__20=20;
    public static final int T__64=64;
    public static final int T__21=21;
    public static final int T__65=65;
    public static final int T__70=70;
    public static final int T__71=71;
    public static final int T__72=72;
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__77=77;
    public static final int T__34=34;
    public static final int T__78=78;
    public static final int T__35=35;
    public static final int T__79=79;
    public static final int T__36=36;
    public static final int T__73=73;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__74=74;
    public static final int T__31=31;
    public static final int T__75=75;
    public static final int T__32=32;
    public static final int T__76=76;
    public static final int T__80=80;
    public static final int T__81=81;
    public static final int T__82=82;
    public static final int T__83=83;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalMDLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMDLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMDLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMDL.g"; }



     	private MDLGrammarAccess grammarAccess;

        public InternalMDLParser(TokenStream input, MDLGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "DominionProgram";
       	}

       	@Override
       	protected MDLGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleDominionProgram"
    // InternalMDL.g:64:1: entryRuleDominionProgram returns [EObject current=null] : iv_ruleDominionProgram= ruleDominionProgram EOF ;
    public final EObject entryRuleDominionProgram() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDominionProgram = null;


        try {
            // InternalMDL.g:64:56: (iv_ruleDominionProgram= ruleDominionProgram EOF )
            // InternalMDL.g:65:2: iv_ruleDominionProgram= ruleDominionProgram EOF
            {
             newCompositeNode(grammarAccess.getDominionProgramRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDominionProgram=ruleDominionProgram();

            state._fsp--;

             current =iv_ruleDominionProgram; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDominionProgram"


    // $ANTLR start "ruleDominionProgram"
    // InternalMDL.g:71:1: ruleDominionProgram returns [EObject current=null] : ( () (otherlv_1= 'dominiongame' ( (lv_dominiongame_2_0= ruleDominionGame ) ) )? (otherlv_3= 'card_libraries' otherlv_4= '{' ( (lv_card_libraries_5_0= ruleCardLibrary ) ) (otherlv_6= ',' ( (lv_card_libraries_7_0= ruleCardLibrary ) ) )* otherlv_8= '}' )? (otherlv_9= 'Strategy' otherlv_10= ':' ( (lv_strategies_11_0= ruleStrategy ) ) (otherlv_12= ',' ( (lv_strategies_13_0= ruleStrategy ) ) )* )? ) ;
    public final EObject ruleDominionProgram() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        EObject lv_dominiongame_2_0 = null;

        EObject lv_card_libraries_5_0 = null;

        EObject lv_card_libraries_7_0 = null;

        EObject lv_strategies_11_0 = null;

        EObject lv_strategies_13_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:77:2: ( ( () (otherlv_1= 'dominiongame' ( (lv_dominiongame_2_0= ruleDominionGame ) ) )? (otherlv_3= 'card_libraries' otherlv_4= '{' ( (lv_card_libraries_5_0= ruleCardLibrary ) ) (otherlv_6= ',' ( (lv_card_libraries_7_0= ruleCardLibrary ) ) )* otherlv_8= '}' )? (otherlv_9= 'Strategy' otherlv_10= ':' ( (lv_strategies_11_0= ruleStrategy ) ) (otherlv_12= ',' ( (lv_strategies_13_0= ruleStrategy ) ) )* )? ) )
            // InternalMDL.g:78:2: ( () (otherlv_1= 'dominiongame' ( (lv_dominiongame_2_0= ruleDominionGame ) ) )? (otherlv_3= 'card_libraries' otherlv_4= '{' ( (lv_card_libraries_5_0= ruleCardLibrary ) ) (otherlv_6= ',' ( (lv_card_libraries_7_0= ruleCardLibrary ) ) )* otherlv_8= '}' )? (otherlv_9= 'Strategy' otherlv_10= ':' ( (lv_strategies_11_0= ruleStrategy ) ) (otherlv_12= ',' ( (lv_strategies_13_0= ruleStrategy ) ) )* )? )
            {
            // InternalMDL.g:78:2: ( () (otherlv_1= 'dominiongame' ( (lv_dominiongame_2_0= ruleDominionGame ) ) )? (otherlv_3= 'card_libraries' otherlv_4= '{' ( (lv_card_libraries_5_0= ruleCardLibrary ) ) (otherlv_6= ',' ( (lv_card_libraries_7_0= ruleCardLibrary ) ) )* otherlv_8= '}' )? (otherlv_9= 'Strategy' otherlv_10= ':' ( (lv_strategies_11_0= ruleStrategy ) ) (otherlv_12= ',' ( (lv_strategies_13_0= ruleStrategy ) ) )* )? )
            // InternalMDL.g:79:3: () (otherlv_1= 'dominiongame' ( (lv_dominiongame_2_0= ruleDominionGame ) ) )? (otherlv_3= 'card_libraries' otherlv_4= '{' ( (lv_card_libraries_5_0= ruleCardLibrary ) ) (otherlv_6= ',' ( (lv_card_libraries_7_0= ruleCardLibrary ) ) )* otherlv_8= '}' )? (otherlv_9= 'Strategy' otherlv_10= ':' ( (lv_strategies_11_0= ruleStrategy ) ) (otherlv_12= ',' ( (lv_strategies_13_0= ruleStrategy ) ) )* )?
            {
            // InternalMDL.g:79:3: ()
            // InternalMDL.g:80:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getDominionProgramAccess().getDominionProgramAction_0(),
            					current);
            			

            }

            // InternalMDL.g:86:3: (otherlv_1= 'dominiongame' ( (lv_dominiongame_2_0= ruleDominionGame ) ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==11) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalMDL.g:87:4: otherlv_1= 'dominiongame' ( (lv_dominiongame_2_0= ruleDominionGame ) )
                    {
                    otherlv_1=(Token)match(input,11,FOLLOW_3); 

                    				newLeafNode(otherlv_1, grammarAccess.getDominionProgramAccess().getDominiongameKeyword_1_0());
                    			
                    // InternalMDL.g:91:4: ( (lv_dominiongame_2_0= ruleDominionGame ) )
                    // InternalMDL.g:92:5: (lv_dominiongame_2_0= ruleDominionGame )
                    {
                    // InternalMDL.g:92:5: (lv_dominiongame_2_0= ruleDominionGame )
                    // InternalMDL.g:93:6: lv_dominiongame_2_0= ruleDominionGame
                    {

                    						newCompositeNode(grammarAccess.getDominionProgramAccess().getDominiongameDominionGameParserRuleCall_1_1_0());
                    					
                    pushFollow(FOLLOW_4);
                    lv_dominiongame_2_0=ruleDominionGame();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDominionProgramRule());
                    						}
                    						set(
                    							current,
                    							"dominiongame",
                    							lv_dominiongame_2_0,
                    							"metaDominoLang.MDL.DominionGame");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMDL.g:111:3: (otherlv_3= 'card_libraries' otherlv_4= '{' ( (lv_card_libraries_5_0= ruleCardLibrary ) ) (otherlv_6= ',' ( (lv_card_libraries_7_0= ruleCardLibrary ) ) )* otherlv_8= '}' )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==12) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalMDL.g:112:4: otherlv_3= 'card_libraries' otherlv_4= '{' ( (lv_card_libraries_5_0= ruleCardLibrary ) ) (otherlv_6= ',' ( (lv_card_libraries_7_0= ruleCardLibrary ) ) )* otherlv_8= '}'
                    {
                    otherlv_3=(Token)match(input,12,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getDominionProgramAccess().getCard_librariesKeyword_2_0());
                    			
                    otherlv_4=(Token)match(input,13,FOLLOW_6); 

                    				newLeafNode(otherlv_4, grammarAccess.getDominionProgramAccess().getLeftCurlyBracketKeyword_2_1());
                    			
                    // InternalMDL.g:120:4: ( (lv_card_libraries_5_0= ruleCardLibrary ) )
                    // InternalMDL.g:121:5: (lv_card_libraries_5_0= ruleCardLibrary )
                    {
                    // InternalMDL.g:121:5: (lv_card_libraries_5_0= ruleCardLibrary )
                    // InternalMDL.g:122:6: lv_card_libraries_5_0= ruleCardLibrary
                    {

                    						newCompositeNode(grammarAccess.getDominionProgramAccess().getCard_librariesCardLibraryParserRuleCall_2_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_card_libraries_5_0=ruleCardLibrary();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDominionProgramRule());
                    						}
                    						add(
                    							current,
                    							"card_libraries",
                    							lv_card_libraries_5_0,
                    							"metaDominoLang.MDL.CardLibrary");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:139:4: (otherlv_6= ',' ( (lv_card_libraries_7_0= ruleCardLibrary ) ) )*
                    loop2:
                    do {
                        int alt2=2;
                        int LA2_0 = input.LA(1);

                        if ( (LA2_0==14) ) {
                            alt2=1;
                        }


                        switch (alt2) {
                    	case 1 :
                    	    // InternalMDL.g:140:5: otherlv_6= ',' ( (lv_card_libraries_7_0= ruleCardLibrary ) )
                    	    {
                    	    otherlv_6=(Token)match(input,14,FOLLOW_6); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getDominionProgramAccess().getCommaKeyword_2_3_0());
                    	    				
                    	    // InternalMDL.g:144:5: ( (lv_card_libraries_7_0= ruleCardLibrary ) )
                    	    // InternalMDL.g:145:6: (lv_card_libraries_7_0= ruleCardLibrary )
                    	    {
                    	    // InternalMDL.g:145:6: (lv_card_libraries_7_0= ruleCardLibrary )
                    	    // InternalMDL.g:146:7: lv_card_libraries_7_0= ruleCardLibrary
                    	    {

                    	    							newCompositeNode(grammarAccess.getDominionProgramAccess().getCard_librariesCardLibraryParserRuleCall_2_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_card_libraries_7_0=ruleCardLibrary();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getDominionProgramRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"card_libraries",
                    	    								lv_card_libraries_7_0,
                    	    								"metaDominoLang.MDL.CardLibrary");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop2;
                        }
                    } while (true);

                    otherlv_8=(Token)match(input,15,FOLLOW_8); 

                    				newLeafNode(otherlv_8, grammarAccess.getDominionProgramAccess().getRightCurlyBracketKeyword_2_4());
                    			

                    }
                    break;

            }

            // InternalMDL.g:169:3: (otherlv_9= 'Strategy' otherlv_10= ':' ( (lv_strategies_11_0= ruleStrategy ) ) (otherlv_12= ',' ( (lv_strategies_13_0= ruleStrategy ) ) )* )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==16) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // InternalMDL.g:170:4: otherlv_9= 'Strategy' otherlv_10= ':' ( (lv_strategies_11_0= ruleStrategy ) ) (otherlv_12= ',' ( (lv_strategies_13_0= ruleStrategy ) ) )*
                    {
                    otherlv_9=(Token)match(input,16,FOLLOW_9); 

                    				newLeafNode(otherlv_9, grammarAccess.getDominionProgramAccess().getStrategyKeyword_3_0());
                    			
                    otherlv_10=(Token)match(input,17,FOLLOW_10); 

                    				newLeafNode(otherlv_10, grammarAccess.getDominionProgramAccess().getColonKeyword_3_1());
                    			
                    // InternalMDL.g:178:4: ( (lv_strategies_11_0= ruleStrategy ) )
                    // InternalMDL.g:179:5: (lv_strategies_11_0= ruleStrategy )
                    {
                    // InternalMDL.g:179:5: (lv_strategies_11_0= ruleStrategy )
                    // InternalMDL.g:180:6: lv_strategies_11_0= ruleStrategy
                    {

                    						newCompositeNode(grammarAccess.getDominionProgramAccess().getStrategiesStrategyParserRuleCall_3_2_0());
                    					
                    pushFollow(FOLLOW_11);
                    lv_strategies_11_0=ruleStrategy();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDominionProgramRule());
                    						}
                    						add(
                    							current,
                    							"strategies",
                    							lv_strategies_11_0,
                    							"metaDominoLang.MDL.Strategy");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:197:4: (otherlv_12= ',' ( (lv_strategies_13_0= ruleStrategy ) ) )*
                    loop4:
                    do {
                        int alt4=2;
                        int LA4_0 = input.LA(1);

                        if ( (LA4_0==14) ) {
                            alt4=1;
                        }


                        switch (alt4) {
                    	case 1 :
                    	    // InternalMDL.g:198:5: otherlv_12= ',' ( (lv_strategies_13_0= ruleStrategy ) )
                    	    {
                    	    otherlv_12=(Token)match(input,14,FOLLOW_10); 

                    	    					newLeafNode(otherlv_12, grammarAccess.getDominionProgramAccess().getCommaKeyword_3_3_0());
                    	    				
                    	    // InternalMDL.g:202:5: ( (lv_strategies_13_0= ruleStrategy ) )
                    	    // InternalMDL.g:203:6: (lv_strategies_13_0= ruleStrategy )
                    	    {
                    	    // InternalMDL.g:203:6: (lv_strategies_13_0= ruleStrategy )
                    	    // InternalMDL.g:204:7: lv_strategies_13_0= ruleStrategy
                    	    {

                    	    							newCompositeNode(grammarAccess.getDominionProgramAccess().getStrategiesStrategyParserRuleCall_3_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_11);
                    	    lv_strategies_13_0=ruleStrategy();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getDominionProgramRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"strategies",
                    	    								lv_strategies_13_0,
                    	    								"metaDominoLang.MDL.Strategy");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop4;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDominionProgram"


    // $ANTLR start "entryRuleAbility"
    // InternalMDL.g:227:1: entryRuleAbility returns [EObject current=null] : iv_ruleAbility= ruleAbility EOF ;
    public final EObject entryRuleAbility() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAbility = null;


        try {
            // InternalMDL.g:227:48: (iv_ruleAbility= ruleAbility EOF )
            // InternalMDL.g:228:2: iv_ruleAbility= ruleAbility EOF
            {
             newCompositeNode(grammarAccess.getAbilityRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAbility=ruleAbility();

            state._fsp--;

             current =iv_ruleAbility; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAbility"


    // $ANTLR start "ruleAbility"
    // InternalMDL.g:234:1: ruleAbility returns [EObject current=null] : (this_PutCardInTrash_0= rulePutCardInTrash | this_DrawCards_1= ruleDrawCards | this_PutCardFromPileToDiscard_2= rulePutCardFromPileToDiscard | this_ExtraBuys_3= ruleExtraBuys | this_ExtraCoins_4= ruleExtraCoins | this_ExtraActions_5= ruleExtraActions | this_PutCardFromHandToDiscard_6= rulePutCardFromHandToDiscard ) ;
    public final EObject ruleAbility() throws RecognitionException {
        EObject current = null;

        EObject this_PutCardInTrash_0 = null;

        EObject this_DrawCards_1 = null;

        EObject this_PutCardFromPileToDiscard_2 = null;

        EObject this_ExtraBuys_3 = null;

        EObject this_ExtraCoins_4 = null;

        EObject this_ExtraActions_5 = null;

        EObject this_PutCardFromHandToDiscard_6 = null;



        	enterRule();

        try {
            // InternalMDL.g:240:2: ( (this_PutCardInTrash_0= rulePutCardInTrash | this_DrawCards_1= ruleDrawCards | this_PutCardFromPileToDiscard_2= rulePutCardFromPileToDiscard | this_ExtraBuys_3= ruleExtraBuys | this_ExtraCoins_4= ruleExtraCoins | this_ExtraActions_5= ruleExtraActions | this_PutCardFromHandToDiscard_6= rulePutCardFromHandToDiscard ) )
            // InternalMDL.g:241:2: (this_PutCardInTrash_0= rulePutCardInTrash | this_DrawCards_1= ruleDrawCards | this_PutCardFromPileToDiscard_2= rulePutCardFromPileToDiscard | this_ExtraBuys_3= ruleExtraBuys | this_ExtraCoins_4= ruleExtraCoins | this_ExtraActions_5= ruleExtraActions | this_PutCardFromHandToDiscard_6= rulePutCardFromHandToDiscard )
            {
            // InternalMDL.g:241:2: (this_PutCardInTrash_0= rulePutCardInTrash | this_DrawCards_1= ruleDrawCards | this_PutCardFromPileToDiscard_2= rulePutCardFromPileToDiscard | this_ExtraBuys_3= ruleExtraBuys | this_ExtraCoins_4= ruleExtraCoins | this_ExtraActions_5= ruleExtraActions | this_PutCardFromHandToDiscard_6= rulePutCardFromHandToDiscard )
            int alt6=7;
            alt6 = dfa6.predict(input);
            switch (alt6) {
                case 1 :
                    // InternalMDL.g:242:3: this_PutCardInTrash_0= rulePutCardInTrash
                    {

                    			newCompositeNode(grammarAccess.getAbilityAccess().getPutCardInTrashParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_PutCardInTrash_0=rulePutCardInTrash();

                    state._fsp--;


                    			current = this_PutCardInTrash_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMDL.g:251:3: this_DrawCards_1= ruleDrawCards
                    {

                    			newCompositeNode(grammarAccess.getAbilityAccess().getDrawCardsParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_DrawCards_1=ruleDrawCards();

                    state._fsp--;


                    			current = this_DrawCards_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalMDL.g:260:3: this_PutCardFromPileToDiscard_2= rulePutCardFromPileToDiscard
                    {

                    			newCompositeNode(grammarAccess.getAbilityAccess().getPutCardFromPileToDiscardParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_PutCardFromPileToDiscard_2=rulePutCardFromPileToDiscard();

                    state._fsp--;


                    			current = this_PutCardFromPileToDiscard_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalMDL.g:269:3: this_ExtraBuys_3= ruleExtraBuys
                    {

                    			newCompositeNode(grammarAccess.getAbilityAccess().getExtraBuysParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_ExtraBuys_3=ruleExtraBuys();

                    state._fsp--;


                    			current = this_ExtraBuys_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalMDL.g:278:3: this_ExtraCoins_4= ruleExtraCoins
                    {

                    			newCompositeNode(grammarAccess.getAbilityAccess().getExtraCoinsParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_ExtraCoins_4=ruleExtraCoins();

                    state._fsp--;


                    			current = this_ExtraCoins_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalMDL.g:287:3: this_ExtraActions_5= ruleExtraActions
                    {

                    			newCompositeNode(grammarAccess.getAbilityAccess().getExtraActionsParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_ExtraActions_5=ruleExtraActions();

                    state._fsp--;


                    			current = this_ExtraActions_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 7 :
                    // InternalMDL.g:296:3: this_PutCardFromHandToDiscard_6= rulePutCardFromHandToDiscard
                    {

                    			newCompositeNode(grammarAccess.getAbilityAccess().getPutCardFromHandToDiscardParserRuleCall_6());
                    		
                    pushFollow(FOLLOW_2);
                    this_PutCardFromHandToDiscard_6=rulePutCardFromHandToDiscard();

                    state._fsp--;


                    			current = this_PutCardFromHandToDiscard_6;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAbility"


    // $ANTLR start "entryRuleCard"
    // InternalMDL.g:308:1: entryRuleCard returns [EObject current=null] : iv_ruleCard= ruleCard EOF ;
    public final EObject entryRuleCard() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCard = null;


        try {
            // InternalMDL.g:308:45: (iv_ruleCard= ruleCard EOF )
            // InternalMDL.g:309:2: iv_ruleCard= ruleCard EOF
            {
             newCompositeNode(grammarAccess.getCardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCard=ruleCard();

            state._fsp--;

             current =iv_ruleCard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCard"


    // $ANTLR start "ruleCard"
    // InternalMDL.g:315:1: ruleCard returns [EObject current=null] : (this_TreasureCard_0= ruleTreasureCard | this_VictoryCard_1= ruleVictoryCard | this_ActionCard_2= ruleActionCard ) ;
    public final EObject ruleCard() throws RecognitionException {
        EObject current = null;

        EObject this_TreasureCard_0 = null;

        EObject this_VictoryCard_1 = null;

        EObject this_ActionCard_2 = null;



        	enterRule();

        try {
            // InternalMDL.g:321:2: ( (this_TreasureCard_0= ruleTreasureCard | this_VictoryCard_1= ruleVictoryCard | this_ActionCard_2= ruleActionCard ) )
            // InternalMDL.g:322:2: (this_TreasureCard_0= ruleTreasureCard | this_VictoryCard_1= ruleVictoryCard | this_ActionCard_2= ruleActionCard )
            {
            // InternalMDL.g:322:2: (this_TreasureCard_0= ruleTreasureCard | this_VictoryCard_1= ruleVictoryCard | this_ActionCard_2= ruleActionCard )
            int alt7=3;
            switch ( input.LA(1) ) {
            case 53:
                {
                switch ( input.LA(2) ) {
                case 54:
                    {
                    switch ( input.LA(3) ) {
                    case 55:
                        {
                        alt7=1;
                        }
                        break;
                    case 58:
                        {
                        alt7=2;
                        }
                        break;
                    case 60:
                        {
                        alt7=3;
                        }
                        break;
                    default:
                        NoViableAltException nvae =
                            new NoViableAltException("", 7, 2, input);

                        throw nvae;
                    }

                    }
                    break;
                case 60:
                    {
                    alt7=3;
                    }
                    break;
                case 55:
                    {
                    alt7=1;
                    }
                    break;
                case 58:
                    {
                    alt7=2;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 7, 1, input);

                    throw nvae;
                }

                }
                break;
            case 54:
                {
                switch ( input.LA(2) ) {
                case 55:
                    {
                    alt7=1;
                    }
                    break;
                case 58:
                    {
                    alt7=2;
                    }
                    break;
                case 60:
                    {
                    alt7=3;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 7, 2, input);

                    throw nvae;
                }

                }
                break;
            case 55:
                {
                alt7=1;
                }
                break;
            case 58:
                {
                alt7=2;
                }
                break;
            case 60:
                {
                alt7=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // InternalMDL.g:323:3: this_TreasureCard_0= ruleTreasureCard
                    {

                    			newCompositeNode(grammarAccess.getCardAccess().getTreasureCardParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_TreasureCard_0=ruleTreasureCard();

                    state._fsp--;


                    			current = this_TreasureCard_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMDL.g:332:3: this_VictoryCard_1= ruleVictoryCard
                    {

                    			newCompositeNode(grammarAccess.getCardAccess().getVictoryCardParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_VictoryCard_1=ruleVictoryCard();

                    state._fsp--;


                    			current = this_VictoryCard_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalMDL.g:341:3: this_ActionCard_2= ruleActionCard
                    {

                    			newCompositeNode(grammarAccess.getCardAccess().getActionCardParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_ActionCard_2=ruleActionCard();

                    state._fsp--;


                    			current = this_ActionCard_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCard"


    // $ANTLR start "entryRulePlayersAction"
    // InternalMDL.g:353:1: entryRulePlayersAction returns [EObject current=null] : iv_rulePlayersAction= rulePlayersAction EOF ;
    public final EObject entryRulePlayersAction() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePlayersAction = null;


        try {
            // InternalMDL.g:353:54: (iv_rulePlayersAction= rulePlayersAction EOF )
            // InternalMDL.g:354:2: iv_rulePlayersAction= rulePlayersAction EOF
            {
             newCompositeNode(grammarAccess.getPlayersActionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePlayersAction=rulePlayersAction();

            state._fsp--;

             current =iv_rulePlayersAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePlayersAction"


    // $ANTLR start "rulePlayersAction"
    // InternalMDL.g:360:1: rulePlayersAction returns [EObject current=null] : (this_BuyCard_0= ruleBuyCard | this_PlayAction_1= rulePlayAction | this_IfAction_2= ruleIfAction | this_WhileAction_3= ruleWhileAction ) ;
    public final EObject rulePlayersAction() throws RecognitionException {
        EObject current = null;

        EObject this_BuyCard_0 = null;

        EObject this_PlayAction_1 = null;

        EObject this_IfAction_2 = null;

        EObject this_WhileAction_3 = null;



        	enterRule();

        try {
            // InternalMDL.g:366:2: ( (this_BuyCard_0= ruleBuyCard | this_PlayAction_1= rulePlayAction | this_IfAction_2= ruleIfAction | this_WhileAction_3= ruleWhileAction ) )
            // InternalMDL.g:367:2: (this_BuyCard_0= ruleBuyCard | this_PlayAction_1= rulePlayAction | this_IfAction_2= ruleIfAction | this_WhileAction_3= ruleWhileAction )
            {
            // InternalMDL.g:367:2: (this_BuyCard_0= ruleBuyCard | this_PlayAction_1= rulePlayAction | this_IfAction_2= ruleIfAction | this_WhileAction_3= ruleWhileAction )
            int alt8=4;
            switch ( input.LA(1) ) {
            case 66:
                {
                alt8=1;
                }
                break;
            case 67:
                {
                alt8=2;
                }
                break;
            case 68:
                {
                alt8=3;
                }
                break;
            case 69:
                {
                alt8=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }

            switch (alt8) {
                case 1 :
                    // InternalMDL.g:368:3: this_BuyCard_0= ruleBuyCard
                    {

                    			newCompositeNode(grammarAccess.getPlayersActionAccess().getBuyCardParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_BuyCard_0=ruleBuyCard();

                    state._fsp--;


                    			current = this_BuyCard_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMDL.g:377:3: this_PlayAction_1= rulePlayAction
                    {

                    			newCompositeNode(grammarAccess.getPlayersActionAccess().getPlayActionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_PlayAction_1=rulePlayAction();

                    state._fsp--;


                    			current = this_PlayAction_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalMDL.g:386:3: this_IfAction_2= ruleIfAction
                    {

                    			newCompositeNode(grammarAccess.getPlayersActionAccess().getIfActionParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_IfAction_2=ruleIfAction();

                    state._fsp--;


                    			current = this_IfAction_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalMDL.g:395:3: this_WhileAction_3= ruleWhileAction
                    {

                    			newCompositeNode(grammarAccess.getPlayersActionAccess().getWhileActionParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_WhileAction_3=ruleWhileAction();

                    state._fsp--;


                    			current = this_WhileAction_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePlayersAction"


    // $ANTLR start "entryRuleExpression"
    // InternalMDL.g:407:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalMDL.g:407:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalMDL.g:408:2: iv_ruleExpression= ruleExpression EOF
            {
             newCompositeNode(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;

             current =iv_ruleExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalMDL.g:414:1: ruleExpression returns [EObject current=null] : (this_FittingCard_0= ruleFittingCard | this_EnoughCoins_1= ruleEnoughCoins ) ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_FittingCard_0 = null;

        EObject this_EnoughCoins_1 = null;



        	enterRule();

        try {
            // InternalMDL.g:420:2: ( (this_FittingCard_0= ruleFittingCard | this_EnoughCoins_1= ruleEnoughCoins ) )
            // InternalMDL.g:421:2: (this_FittingCard_0= ruleFittingCard | this_EnoughCoins_1= ruleEnoughCoins )
            {
            // InternalMDL.g:421:2: (this_FittingCard_0= ruleFittingCard | this_EnoughCoins_1= ruleEnoughCoins )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==70) ) {
                int LA9_1 = input.LA(2);

                if ( (LA9_1==71) ) {
                    int LA9_2 = input.LA(3);

                    if ( ((LA9_2>=RULE_STRING && LA9_2<=RULE_ID)) ) {
                        alt9=1;
                    }
                    else if ( (LA9_2==RULE_INT||LA9_2==52) ) {
                        alt9=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 9, 2, input);

                        throw nvae;
                    }
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 9, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // InternalMDL.g:422:3: this_FittingCard_0= ruleFittingCard
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getFittingCardParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_FittingCard_0=ruleFittingCard();

                    state._fsp--;


                    			current = this_FittingCard_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMDL.g:431:3: this_EnoughCoins_1= ruleEnoughCoins
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getEnoughCoinsParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_EnoughCoins_1=ruleEnoughCoins();

                    state._fsp--;


                    			current = this_EnoughCoins_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleDominionGame"
    // InternalMDL.g:443:1: entryRuleDominionGame returns [EObject current=null] : iv_ruleDominionGame= ruleDominionGame EOF ;
    public final EObject entryRuleDominionGame() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDominionGame = null;


        try {
            // InternalMDL.g:443:53: (iv_ruleDominionGame= ruleDominionGame EOF )
            // InternalMDL.g:444:2: iv_ruleDominionGame= ruleDominionGame EOF
            {
             newCompositeNode(grammarAccess.getDominionGameRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDominionGame=ruleDominionGame();

            state._fsp--;

             current =iv_ruleDominionGame; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDominionGame"


    // $ANTLR start "ruleDominionGame"
    // InternalMDL.g:450:1: ruleDominionGame returns [EObject current=null] : ( () otherlv_1= 'DominionGame' otherlv_2= '{' (otherlv_3= 'playersplayarea' otherlv_4= '{' ( (lv_playersplayarea_5_0= rulePlayersPlayArea ) ) (otherlv_6= ',' ( (lv_playersplayarea_7_0= rulePlayersPlayArea ) ) )* otherlv_8= '}' )? (otherlv_9= 'players_turns' otherlv_10= '{' ( (lv_players_turns_11_0= rulePlayersTurn ) ) (otherlv_12= ',' ( (lv_players_turns_13_0= rulePlayersTurn ) ) )* otherlv_14= '}' )? (otherlv_15= 'avaialble_abilities' otherlv_16= '{' ( (lv_avaialble_abilities_17_0= ruleAbility ) ) (otherlv_18= ',' ( (lv_avaialble_abilities_19_0= ruleAbility ) ) )* otherlv_20= '}' )? (otherlv_21= 'trashpile' ( (lv_trashpile_22_0= ruleTrashPile ) ) )? (otherlv_23= 'supply_piles' otherlv_24= '{' ( (lv_supply_piles_25_0= ruleSupplyPile ) ) (otherlv_26= ',' ( (lv_supply_piles_27_0= ruleSupplyPile ) ) )* otherlv_28= '}' )? otherlv_29= '}' ) ;
    public final EObject ruleDominionGame() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_15=null;
        Token otherlv_16=null;
        Token otherlv_18=null;
        Token otherlv_20=null;
        Token otherlv_21=null;
        Token otherlv_23=null;
        Token otherlv_24=null;
        Token otherlv_26=null;
        Token otherlv_28=null;
        Token otherlv_29=null;
        EObject lv_playersplayarea_5_0 = null;

        EObject lv_playersplayarea_7_0 = null;

        EObject lv_players_turns_11_0 = null;

        EObject lv_players_turns_13_0 = null;

        EObject lv_avaialble_abilities_17_0 = null;

        EObject lv_avaialble_abilities_19_0 = null;

        EObject lv_trashpile_22_0 = null;

        EObject lv_supply_piles_25_0 = null;

        EObject lv_supply_piles_27_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:456:2: ( ( () otherlv_1= 'DominionGame' otherlv_2= '{' (otherlv_3= 'playersplayarea' otherlv_4= '{' ( (lv_playersplayarea_5_0= rulePlayersPlayArea ) ) (otherlv_6= ',' ( (lv_playersplayarea_7_0= rulePlayersPlayArea ) ) )* otherlv_8= '}' )? (otherlv_9= 'players_turns' otherlv_10= '{' ( (lv_players_turns_11_0= rulePlayersTurn ) ) (otherlv_12= ',' ( (lv_players_turns_13_0= rulePlayersTurn ) ) )* otherlv_14= '}' )? (otherlv_15= 'avaialble_abilities' otherlv_16= '{' ( (lv_avaialble_abilities_17_0= ruleAbility ) ) (otherlv_18= ',' ( (lv_avaialble_abilities_19_0= ruleAbility ) ) )* otherlv_20= '}' )? (otherlv_21= 'trashpile' ( (lv_trashpile_22_0= ruleTrashPile ) ) )? (otherlv_23= 'supply_piles' otherlv_24= '{' ( (lv_supply_piles_25_0= ruleSupplyPile ) ) (otherlv_26= ',' ( (lv_supply_piles_27_0= ruleSupplyPile ) ) )* otherlv_28= '}' )? otherlv_29= '}' ) )
            // InternalMDL.g:457:2: ( () otherlv_1= 'DominionGame' otherlv_2= '{' (otherlv_3= 'playersplayarea' otherlv_4= '{' ( (lv_playersplayarea_5_0= rulePlayersPlayArea ) ) (otherlv_6= ',' ( (lv_playersplayarea_7_0= rulePlayersPlayArea ) ) )* otherlv_8= '}' )? (otherlv_9= 'players_turns' otherlv_10= '{' ( (lv_players_turns_11_0= rulePlayersTurn ) ) (otherlv_12= ',' ( (lv_players_turns_13_0= rulePlayersTurn ) ) )* otherlv_14= '}' )? (otherlv_15= 'avaialble_abilities' otherlv_16= '{' ( (lv_avaialble_abilities_17_0= ruleAbility ) ) (otherlv_18= ',' ( (lv_avaialble_abilities_19_0= ruleAbility ) ) )* otherlv_20= '}' )? (otherlv_21= 'trashpile' ( (lv_trashpile_22_0= ruleTrashPile ) ) )? (otherlv_23= 'supply_piles' otherlv_24= '{' ( (lv_supply_piles_25_0= ruleSupplyPile ) ) (otherlv_26= ',' ( (lv_supply_piles_27_0= ruleSupplyPile ) ) )* otherlv_28= '}' )? otherlv_29= '}' )
            {
            // InternalMDL.g:457:2: ( () otherlv_1= 'DominionGame' otherlv_2= '{' (otherlv_3= 'playersplayarea' otherlv_4= '{' ( (lv_playersplayarea_5_0= rulePlayersPlayArea ) ) (otherlv_6= ',' ( (lv_playersplayarea_7_0= rulePlayersPlayArea ) ) )* otherlv_8= '}' )? (otherlv_9= 'players_turns' otherlv_10= '{' ( (lv_players_turns_11_0= rulePlayersTurn ) ) (otherlv_12= ',' ( (lv_players_turns_13_0= rulePlayersTurn ) ) )* otherlv_14= '}' )? (otherlv_15= 'avaialble_abilities' otherlv_16= '{' ( (lv_avaialble_abilities_17_0= ruleAbility ) ) (otherlv_18= ',' ( (lv_avaialble_abilities_19_0= ruleAbility ) ) )* otherlv_20= '}' )? (otherlv_21= 'trashpile' ( (lv_trashpile_22_0= ruleTrashPile ) ) )? (otherlv_23= 'supply_piles' otherlv_24= '{' ( (lv_supply_piles_25_0= ruleSupplyPile ) ) (otherlv_26= ',' ( (lv_supply_piles_27_0= ruleSupplyPile ) ) )* otherlv_28= '}' )? otherlv_29= '}' )
            // InternalMDL.g:458:3: () otherlv_1= 'DominionGame' otherlv_2= '{' (otherlv_3= 'playersplayarea' otherlv_4= '{' ( (lv_playersplayarea_5_0= rulePlayersPlayArea ) ) (otherlv_6= ',' ( (lv_playersplayarea_7_0= rulePlayersPlayArea ) ) )* otherlv_8= '}' )? (otherlv_9= 'players_turns' otherlv_10= '{' ( (lv_players_turns_11_0= rulePlayersTurn ) ) (otherlv_12= ',' ( (lv_players_turns_13_0= rulePlayersTurn ) ) )* otherlv_14= '}' )? (otherlv_15= 'avaialble_abilities' otherlv_16= '{' ( (lv_avaialble_abilities_17_0= ruleAbility ) ) (otherlv_18= ',' ( (lv_avaialble_abilities_19_0= ruleAbility ) ) )* otherlv_20= '}' )? (otherlv_21= 'trashpile' ( (lv_trashpile_22_0= ruleTrashPile ) ) )? (otherlv_23= 'supply_piles' otherlv_24= '{' ( (lv_supply_piles_25_0= ruleSupplyPile ) ) (otherlv_26= ',' ( (lv_supply_piles_27_0= ruleSupplyPile ) ) )* otherlv_28= '}' )? otherlv_29= '}'
            {
            // InternalMDL.g:458:3: ()
            // InternalMDL.g:459:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getDominionGameAccess().getDominionGameAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,18,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getDominionGameAccess().getDominionGameKeyword_1());
            		
            otherlv_2=(Token)match(input,13,FOLLOW_12); 

            			newLeafNode(otherlv_2, grammarAccess.getDominionGameAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMDL.g:473:3: (otherlv_3= 'playersplayarea' otherlv_4= '{' ( (lv_playersplayarea_5_0= rulePlayersPlayArea ) ) (otherlv_6= ',' ( (lv_playersplayarea_7_0= rulePlayersPlayArea ) ) )* otherlv_8= '}' )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==19) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalMDL.g:474:4: otherlv_3= 'playersplayarea' otherlv_4= '{' ( (lv_playersplayarea_5_0= rulePlayersPlayArea ) ) (otherlv_6= ',' ( (lv_playersplayarea_7_0= rulePlayersPlayArea ) ) )* otherlv_8= '}'
                    {
                    otherlv_3=(Token)match(input,19,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getDominionGameAccess().getPlayersplayareaKeyword_3_0());
                    			
                    otherlv_4=(Token)match(input,13,FOLLOW_13); 

                    				newLeafNode(otherlv_4, grammarAccess.getDominionGameAccess().getLeftCurlyBracketKeyword_3_1());
                    			
                    // InternalMDL.g:482:4: ( (lv_playersplayarea_5_0= rulePlayersPlayArea ) )
                    // InternalMDL.g:483:5: (lv_playersplayarea_5_0= rulePlayersPlayArea )
                    {
                    // InternalMDL.g:483:5: (lv_playersplayarea_5_0= rulePlayersPlayArea )
                    // InternalMDL.g:484:6: lv_playersplayarea_5_0= rulePlayersPlayArea
                    {

                    						newCompositeNode(grammarAccess.getDominionGameAccess().getPlayersplayareaPlayersPlayAreaParserRuleCall_3_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_playersplayarea_5_0=rulePlayersPlayArea();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDominionGameRule());
                    						}
                    						add(
                    							current,
                    							"playersplayarea",
                    							lv_playersplayarea_5_0,
                    							"metaDominoLang.MDL.PlayersPlayArea");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:501:4: (otherlv_6= ',' ( (lv_playersplayarea_7_0= rulePlayersPlayArea ) ) )*
                    loop10:
                    do {
                        int alt10=2;
                        int LA10_0 = input.LA(1);

                        if ( (LA10_0==14) ) {
                            alt10=1;
                        }


                        switch (alt10) {
                    	case 1 :
                    	    // InternalMDL.g:502:5: otherlv_6= ',' ( (lv_playersplayarea_7_0= rulePlayersPlayArea ) )
                    	    {
                    	    otherlv_6=(Token)match(input,14,FOLLOW_13); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getDominionGameAccess().getCommaKeyword_3_3_0());
                    	    				
                    	    // InternalMDL.g:506:5: ( (lv_playersplayarea_7_0= rulePlayersPlayArea ) )
                    	    // InternalMDL.g:507:6: (lv_playersplayarea_7_0= rulePlayersPlayArea )
                    	    {
                    	    // InternalMDL.g:507:6: (lv_playersplayarea_7_0= rulePlayersPlayArea )
                    	    // InternalMDL.g:508:7: lv_playersplayarea_7_0= rulePlayersPlayArea
                    	    {

                    	    							newCompositeNode(grammarAccess.getDominionGameAccess().getPlayersplayareaPlayersPlayAreaParserRuleCall_3_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_playersplayarea_7_0=rulePlayersPlayArea();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getDominionGameRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"playersplayarea",
                    	    								lv_playersplayarea_7_0,
                    	    								"metaDominoLang.MDL.PlayersPlayArea");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop10;
                        }
                    } while (true);

                    otherlv_8=(Token)match(input,15,FOLLOW_14); 

                    				newLeafNode(otherlv_8, grammarAccess.getDominionGameAccess().getRightCurlyBracketKeyword_3_4());
                    			

                    }
                    break;

            }

            // InternalMDL.g:531:3: (otherlv_9= 'players_turns' otherlv_10= '{' ( (lv_players_turns_11_0= rulePlayersTurn ) ) (otherlv_12= ',' ( (lv_players_turns_13_0= rulePlayersTurn ) ) )* otherlv_14= '}' )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==20) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalMDL.g:532:4: otherlv_9= 'players_turns' otherlv_10= '{' ( (lv_players_turns_11_0= rulePlayersTurn ) ) (otherlv_12= ',' ( (lv_players_turns_13_0= rulePlayersTurn ) ) )* otherlv_14= '}'
                    {
                    otherlv_9=(Token)match(input,20,FOLLOW_5); 

                    				newLeafNode(otherlv_9, grammarAccess.getDominionGameAccess().getPlayers_turnsKeyword_4_0());
                    			
                    otherlv_10=(Token)match(input,13,FOLLOW_15); 

                    				newLeafNode(otherlv_10, grammarAccess.getDominionGameAccess().getLeftCurlyBracketKeyword_4_1());
                    			
                    // InternalMDL.g:540:4: ( (lv_players_turns_11_0= rulePlayersTurn ) )
                    // InternalMDL.g:541:5: (lv_players_turns_11_0= rulePlayersTurn )
                    {
                    // InternalMDL.g:541:5: (lv_players_turns_11_0= rulePlayersTurn )
                    // InternalMDL.g:542:6: lv_players_turns_11_0= rulePlayersTurn
                    {

                    						newCompositeNode(grammarAccess.getDominionGameAccess().getPlayers_turnsPlayersTurnParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_players_turns_11_0=rulePlayersTurn();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDominionGameRule());
                    						}
                    						add(
                    							current,
                    							"players_turns",
                    							lv_players_turns_11_0,
                    							"metaDominoLang.MDL.PlayersTurn");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:559:4: (otherlv_12= ',' ( (lv_players_turns_13_0= rulePlayersTurn ) ) )*
                    loop12:
                    do {
                        int alt12=2;
                        int LA12_0 = input.LA(1);

                        if ( (LA12_0==14) ) {
                            alt12=1;
                        }


                        switch (alt12) {
                    	case 1 :
                    	    // InternalMDL.g:560:5: otherlv_12= ',' ( (lv_players_turns_13_0= rulePlayersTurn ) )
                    	    {
                    	    otherlv_12=(Token)match(input,14,FOLLOW_15); 

                    	    					newLeafNode(otherlv_12, grammarAccess.getDominionGameAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalMDL.g:564:5: ( (lv_players_turns_13_0= rulePlayersTurn ) )
                    	    // InternalMDL.g:565:6: (lv_players_turns_13_0= rulePlayersTurn )
                    	    {
                    	    // InternalMDL.g:565:6: (lv_players_turns_13_0= rulePlayersTurn )
                    	    // InternalMDL.g:566:7: lv_players_turns_13_0= rulePlayersTurn
                    	    {

                    	    							newCompositeNode(grammarAccess.getDominionGameAccess().getPlayers_turnsPlayersTurnParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_players_turns_13_0=rulePlayersTurn();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getDominionGameRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"players_turns",
                    	    								lv_players_turns_13_0,
                    	    								"metaDominoLang.MDL.PlayersTurn");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop12;
                        }
                    } while (true);

                    otherlv_14=(Token)match(input,15,FOLLOW_16); 

                    				newLeafNode(otherlv_14, grammarAccess.getDominionGameAccess().getRightCurlyBracketKeyword_4_4());
                    			

                    }
                    break;

            }

            // InternalMDL.g:589:3: (otherlv_15= 'avaialble_abilities' otherlv_16= '{' ( (lv_avaialble_abilities_17_0= ruleAbility ) ) (otherlv_18= ',' ( (lv_avaialble_abilities_19_0= ruleAbility ) ) )* otherlv_20= '}' )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==21) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalMDL.g:590:4: otherlv_15= 'avaialble_abilities' otherlv_16= '{' ( (lv_avaialble_abilities_17_0= ruleAbility ) ) (otherlv_18= ',' ( (lv_avaialble_abilities_19_0= ruleAbility ) ) )* otherlv_20= '}'
                    {
                    otherlv_15=(Token)match(input,21,FOLLOW_5); 

                    				newLeafNode(otherlv_15, grammarAccess.getDominionGameAccess().getAvaialble_abilitiesKeyword_5_0());
                    			
                    otherlv_16=(Token)match(input,13,FOLLOW_17); 

                    				newLeafNode(otherlv_16, grammarAccess.getDominionGameAccess().getLeftCurlyBracketKeyword_5_1());
                    			
                    // InternalMDL.g:598:4: ( (lv_avaialble_abilities_17_0= ruleAbility ) )
                    // InternalMDL.g:599:5: (lv_avaialble_abilities_17_0= ruleAbility )
                    {
                    // InternalMDL.g:599:5: (lv_avaialble_abilities_17_0= ruleAbility )
                    // InternalMDL.g:600:6: lv_avaialble_abilities_17_0= ruleAbility
                    {

                    						newCompositeNode(grammarAccess.getDominionGameAccess().getAvaialble_abilitiesAbilityParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_avaialble_abilities_17_0=ruleAbility();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDominionGameRule());
                    						}
                    						add(
                    							current,
                    							"avaialble_abilities",
                    							lv_avaialble_abilities_17_0,
                    							"metaDominoLang.MDL.Ability");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:617:4: (otherlv_18= ',' ( (lv_avaialble_abilities_19_0= ruleAbility ) ) )*
                    loop14:
                    do {
                        int alt14=2;
                        int LA14_0 = input.LA(1);

                        if ( (LA14_0==14) ) {
                            alt14=1;
                        }


                        switch (alt14) {
                    	case 1 :
                    	    // InternalMDL.g:618:5: otherlv_18= ',' ( (lv_avaialble_abilities_19_0= ruleAbility ) )
                    	    {
                    	    otherlv_18=(Token)match(input,14,FOLLOW_17); 

                    	    					newLeafNode(otherlv_18, grammarAccess.getDominionGameAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalMDL.g:622:5: ( (lv_avaialble_abilities_19_0= ruleAbility ) )
                    	    // InternalMDL.g:623:6: (lv_avaialble_abilities_19_0= ruleAbility )
                    	    {
                    	    // InternalMDL.g:623:6: (lv_avaialble_abilities_19_0= ruleAbility )
                    	    // InternalMDL.g:624:7: lv_avaialble_abilities_19_0= ruleAbility
                    	    {

                    	    							newCompositeNode(grammarAccess.getDominionGameAccess().getAvaialble_abilitiesAbilityParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_avaialble_abilities_19_0=ruleAbility();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getDominionGameRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"avaialble_abilities",
                    	    								lv_avaialble_abilities_19_0,
                    	    								"metaDominoLang.MDL.Ability");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop14;
                        }
                    } while (true);

                    otherlv_20=(Token)match(input,15,FOLLOW_18); 

                    				newLeafNode(otherlv_20, grammarAccess.getDominionGameAccess().getRightCurlyBracketKeyword_5_4());
                    			

                    }
                    break;

            }

            // InternalMDL.g:647:3: (otherlv_21= 'trashpile' ( (lv_trashpile_22_0= ruleTrashPile ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==22) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalMDL.g:648:4: otherlv_21= 'trashpile' ( (lv_trashpile_22_0= ruleTrashPile ) )
                    {
                    otherlv_21=(Token)match(input,22,FOLLOW_19); 

                    				newLeafNode(otherlv_21, grammarAccess.getDominionGameAccess().getTrashpileKeyword_6_0());
                    			
                    // InternalMDL.g:652:4: ( (lv_trashpile_22_0= ruleTrashPile ) )
                    // InternalMDL.g:653:5: (lv_trashpile_22_0= ruleTrashPile )
                    {
                    // InternalMDL.g:653:5: (lv_trashpile_22_0= ruleTrashPile )
                    // InternalMDL.g:654:6: lv_trashpile_22_0= ruleTrashPile
                    {

                    						newCompositeNode(grammarAccess.getDominionGameAccess().getTrashpileTrashPileParserRuleCall_6_1_0());
                    					
                    pushFollow(FOLLOW_20);
                    lv_trashpile_22_0=ruleTrashPile();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDominionGameRule());
                    						}
                    						set(
                    							current,
                    							"trashpile",
                    							lv_trashpile_22_0,
                    							"metaDominoLang.MDL.TrashPile");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMDL.g:672:3: (otherlv_23= 'supply_piles' otherlv_24= '{' ( (lv_supply_piles_25_0= ruleSupplyPile ) ) (otherlv_26= ',' ( (lv_supply_piles_27_0= ruleSupplyPile ) ) )* otherlv_28= '}' )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==23) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalMDL.g:673:4: otherlv_23= 'supply_piles' otherlv_24= '{' ( (lv_supply_piles_25_0= ruleSupplyPile ) ) (otherlv_26= ',' ( (lv_supply_piles_27_0= ruleSupplyPile ) ) )* otherlv_28= '}'
                    {
                    otherlv_23=(Token)match(input,23,FOLLOW_5); 

                    				newLeafNode(otherlv_23, grammarAccess.getDominionGameAccess().getSupply_pilesKeyword_7_0());
                    			
                    otherlv_24=(Token)match(input,13,FOLLOW_21); 

                    				newLeafNode(otherlv_24, grammarAccess.getDominionGameAccess().getLeftCurlyBracketKeyword_7_1());
                    			
                    // InternalMDL.g:681:4: ( (lv_supply_piles_25_0= ruleSupplyPile ) )
                    // InternalMDL.g:682:5: (lv_supply_piles_25_0= ruleSupplyPile )
                    {
                    // InternalMDL.g:682:5: (lv_supply_piles_25_0= ruleSupplyPile )
                    // InternalMDL.g:683:6: lv_supply_piles_25_0= ruleSupplyPile
                    {

                    						newCompositeNode(grammarAccess.getDominionGameAccess().getSupply_pilesSupplyPileParserRuleCall_7_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_supply_piles_25_0=ruleSupplyPile();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDominionGameRule());
                    						}
                    						add(
                    							current,
                    							"supply_piles",
                    							lv_supply_piles_25_0,
                    							"metaDominoLang.MDL.SupplyPile");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:700:4: (otherlv_26= ',' ( (lv_supply_piles_27_0= ruleSupplyPile ) ) )*
                    loop17:
                    do {
                        int alt17=2;
                        int LA17_0 = input.LA(1);

                        if ( (LA17_0==14) ) {
                            alt17=1;
                        }


                        switch (alt17) {
                    	case 1 :
                    	    // InternalMDL.g:701:5: otherlv_26= ',' ( (lv_supply_piles_27_0= ruleSupplyPile ) )
                    	    {
                    	    otherlv_26=(Token)match(input,14,FOLLOW_21); 

                    	    					newLeafNode(otherlv_26, grammarAccess.getDominionGameAccess().getCommaKeyword_7_3_0());
                    	    				
                    	    // InternalMDL.g:705:5: ( (lv_supply_piles_27_0= ruleSupplyPile ) )
                    	    // InternalMDL.g:706:6: (lv_supply_piles_27_0= ruleSupplyPile )
                    	    {
                    	    // InternalMDL.g:706:6: (lv_supply_piles_27_0= ruleSupplyPile )
                    	    // InternalMDL.g:707:7: lv_supply_piles_27_0= ruleSupplyPile
                    	    {

                    	    							newCompositeNode(grammarAccess.getDominionGameAccess().getSupply_pilesSupplyPileParserRuleCall_7_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_supply_piles_27_0=ruleSupplyPile();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getDominionGameRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"supply_piles",
                    	    								lv_supply_piles_27_0,
                    	    								"metaDominoLang.MDL.SupplyPile");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop17;
                        }
                    } while (true);

                    otherlv_28=(Token)match(input,15,FOLLOW_22); 

                    				newLeafNode(otherlv_28, grammarAccess.getDominionGameAccess().getRightCurlyBracketKeyword_7_4());
                    			

                    }
                    break;

            }

            otherlv_29=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_29, grammarAccess.getDominionGameAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDominionGame"


    // $ANTLR start "entryRuleCardLibrary"
    // InternalMDL.g:738:1: entryRuleCardLibrary returns [EObject current=null] : iv_ruleCardLibrary= ruleCardLibrary EOF ;
    public final EObject entryRuleCardLibrary() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCardLibrary = null;


        try {
            // InternalMDL.g:738:52: (iv_ruleCardLibrary= ruleCardLibrary EOF )
            // InternalMDL.g:739:2: iv_ruleCardLibrary= ruleCardLibrary EOF
            {
             newCompositeNode(grammarAccess.getCardLibraryRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCardLibrary=ruleCardLibrary();

            state._fsp--;

             current =iv_ruleCardLibrary; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCardLibrary"


    // $ANTLR start "ruleCardLibrary"
    // InternalMDL.g:745:1: ruleCardLibrary returns [EObject current=null] : ( () otherlv_1= 'CardLibrary' otherlv_2= '{' (otherlv_3= 'card' otherlv_4= '{' ( (lv_card_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_card_7_0= ruleCard ) ) )* otherlv_8= '}' )? (otherlv_9= 'abilities' otherlv_10= '{' ( (lv_abilities_11_0= ruleAbility ) ) (otherlv_12= ',' ( (lv_abilities_13_0= ruleAbility ) ) )* otherlv_14= '}' )? otherlv_15= '}' ) ;
    public final EObject ruleCardLibrary() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_15=null;
        EObject lv_card_5_0 = null;

        EObject lv_card_7_0 = null;

        EObject lv_abilities_11_0 = null;

        EObject lv_abilities_13_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:751:2: ( ( () otherlv_1= 'CardLibrary' otherlv_2= '{' (otherlv_3= 'card' otherlv_4= '{' ( (lv_card_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_card_7_0= ruleCard ) ) )* otherlv_8= '}' )? (otherlv_9= 'abilities' otherlv_10= '{' ( (lv_abilities_11_0= ruleAbility ) ) (otherlv_12= ',' ( (lv_abilities_13_0= ruleAbility ) ) )* otherlv_14= '}' )? otherlv_15= '}' ) )
            // InternalMDL.g:752:2: ( () otherlv_1= 'CardLibrary' otherlv_2= '{' (otherlv_3= 'card' otherlv_4= '{' ( (lv_card_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_card_7_0= ruleCard ) ) )* otherlv_8= '}' )? (otherlv_9= 'abilities' otherlv_10= '{' ( (lv_abilities_11_0= ruleAbility ) ) (otherlv_12= ',' ( (lv_abilities_13_0= ruleAbility ) ) )* otherlv_14= '}' )? otherlv_15= '}' )
            {
            // InternalMDL.g:752:2: ( () otherlv_1= 'CardLibrary' otherlv_2= '{' (otherlv_3= 'card' otherlv_4= '{' ( (lv_card_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_card_7_0= ruleCard ) ) )* otherlv_8= '}' )? (otherlv_9= 'abilities' otherlv_10= '{' ( (lv_abilities_11_0= ruleAbility ) ) (otherlv_12= ',' ( (lv_abilities_13_0= ruleAbility ) ) )* otherlv_14= '}' )? otherlv_15= '}' )
            // InternalMDL.g:753:3: () otherlv_1= 'CardLibrary' otherlv_2= '{' (otherlv_3= 'card' otherlv_4= '{' ( (lv_card_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_card_7_0= ruleCard ) ) )* otherlv_8= '}' )? (otherlv_9= 'abilities' otherlv_10= '{' ( (lv_abilities_11_0= ruleAbility ) ) (otherlv_12= ',' ( (lv_abilities_13_0= ruleAbility ) ) )* otherlv_14= '}' )? otherlv_15= '}'
            {
            // InternalMDL.g:753:3: ()
            // InternalMDL.g:754:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getCardLibraryAccess().getCardLibraryAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,24,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getCardLibraryAccess().getCardLibraryKeyword_1());
            		
            otherlv_2=(Token)match(input,13,FOLLOW_23); 

            			newLeafNode(otherlv_2, grammarAccess.getCardLibraryAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMDL.g:768:3: (otherlv_3= 'card' otherlv_4= '{' ( (lv_card_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_card_7_0= ruleCard ) ) )* otherlv_8= '}' )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==25) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalMDL.g:769:4: otherlv_3= 'card' otherlv_4= '{' ( (lv_card_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_card_7_0= ruleCard ) ) )* otherlv_8= '}'
                    {
                    otherlv_3=(Token)match(input,25,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getCardLibraryAccess().getCardKeyword_3_0());
                    			
                    otherlv_4=(Token)match(input,13,FOLLOW_24); 

                    				newLeafNode(otherlv_4, grammarAccess.getCardLibraryAccess().getLeftCurlyBracketKeyword_3_1());
                    			
                    // InternalMDL.g:777:4: ( (lv_card_5_0= ruleCard ) )
                    // InternalMDL.g:778:5: (lv_card_5_0= ruleCard )
                    {
                    // InternalMDL.g:778:5: (lv_card_5_0= ruleCard )
                    // InternalMDL.g:779:6: lv_card_5_0= ruleCard
                    {

                    						newCompositeNode(grammarAccess.getCardLibraryAccess().getCardCardParserRuleCall_3_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_card_5_0=ruleCard();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCardLibraryRule());
                    						}
                    						add(
                    							current,
                    							"card",
                    							lv_card_5_0,
                    							"metaDominoLang.MDL.Card");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:796:4: (otherlv_6= ',' ( (lv_card_7_0= ruleCard ) ) )*
                    loop19:
                    do {
                        int alt19=2;
                        int LA19_0 = input.LA(1);

                        if ( (LA19_0==14) ) {
                            alt19=1;
                        }


                        switch (alt19) {
                    	case 1 :
                    	    // InternalMDL.g:797:5: otherlv_6= ',' ( (lv_card_7_0= ruleCard ) )
                    	    {
                    	    otherlv_6=(Token)match(input,14,FOLLOW_24); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getCardLibraryAccess().getCommaKeyword_3_3_0());
                    	    				
                    	    // InternalMDL.g:801:5: ( (lv_card_7_0= ruleCard ) )
                    	    // InternalMDL.g:802:6: (lv_card_7_0= ruleCard )
                    	    {
                    	    // InternalMDL.g:802:6: (lv_card_7_0= ruleCard )
                    	    // InternalMDL.g:803:7: lv_card_7_0= ruleCard
                    	    {

                    	    							newCompositeNode(grammarAccess.getCardLibraryAccess().getCardCardParserRuleCall_3_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_card_7_0=ruleCard();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getCardLibraryRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"card",
                    	    								lv_card_7_0,
                    	    								"metaDominoLang.MDL.Card");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop19;
                        }
                    } while (true);

                    otherlv_8=(Token)match(input,15,FOLLOW_25); 

                    				newLeafNode(otherlv_8, grammarAccess.getCardLibraryAccess().getRightCurlyBracketKeyword_3_4());
                    			

                    }
                    break;

            }

            // InternalMDL.g:826:3: (otherlv_9= 'abilities' otherlv_10= '{' ( (lv_abilities_11_0= ruleAbility ) ) (otherlv_12= ',' ( (lv_abilities_13_0= ruleAbility ) ) )* otherlv_14= '}' )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==26) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalMDL.g:827:4: otherlv_9= 'abilities' otherlv_10= '{' ( (lv_abilities_11_0= ruleAbility ) ) (otherlv_12= ',' ( (lv_abilities_13_0= ruleAbility ) ) )* otherlv_14= '}'
                    {
                    otherlv_9=(Token)match(input,26,FOLLOW_5); 

                    				newLeafNode(otherlv_9, grammarAccess.getCardLibraryAccess().getAbilitiesKeyword_4_0());
                    			
                    otherlv_10=(Token)match(input,13,FOLLOW_17); 

                    				newLeafNode(otherlv_10, grammarAccess.getCardLibraryAccess().getLeftCurlyBracketKeyword_4_1());
                    			
                    // InternalMDL.g:835:4: ( (lv_abilities_11_0= ruleAbility ) )
                    // InternalMDL.g:836:5: (lv_abilities_11_0= ruleAbility )
                    {
                    // InternalMDL.g:836:5: (lv_abilities_11_0= ruleAbility )
                    // InternalMDL.g:837:6: lv_abilities_11_0= ruleAbility
                    {

                    						newCompositeNode(grammarAccess.getCardLibraryAccess().getAbilitiesAbilityParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_abilities_11_0=ruleAbility();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCardLibraryRule());
                    						}
                    						add(
                    							current,
                    							"abilities",
                    							lv_abilities_11_0,
                    							"metaDominoLang.MDL.Ability");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:854:4: (otherlv_12= ',' ( (lv_abilities_13_0= ruleAbility ) ) )*
                    loop21:
                    do {
                        int alt21=2;
                        int LA21_0 = input.LA(1);

                        if ( (LA21_0==14) ) {
                            alt21=1;
                        }


                        switch (alt21) {
                    	case 1 :
                    	    // InternalMDL.g:855:5: otherlv_12= ',' ( (lv_abilities_13_0= ruleAbility ) )
                    	    {
                    	    otherlv_12=(Token)match(input,14,FOLLOW_17); 

                    	    					newLeafNode(otherlv_12, grammarAccess.getCardLibraryAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalMDL.g:859:5: ( (lv_abilities_13_0= ruleAbility ) )
                    	    // InternalMDL.g:860:6: (lv_abilities_13_0= ruleAbility )
                    	    {
                    	    // InternalMDL.g:860:6: (lv_abilities_13_0= ruleAbility )
                    	    // InternalMDL.g:861:7: lv_abilities_13_0= ruleAbility
                    	    {

                    	    							newCompositeNode(grammarAccess.getCardLibraryAccess().getAbilitiesAbilityParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_abilities_13_0=ruleAbility();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getCardLibraryRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"abilities",
                    	    								lv_abilities_13_0,
                    	    								"metaDominoLang.MDL.Ability");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop21;
                        }
                    } while (true);

                    otherlv_14=(Token)match(input,15,FOLLOW_22); 

                    				newLeafNode(otherlv_14, grammarAccess.getCardLibraryAccess().getRightCurlyBracketKeyword_4_4());
                    			

                    }
                    break;

            }

            otherlv_15=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_15, grammarAccess.getCardLibraryAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCardLibrary"


    // $ANTLR start "entryRuleStrategy"
    // InternalMDL.g:892:1: entryRuleStrategy returns [EObject current=null] : iv_ruleStrategy= ruleStrategy EOF ;
    public final EObject entryRuleStrategy() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStrategy = null;


        try {
            // InternalMDL.g:892:49: (iv_ruleStrategy= ruleStrategy EOF )
            // InternalMDL.g:893:2: iv_ruleStrategy= ruleStrategy EOF
            {
             newCompositeNode(grammarAccess.getStrategyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStrategy=ruleStrategy();

            state._fsp--;

             current =iv_ruleStrategy; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStrategy"


    // $ANTLR start "ruleStrategy"
    // InternalMDL.g:899:1: ruleStrategy returns [EObject current=null] : ( (otherlv_0= 'Action' otherlv_1= 'phase' otherlv_2= ':' ( (lv_actionphase_3_0= ruleActionPhase ) ) )? otherlv_4= 'Buy' otherlv_5= 'phase' otherlv_6= ':' ( (lv_buyphase_7_0= ruleBuyPhase ) ) ) ;
    public final EObject ruleStrategy() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        EObject lv_actionphase_3_0 = null;

        EObject lv_buyphase_7_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:905:2: ( ( (otherlv_0= 'Action' otherlv_1= 'phase' otherlv_2= ':' ( (lv_actionphase_3_0= ruleActionPhase ) ) )? otherlv_4= 'Buy' otherlv_5= 'phase' otherlv_6= ':' ( (lv_buyphase_7_0= ruleBuyPhase ) ) ) )
            // InternalMDL.g:906:2: ( (otherlv_0= 'Action' otherlv_1= 'phase' otherlv_2= ':' ( (lv_actionphase_3_0= ruleActionPhase ) ) )? otherlv_4= 'Buy' otherlv_5= 'phase' otherlv_6= ':' ( (lv_buyphase_7_0= ruleBuyPhase ) ) )
            {
            // InternalMDL.g:906:2: ( (otherlv_0= 'Action' otherlv_1= 'phase' otherlv_2= ':' ( (lv_actionphase_3_0= ruleActionPhase ) ) )? otherlv_4= 'Buy' otherlv_5= 'phase' otherlv_6= ':' ( (lv_buyphase_7_0= ruleBuyPhase ) ) )
            // InternalMDL.g:907:3: (otherlv_0= 'Action' otherlv_1= 'phase' otherlv_2= ':' ( (lv_actionphase_3_0= ruleActionPhase ) ) )? otherlv_4= 'Buy' otherlv_5= 'phase' otherlv_6= ':' ( (lv_buyphase_7_0= ruleBuyPhase ) )
            {
            // InternalMDL.g:907:3: (otherlv_0= 'Action' otherlv_1= 'phase' otherlv_2= ':' ( (lv_actionphase_3_0= ruleActionPhase ) ) )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==27) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalMDL.g:908:4: otherlv_0= 'Action' otherlv_1= 'phase' otherlv_2= ':' ( (lv_actionphase_3_0= ruleActionPhase ) )
                    {
                    otherlv_0=(Token)match(input,27,FOLLOW_26); 

                    				newLeafNode(otherlv_0, grammarAccess.getStrategyAccess().getActionKeyword_0_0());
                    			
                    otherlv_1=(Token)match(input,28,FOLLOW_9); 

                    				newLeafNode(otherlv_1, grammarAccess.getStrategyAccess().getPhaseKeyword_0_1());
                    			
                    otherlv_2=(Token)match(input,17,FOLLOW_27); 

                    				newLeafNode(otherlv_2, grammarAccess.getStrategyAccess().getColonKeyword_0_2());
                    			
                    // InternalMDL.g:920:4: ( (lv_actionphase_3_0= ruleActionPhase ) )
                    // InternalMDL.g:921:5: (lv_actionphase_3_0= ruleActionPhase )
                    {
                    // InternalMDL.g:921:5: (lv_actionphase_3_0= ruleActionPhase )
                    // InternalMDL.g:922:6: lv_actionphase_3_0= ruleActionPhase
                    {

                    						newCompositeNode(grammarAccess.getStrategyAccess().getActionphaseActionPhaseParserRuleCall_0_3_0());
                    					
                    pushFollow(FOLLOW_28);
                    lv_actionphase_3_0=ruleActionPhase();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getStrategyRule());
                    						}
                    						set(
                    							current,
                    							"actionphase",
                    							lv_actionphase_3_0,
                    							"metaDominoLang.MDL.ActionPhase");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_4=(Token)match(input,29,FOLLOW_26); 

            			newLeafNode(otherlv_4, grammarAccess.getStrategyAccess().getBuyKeyword_1());
            		
            otherlv_5=(Token)match(input,28,FOLLOW_9); 

            			newLeafNode(otherlv_5, grammarAccess.getStrategyAccess().getPhaseKeyword_2());
            		
            otherlv_6=(Token)match(input,17,FOLLOW_29); 

            			newLeafNode(otherlv_6, grammarAccess.getStrategyAccess().getColonKeyword_3());
            		
            // InternalMDL.g:952:3: ( (lv_buyphase_7_0= ruleBuyPhase ) )
            // InternalMDL.g:953:4: (lv_buyphase_7_0= ruleBuyPhase )
            {
            // InternalMDL.g:953:4: (lv_buyphase_7_0= ruleBuyPhase )
            // InternalMDL.g:954:5: lv_buyphase_7_0= ruleBuyPhase
            {

            					newCompositeNode(grammarAccess.getStrategyAccess().getBuyphaseBuyPhaseParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_2);
            lv_buyphase_7_0=ruleBuyPhase();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStrategyRule());
            					}
            					set(
            						current,
            						"buyphase",
            						lv_buyphase_7_0,
            						"metaDominoLang.MDL.BuyPhase");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStrategy"


    // $ANTLR start "entryRulePlayersPlayArea"
    // InternalMDL.g:975:1: entryRulePlayersPlayArea returns [EObject current=null] : iv_rulePlayersPlayArea= rulePlayersPlayArea EOF ;
    public final EObject entryRulePlayersPlayArea() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePlayersPlayArea = null;


        try {
            // InternalMDL.g:975:56: (iv_rulePlayersPlayArea= rulePlayersPlayArea EOF )
            // InternalMDL.g:976:2: iv_rulePlayersPlayArea= rulePlayersPlayArea EOF
            {
             newCompositeNode(grammarAccess.getPlayersPlayAreaRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePlayersPlayArea=rulePlayersPlayArea();

            state._fsp--;

             current =iv_rulePlayersPlayArea; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePlayersPlayArea"


    // $ANTLR start "rulePlayersPlayArea"
    // InternalMDL.g:982:1: rulePlayersPlayArea returns [EObject current=null] : (otherlv_0= 'PlayersPlayArea' otherlv_1= '{' (otherlv_2= 'playersName' ( (lv_playersName_3_0= ruleEString ) ) )? (otherlv_4= 'actionsLeft' ( (lv_actionsLeft_5_0= ruleEInt ) ) )? (otherlv_6= 'buysLeft' ( (lv_buysLeft_7_0= ruleEInt ) ) )? otherlv_8= 'cards_played_this_turn' ( (lv_cards_played_this_turn_9_0= ruleCardsPlayedThisTurn ) ) otherlv_10= 'players_deck' ( (lv_players_deck_11_0= rulePlayersDeck ) ) otherlv_12= 'players_hand' ( (lv_players_hand_13_0= rulePlayersHand ) ) otherlv_14= 'discard_pile' ( (lv_discard_pile_15_0= ruleDiscardPile ) ) otherlv_16= '}' ) ;
    public final EObject rulePlayersPlayArea() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        AntlrDatatypeRuleToken lv_playersName_3_0 = null;

        AntlrDatatypeRuleToken lv_actionsLeft_5_0 = null;

        AntlrDatatypeRuleToken lv_buysLeft_7_0 = null;

        EObject lv_cards_played_this_turn_9_0 = null;

        EObject lv_players_deck_11_0 = null;

        EObject lv_players_hand_13_0 = null;

        EObject lv_discard_pile_15_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:988:2: ( (otherlv_0= 'PlayersPlayArea' otherlv_1= '{' (otherlv_2= 'playersName' ( (lv_playersName_3_0= ruleEString ) ) )? (otherlv_4= 'actionsLeft' ( (lv_actionsLeft_5_0= ruleEInt ) ) )? (otherlv_6= 'buysLeft' ( (lv_buysLeft_7_0= ruleEInt ) ) )? otherlv_8= 'cards_played_this_turn' ( (lv_cards_played_this_turn_9_0= ruleCardsPlayedThisTurn ) ) otherlv_10= 'players_deck' ( (lv_players_deck_11_0= rulePlayersDeck ) ) otherlv_12= 'players_hand' ( (lv_players_hand_13_0= rulePlayersHand ) ) otherlv_14= 'discard_pile' ( (lv_discard_pile_15_0= ruleDiscardPile ) ) otherlv_16= '}' ) )
            // InternalMDL.g:989:2: (otherlv_0= 'PlayersPlayArea' otherlv_1= '{' (otherlv_2= 'playersName' ( (lv_playersName_3_0= ruleEString ) ) )? (otherlv_4= 'actionsLeft' ( (lv_actionsLeft_5_0= ruleEInt ) ) )? (otherlv_6= 'buysLeft' ( (lv_buysLeft_7_0= ruleEInt ) ) )? otherlv_8= 'cards_played_this_turn' ( (lv_cards_played_this_turn_9_0= ruleCardsPlayedThisTurn ) ) otherlv_10= 'players_deck' ( (lv_players_deck_11_0= rulePlayersDeck ) ) otherlv_12= 'players_hand' ( (lv_players_hand_13_0= rulePlayersHand ) ) otherlv_14= 'discard_pile' ( (lv_discard_pile_15_0= ruleDiscardPile ) ) otherlv_16= '}' )
            {
            // InternalMDL.g:989:2: (otherlv_0= 'PlayersPlayArea' otherlv_1= '{' (otherlv_2= 'playersName' ( (lv_playersName_3_0= ruleEString ) ) )? (otherlv_4= 'actionsLeft' ( (lv_actionsLeft_5_0= ruleEInt ) ) )? (otherlv_6= 'buysLeft' ( (lv_buysLeft_7_0= ruleEInt ) ) )? otherlv_8= 'cards_played_this_turn' ( (lv_cards_played_this_turn_9_0= ruleCardsPlayedThisTurn ) ) otherlv_10= 'players_deck' ( (lv_players_deck_11_0= rulePlayersDeck ) ) otherlv_12= 'players_hand' ( (lv_players_hand_13_0= rulePlayersHand ) ) otherlv_14= 'discard_pile' ( (lv_discard_pile_15_0= ruleDiscardPile ) ) otherlv_16= '}' )
            // InternalMDL.g:990:3: otherlv_0= 'PlayersPlayArea' otherlv_1= '{' (otherlv_2= 'playersName' ( (lv_playersName_3_0= ruleEString ) ) )? (otherlv_4= 'actionsLeft' ( (lv_actionsLeft_5_0= ruleEInt ) ) )? (otherlv_6= 'buysLeft' ( (lv_buysLeft_7_0= ruleEInt ) ) )? otherlv_8= 'cards_played_this_turn' ( (lv_cards_played_this_turn_9_0= ruleCardsPlayedThisTurn ) ) otherlv_10= 'players_deck' ( (lv_players_deck_11_0= rulePlayersDeck ) ) otherlv_12= 'players_hand' ( (lv_players_hand_13_0= rulePlayersHand ) ) otherlv_14= 'discard_pile' ( (lv_discard_pile_15_0= ruleDiscardPile ) ) otherlv_16= '}'
            {
            otherlv_0=(Token)match(input,30,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getPlayersPlayAreaAccess().getPlayersPlayAreaKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_30); 

            			newLeafNode(otherlv_1, grammarAccess.getPlayersPlayAreaAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalMDL.g:998:3: (otherlv_2= 'playersName' ( (lv_playersName_3_0= ruleEString ) ) )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==31) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalMDL.g:999:4: otherlv_2= 'playersName' ( (lv_playersName_3_0= ruleEString ) )
                    {
                    otherlv_2=(Token)match(input,31,FOLLOW_31); 

                    				newLeafNode(otherlv_2, grammarAccess.getPlayersPlayAreaAccess().getPlayersNameKeyword_2_0());
                    			
                    // InternalMDL.g:1003:4: ( (lv_playersName_3_0= ruleEString ) )
                    // InternalMDL.g:1004:5: (lv_playersName_3_0= ruleEString )
                    {
                    // InternalMDL.g:1004:5: (lv_playersName_3_0= ruleEString )
                    // InternalMDL.g:1005:6: lv_playersName_3_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getPlayersPlayAreaAccess().getPlayersNameEStringParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_32);
                    lv_playersName_3_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPlayersPlayAreaRule());
                    						}
                    						set(
                    							current,
                    							"playersName",
                    							lv_playersName_3_0,
                    							"metaDominoLang.MDL.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMDL.g:1023:3: (otherlv_4= 'actionsLeft' ( (lv_actionsLeft_5_0= ruleEInt ) ) )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==32) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalMDL.g:1024:4: otherlv_4= 'actionsLeft' ( (lv_actionsLeft_5_0= ruleEInt ) )
                    {
                    otherlv_4=(Token)match(input,32,FOLLOW_33); 

                    				newLeafNode(otherlv_4, grammarAccess.getPlayersPlayAreaAccess().getActionsLeftKeyword_3_0());
                    			
                    // InternalMDL.g:1028:4: ( (lv_actionsLeft_5_0= ruleEInt ) )
                    // InternalMDL.g:1029:5: (lv_actionsLeft_5_0= ruleEInt )
                    {
                    // InternalMDL.g:1029:5: (lv_actionsLeft_5_0= ruleEInt )
                    // InternalMDL.g:1030:6: lv_actionsLeft_5_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getPlayersPlayAreaAccess().getActionsLeftEIntParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_34);
                    lv_actionsLeft_5_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPlayersPlayAreaRule());
                    						}
                    						set(
                    							current,
                    							"actionsLeft",
                    							lv_actionsLeft_5_0,
                    							"metaDominoLang.MDL.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalMDL.g:1048:3: (otherlv_6= 'buysLeft' ( (lv_buysLeft_7_0= ruleEInt ) ) )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==33) ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // InternalMDL.g:1049:4: otherlv_6= 'buysLeft' ( (lv_buysLeft_7_0= ruleEInt ) )
                    {
                    otherlv_6=(Token)match(input,33,FOLLOW_33); 

                    				newLeafNode(otherlv_6, grammarAccess.getPlayersPlayAreaAccess().getBuysLeftKeyword_4_0());
                    			
                    // InternalMDL.g:1053:4: ( (lv_buysLeft_7_0= ruleEInt ) )
                    // InternalMDL.g:1054:5: (lv_buysLeft_7_0= ruleEInt )
                    {
                    // InternalMDL.g:1054:5: (lv_buysLeft_7_0= ruleEInt )
                    // InternalMDL.g:1055:6: lv_buysLeft_7_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getPlayersPlayAreaAccess().getBuysLeftEIntParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_35);
                    lv_buysLeft_7_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPlayersPlayAreaRule());
                    						}
                    						set(
                    							current,
                    							"buysLeft",
                    							lv_buysLeft_7_0,
                    							"metaDominoLang.MDL.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_8=(Token)match(input,34,FOLLOW_36); 

            			newLeafNode(otherlv_8, grammarAccess.getPlayersPlayAreaAccess().getCards_played_this_turnKeyword_5());
            		
            // InternalMDL.g:1077:3: ( (lv_cards_played_this_turn_9_0= ruleCardsPlayedThisTurn ) )
            // InternalMDL.g:1078:4: (lv_cards_played_this_turn_9_0= ruleCardsPlayedThisTurn )
            {
            // InternalMDL.g:1078:4: (lv_cards_played_this_turn_9_0= ruleCardsPlayedThisTurn )
            // InternalMDL.g:1079:5: lv_cards_played_this_turn_9_0= ruleCardsPlayedThisTurn
            {

            					newCompositeNode(grammarAccess.getPlayersPlayAreaAccess().getCards_played_this_turnCardsPlayedThisTurnParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_37);
            lv_cards_played_this_turn_9_0=ruleCardsPlayedThisTurn();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPlayersPlayAreaRule());
            					}
            					set(
            						current,
            						"cards_played_this_turn",
            						lv_cards_played_this_turn_9_0,
            						"metaDominoLang.MDL.CardsPlayedThisTurn");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_10=(Token)match(input,35,FOLLOW_38); 

            			newLeafNode(otherlv_10, grammarAccess.getPlayersPlayAreaAccess().getPlayers_deckKeyword_7());
            		
            // InternalMDL.g:1100:3: ( (lv_players_deck_11_0= rulePlayersDeck ) )
            // InternalMDL.g:1101:4: (lv_players_deck_11_0= rulePlayersDeck )
            {
            // InternalMDL.g:1101:4: (lv_players_deck_11_0= rulePlayersDeck )
            // InternalMDL.g:1102:5: lv_players_deck_11_0= rulePlayersDeck
            {

            					newCompositeNode(grammarAccess.getPlayersPlayAreaAccess().getPlayers_deckPlayersDeckParserRuleCall_8_0());
            				
            pushFollow(FOLLOW_39);
            lv_players_deck_11_0=rulePlayersDeck();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPlayersPlayAreaRule());
            					}
            					set(
            						current,
            						"players_deck",
            						lv_players_deck_11_0,
            						"metaDominoLang.MDL.PlayersDeck");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_12=(Token)match(input,36,FOLLOW_40); 

            			newLeafNode(otherlv_12, grammarAccess.getPlayersPlayAreaAccess().getPlayers_handKeyword_9());
            		
            // InternalMDL.g:1123:3: ( (lv_players_hand_13_0= rulePlayersHand ) )
            // InternalMDL.g:1124:4: (lv_players_hand_13_0= rulePlayersHand )
            {
            // InternalMDL.g:1124:4: (lv_players_hand_13_0= rulePlayersHand )
            // InternalMDL.g:1125:5: lv_players_hand_13_0= rulePlayersHand
            {

            					newCompositeNode(grammarAccess.getPlayersPlayAreaAccess().getPlayers_handPlayersHandParserRuleCall_10_0());
            				
            pushFollow(FOLLOW_41);
            lv_players_hand_13_0=rulePlayersHand();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPlayersPlayAreaRule());
            					}
            					set(
            						current,
            						"players_hand",
            						lv_players_hand_13_0,
            						"metaDominoLang.MDL.PlayersHand");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_14=(Token)match(input,37,FOLLOW_42); 

            			newLeafNode(otherlv_14, grammarAccess.getPlayersPlayAreaAccess().getDiscard_pileKeyword_11());
            		
            // InternalMDL.g:1146:3: ( (lv_discard_pile_15_0= ruleDiscardPile ) )
            // InternalMDL.g:1147:4: (lv_discard_pile_15_0= ruleDiscardPile )
            {
            // InternalMDL.g:1147:4: (lv_discard_pile_15_0= ruleDiscardPile )
            // InternalMDL.g:1148:5: lv_discard_pile_15_0= ruleDiscardPile
            {

            					newCompositeNode(grammarAccess.getPlayersPlayAreaAccess().getDiscard_pileDiscardPileParserRuleCall_12_0());
            				
            pushFollow(FOLLOW_22);
            lv_discard_pile_15_0=ruleDiscardPile();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPlayersPlayAreaRule());
            					}
            					set(
            						current,
            						"discard_pile",
            						lv_discard_pile_15_0,
            						"metaDominoLang.MDL.DiscardPile");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_16=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_16, grammarAccess.getPlayersPlayAreaAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePlayersPlayArea"


    // $ANTLR start "entryRulePlayersTurn"
    // InternalMDL.g:1173:1: entryRulePlayersTurn returns [EObject current=null] : iv_rulePlayersTurn= rulePlayersTurn EOF ;
    public final EObject entryRulePlayersTurn() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePlayersTurn = null;


        try {
            // InternalMDL.g:1173:52: (iv_rulePlayersTurn= rulePlayersTurn EOF )
            // InternalMDL.g:1174:2: iv_rulePlayersTurn= rulePlayersTurn EOF
            {
             newCompositeNode(grammarAccess.getPlayersTurnRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePlayersTurn=rulePlayersTurn();

            state._fsp--;

             current =iv_rulePlayersTurn; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePlayersTurn"


    // $ANTLR start "rulePlayersTurn"
    // InternalMDL.g:1180:1: rulePlayersTurn returns [EObject current=null] : (otherlv_0= 'PlayersTurn' otherlv_1= '{' (otherlv_2= 'turnNumber' ( (lv_turnNumber_3_0= ruleEInt ) ) )? otherlv_4= 'player' ( ( ruleEString ) ) otherlv_6= 'players_hand' ( ( ruleEString ) ) otherlv_8= 'action_phase' ( (lv_action_phase_9_0= ruleActionPhase ) ) otherlv_10= 'buyphase' ( (lv_buyphase_11_0= ruleBuyPhase ) ) otherlv_12= 'cleanupphase' ( (lv_cleanupphase_13_0= ruleCleanupPhase ) ) otherlv_14= '}' ) ;
    public final EObject rulePlayersTurn() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        AntlrDatatypeRuleToken lv_turnNumber_3_0 = null;

        EObject lv_action_phase_9_0 = null;

        EObject lv_buyphase_11_0 = null;

        EObject lv_cleanupphase_13_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:1186:2: ( (otherlv_0= 'PlayersTurn' otherlv_1= '{' (otherlv_2= 'turnNumber' ( (lv_turnNumber_3_0= ruleEInt ) ) )? otherlv_4= 'player' ( ( ruleEString ) ) otherlv_6= 'players_hand' ( ( ruleEString ) ) otherlv_8= 'action_phase' ( (lv_action_phase_9_0= ruleActionPhase ) ) otherlv_10= 'buyphase' ( (lv_buyphase_11_0= ruleBuyPhase ) ) otherlv_12= 'cleanupphase' ( (lv_cleanupphase_13_0= ruleCleanupPhase ) ) otherlv_14= '}' ) )
            // InternalMDL.g:1187:2: (otherlv_0= 'PlayersTurn' otherlv_1= '{' (otherlv_2= 'turnNumber' ( (lv_turnNumber_3_0= ruleEInt ) ) )? otherlv_4= 'player' ( ( ruleEString ) ) otherlv_6= 'players_hand' ( ( ruleEString ) ) otherlv_8= 'action_phase' ( (lv_action_phase_9_0= ruleActionPhase ) ) otherlv_10= 'buyphase' ( (lv_buyphase_11_0= ruleBuyPhase ) ) otherlv_12= 'cleanupphase' ( (lv_cleanupphase_13_0= ruleCleanupPhase ) ) otherlv_14= '}' )
            {
            // InternalMDL.g:1187:2: (otherlv_0= 'PlayersTurn' otherlv_1= '{' (otherlv_2= 'turnNumber' ( (lv_turnNumber_3_0= ruleEInt ) ) )? otherlv_4= 'player' ( ( ruleEString ) ) otherlv_6= 'players_hand' ( ( ruleEString ) ) otherlv_8= 'action_phase' ( (lv_action_phase_9_0= ruleActionPhase ) ) otherlv_10= 'buyphase' ( (lv_buyphase_11_0= ruleBuyPhase ) ) otherlv_12= 'cleanupphase' ( (lv_cleanupphase_13_0= ruleCleanupPhase ) ) otherlv_14= '}' )
            // InternalMDL.g:1188:3: otherlv_0= 'PlayersTurn' otherlv_1= '{' (otherlv_2= 'turnNumber' ( (lv_turnNumber_3_0= ruleEInt ) ) )? otherlv_4= 'player' ( ( ruleEString ) ) otherlv_6= 'players_hand' ( ( ruleEString ) ) otherlv_8= 'action_phase' ( (lv_action_phase_9_0= ruleActionPhase ) ) otherlv_10= 'buyphase' ( (lv_buyphase_11_0= ruleBuyPhase ) ) otherlv_12= 'cleanupphase' ( (lv_cleanupphase_13_0= ruleCleanupPhase ) ) otherlv_14= '}'
            {
            otherlv_0=(Token)match(input,38,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getPlayersTurnAccess().getPlayersTurnKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_43); 

            			newLeafNode(otherlv_1, grammarAccess.getPlayersTurnAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalMDL.g:1196:3: (otherlv_2= 'turnNumber' ( (lv_turnNumber_3_0= ruleEInt ) ) )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==39) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalMDL.g:1197:4: otherlv_2= 'turnNumber' ( (lv_turnNumber_3_0= ruleEInt ) )
                    {
                    otherlv_2=(Token)match(input,39,FOLLOW_33); 

                    				newLeafNode(otherlv_2, grammarAccess.getPlayersTurnAccess().getTurnNumberKeyword_2_0());
                    			
                    // InternalMDL.g:1201:4: ( (lv_turnNumber_3_0= ruleEInt ) )
                    // InternalMDL.g:1202:5: (lv_turnNumber_3_0= ruleEInt )
                    {
                    // InternalMDL.g:1202:5: (lv_turnNumber_3_0= ruleEInt )
                    // InternalMDL.g:1203:6: lv_turnNumber_3_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getPlayersTurnAccess().getTurnNumberEIntParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_44);
                    lv_turnNumber_3_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPlayersTurnRule());
                    						}
                    						set(
                    							current,
                    							"turnNumber",
                    							lv_turnNumber_3_0,
                    							"metaDominoLang.MDL.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_4=(Token)match(input,40,FOLLOW_31); 

            			newLeafNode(otherlv_4, grammarAccess.getPlayersTurnAccess().getPlayerKeyword_3());
            		
            // InternalMDL.g:1225:3: ( ( ruleEString ) )
            // InternalMDL.g:1226:4: ( ruleEString )
            {
            // InternalMDL.g:1226:4: ( ruleEString )
            // InternalMDL.g:1227:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPlayersTurnRule());
            					}
            				

            					newCompositeNode(grammarAccess.getPlayersTurnAccess().getPlayerPlayersPlayAreaCrossReference_4_0());
            				
            pushFollow(FOLLOW_39);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_6=(Token)match(input,36,FOLLOW_31); 

            			newLeafNode(otherlv_6, grammarAccess.getPlayersTurnAccess().getPlayers_handKeyword_5());
            		
            // InternalMDL.g:1245:3: ( ( ruleEString ) )
            // InternalMDL.g:1246:4: ( ruleEString )
            {
            // InternalMDL.g:1246:4: ( ruleEString )
            // InternalMDL.g:1247:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPlayersTurnRule());
            					}
            				

            					newCompositeNode(grammarAccess.getPlayersTurnAccess().getPlayers_handPlayersHandCrossReference_6_0());
            				
            pushFollow(FOLLOW_45);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_8=(Token)match(input,41,FOLLOW_46); 

            			newLeafNode(otherlv_8, grammarAccess.getPlayersTurnAccess().getAction_phaseKeyword_7());
            		
            // InternalMDL.g:1265:3: ( (lv_action_phase_9_0= ruleActionPhase ) )
            // InternalMDL.g:1266:4: (lv_action_phase_9_0= ruleActionPhase )
            {
            // InternalMDL.g:1266:4: (lv_action_phase_9_0= ruleActionPhase )
            // InternalMDL.g:1267:5: lv_action_phase_9_0= ruleActionPhase
            {

            					newCompositeNode(grammarAccess.getPlayersTurnAccess().getAction_phaseActionPhaseParserRuleCall_8_0());
            				
            pushFollow(FOLLOW_47);
            lv_action_phase_9_0=ruleActionPhase();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPlayersTurnRule());
            					}
            					set(
            						current,
            						"action_phase",
            						lv_action_phase_9_0,
            						"metaDominoLang.MDL.ActionPhase");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_10=(Token)match(input,42,FOLLOW_48); 

            			newLeafNode(otherlv_10, grammarAccess.getPlayersTurnAccess().getBuyphaseKeyword_9());
            		
            // InternalMDL.g:1288:3: ( (lv_buyphase_11_0= ruleBuyPhase ) )
            // InternalMDL.g:1289:4: (lv_buyphase_11_0= ruleBuyPhase )
            {
            // InternalMDL.g:1289:4: (lv_buyphase_11_0= ruleBuyPhase )
            // InternalMDL.g:1290:5: lv_buyphase_11_0= ruleBuyPhase
            {

            					newCompositeNode(grammarAccess.getPlayersTurnAccess().getBuyphaseBuyPhaseParserRuleCall_10_0());
            				
            pushFollow(FOLLOW_49);
            lv_buyphase_11_0=ruleBuyPhase();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPlayersTurnRule());
            					}
            					set(
            						current,
            						"buyphase",
            						lv_buyphase_11_0,
            						"metaDominoLang.MDL.BuyPhase");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_12=(Token)match(input,43,FOLLOW_50); 

            			newLeafNode(otherlv_12, grammarAccess.getPlayersTurnAccess().getCleanupphaseKeyword_11());
            		
            // InternalMDL.g:1311:3: ( (lv_cleanupphase_13_0= ruleCleanupPhase ) )
            // InternalMDL.g:1312:4: (lv_cleanupphase_13_0= ruleCleanupPhase )
            {
            // InternalMDL.g:1312:4: (lv_cleanupphase_13_0= ruleCleanupPhase )
            // InternalMDL.g:1313:5: lv_cleanupphase_13_0= ruleCleanupPhase
            {

            					newCompositeNode(grammarAccess.getPlayersTurnAccess().getCleanupphaseCleanupPhaseParserRuleCall_12_0());
            				
            pushFollow(FOLLOW_22);
            lv_cleanupphase_13_0=ruleCleanupPhase();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPlayersTurnRule());
            					}
            					set(
            						current,
            						"cleanupphase",
            						lv_cleanupphase_13_0,
            						"metaDominoLang.MDL.CleanupPhase");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_14=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_14, grammarAccess.getPlayersTurnAccess().getRightCurlyBracketKeyword_13());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePlayersTurn"


    // $ANTLR start "entryRuleTrashPile"
    // InternalMDL.g:1338:1: entryRuleTrashPile returns [EObject current=null] : iv_ruleTrashPile= ruleTrashPile EOF ;
    public final EObject entryRuleTrashPile() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTrashPile = null;


        try {
            // InternalMDL.g:1338:50: (iv_ruleTrashPile= ruleTrashPile EOF )
            // InternalMDL.g:1339:2: iv_ruleTrashPile= ruleTrashPile EOF
            {
             newCompositeNode(grammarAccess.getTrashPileRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTrashPile=ruleTrashPile();

            state._fsp--;

             current =iv_ruleTrashPile; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTrashPile"


    // $ANTLR start "ruleTrashPile"
    // InternalMDL.g:1345:1: ruleTrashPile returns [EObject current=null] : ( () otherlv_1= 'TrashPile' otherlv_2= '{' (otherlv_3= 'cards' otherlv_4= '{' ( (lv_cards_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_cards_7_0= ruleCard ) ) )* otherlv_8= '}' )? otherlv_9= '}' ) ;
    public final EObject ruleTrashPile() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        EObject lv_cards_5_0 = null;

        EObject lv_cards_7_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:1351:2: ( ( () otherlv_1= 'TrashPile' otherlv_2= '{' (otherlv_3= 'cards' otherlv_4= '{' ( (lv_cards_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_cards_7_0= ruleCard ) ) )* otherlv_8= '}' )? otherlv_9= '}' ) )
            // InternalMDL.g:1352:2: ( () otherlv_1= 'TrashPile' otherlv_2= '{' (otherlv_3= 'cards' otherlv_4= '{' ( (lv_cards_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_cards_7_0= ruleCard ) ) )* otherlv_8= '}' )? otherlv_9= '}' )
            {
            // InternalMDL.g:1352:2: ( () otherlv_1= 'TrashPile' otherlv_2= '{' (otherlv_3= 'cards' otherlv_4= '{' ( (lv_cards_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_cards_7_0= ruleCard ) ) )* otherlv_8= '}' )? otherlv_9= '}' )
            // InternalMDL.g:1353:3: () otherlv_1= 'TrashPile' otherlv_2= '{' (otherlv_3= 'cards' otherlv_4= '{' ( (lv_cards_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_cards_7_0= ruleCard ) ) )* otherlv_8= '}' )? otherlv_9= '}'
            {
            // InternalMDL.g:1353:3: ()
            // InternalMDL.g:1354:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getTrashPileAccess().getTrashPileAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,44,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getTrashPileAccess().getTrashPileKeyword_1());
            		
            otherlv_2=(Token)match(input,13,FOLLOW_51); 

            			newLeafNode(otherlv_2, grammarAccess.getTrashPileAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMDL.g:1368:3: (otherlv_3= 'cards' otherlv_4= '{' ( (lv_cards_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_cards_7_0= ruleCard ) ) )* otherlv_8= '}' )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==45) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalMDL.g:1369:4: otherlv_3= 'cards' otherlv_4= '{' ( (lv_cards_5_0= ruleCard ) ) (otherlv_6= ',' ( (lv_cards_7_0= ruleCard ) ) )* otherlv_8= '}'
                    {
                    otherlv_3=(Token)match(input,45,FOLLOW_5); 

                    				newLeafNode(otherlv_3, grammarAccess.getTrashPileAccess().getCardsKeyword_3_0());
                    			
                    otherlv_4=(Token)match(input,13,FOLLOW_24); 

                    				newLeafNode(otherlv_4, grammarAccess.getTrashPileAccess().getLeftCurlyBracketKeyword_3_1());
                    			
                    // InternalMDL.g:1377:4: ( (lv_cards_5_0= ruleCard ) )
                    // InternalMDL.g:1378:5: (lv_cards_5_0= ruleCard )
                    {
                    // InternalMDL.g:1378:5: (lv_cards_5_0= ruleCard )
                    // InternalMDL.g:1379:6: lv_cards_5_0= ruleCard
                    {

                    						newCompositeNode(grammarAccess.getTrashPileAccess().getCardsCardParserRuleCall_3_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_cards_5_0=ruleCard();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTrashPileRule());
                    						}
                    						add(
                    							current,
                    							"cards",
                    							lv_cards_5_0,
                    							"metaDominoLang.MDL.Card");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:1396:4: (otherlv_6= ',' ( (lv_cards_7_0= ruleCard ) ) )*
                    loop28:
                    do {
                        int alt28=2;
                        int LA28_0 = input.LA(1);

                        if ( (LA28_0==14) ) {
                            alt28=1;
                        }


                        switch (alt28) {
                    	case 1 :
                    	    // InternalMDL.g:1397:5: otherlv_6= ',' ( (lv_cards_7_0= ruleCard ) )
                    	    {
                    	    otherlv_6=(Token)match(input,14,FOLLOW_24); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getTrashPileAccess().getCommaKeyword_3_3_0());
                    	    				
                    	    // InternalMDL.g:1401:5: ( (lv_cards_7_0= ruleCard ) )
                    	    // InternalMDL.g:1402:6: (lv_cards_7_0= ruleCard )
                    	    {
                    	    // InternalMDL.g:1402:6: (lv_cards_7_0= ruleCard )
                    	    // InternalMDL.g:1403:7: lv_cards_7_0= ruleCard
                    	    {

                    	    							newCompositeNode(grammarAccess.getTrashPileAccess().getCardsCardParserRuleCall_3_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_cards_7_0=ruleCard();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getTrashPileRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"cards",
                    	    								lv_cards_7_0,
                    	    								"metaDominoLang.MDL.Card");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop28;
                        }
                    } while (true);

                    otherlv_8=(Token)match(input,15,FOLLOW_22); 

                    				newLeafNode(otherlv_8, grammarAccess.getTrashPileAccess().getRightCurlyBracketKeyword_3_4());
                    			

                    }
                    break;

            }

            otherlv_9=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getTrashPileAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTrashPile"


    // $ANTLR start "entryRuleSupplyPile"
    // InternalMDL.g:1434:1: entryRuleSupplyPile returns [EObject current=null] : iv_ruleSupplyPile= ruleSupplyPile EOF ;
    public final EObject entryRuleSupplyPile() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSupplyPile = null;


        try {
            // InternalMDL.g:1434:51: (iv_ruleSupplyPile= ruleSupplyPile EOF )
            // InternalMDL.g:1435:2: iv_ruleSupplyPile= ruleSupplyPile EOF
            {
             newCompositeNode(grammarAccess.getSupplyPileRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSupplyPile=ruleSupplyPile();

            state._fsp--;

             current =iv_ruleSupplyPile; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSupplyPile"


    // $ANTLR start "ruleSupplyPile"
    // InternalMDL.g:1441:1: ruleSupplyPile returns [EObject current=null] : (otherlv_0= 'SupplyPile' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' ) ;
    public final EObject ruleSupplyPile() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        AntlrDatatypeRuleToken lv_cardsNumber_3_0 = null;

        EObject lv_cards_6_0 = null;

        EObject lv_cards_8_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:1447:2: ( (otherlv_0= 'SupplyPile' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' ) )
            // InternalMDL.g:1448:2: (otherlv_0= 'SupplyPile' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' )
            {
            // InternalMDL.g:1448:2: (otherlv_0= 'SupplyPile' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' )
            // InternalMDL.g:1449:3: otherlv_0= 'SupplyPile' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}'
            {
            otherlv_0=(Token)match(input,46,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getSupplyPileAccess().getSupplyPileKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_52); 

            			newLeafNode(otherlv_1, grammarAccess.getSupplyPileAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,47,FOLLOW_33); 

            			newLeafNode(otherlv_2, grammarAccess.getSupplyPileAccess().getCardsNumberKeyword_2());
            		
            // InternalMDL.g:1461:3: ( (lv_cardsNumber_3_0= ruleEInt ) )
            // InternalMDL.g:1462:4: (lv_cardsNumber_3_0= ruleEInt )
            {
            // InternalMDL.g:1462:4: (lv_cardsNumber_3_0= ruleEInt )
            // InternalMDL.g:1463:5: lv_cardsNumber_3_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getSupplyPileAccess().getCardsNumberEIntParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_51);
            lv_cardsNumber_3_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getSupplyPileRule());
            					}
            					set(
            						current,
            						"cardsNumber",
            						lv_cardsNumber_3_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMDL.g:1480:3: (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==45) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalMDL.g:1481:4: otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}'
                    {
                    otherlv_4=(Token)match(input,45,FOLLOW_5); 

                    				newLeafNode(otherlv_4, grammarAccess.getSupplyPileAccess().getCardsKeyword_4_0());
                    			
                    otherlv_5=(Token)match(input,13,FOLLOW_24); 

                    				newLeafNode(otherlv_5, grammarAccess.getSupplyPileAccess().getLeftCurlyBracketKeyword_4_1());
                    			
                    // InternalMDL.g:1489:4: ( (lv_cards_6_0= ruleCard ) )
                    // InternalMDL.g:1490:5: (lv_cards_6_0= ruleCard )
                    {
                    // InternalMDL.g:1490:5: (lv_cards_6_0= ruleCard )
                    // InternalMDL.g:1491:6: lv_cards_6_0= ruleCard
                    {

                    						newCompositeNode(grammarAccess.getSupplyPileAccess().getCardsCardParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_cards_6_0=ruleCard();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getSupplyPileRule());
                    						}
                    						add(
                    							current,
                    							"cards",
                    							lv_cards_6_0,
                    							"metaDominoLang.MDL.Card");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:1508:4: (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )*
                    loop30:
                    do {
                        int alt30=2;
                        int LA30_0 = input.LA(1);

                        if ( (LA30_0==14) ) {
                            alt30=1;
                        }


                        switch (alt30) {
                    	case 1 :
                    	    // InternalMDL.g:1509:5: otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) )
                    	    {
                    	    otherlv_7=(Token)match(input,14,FOLLOW_24); 

                    	    					newLeafNode(otherlv_7, grammarAccess.getSupplyPileAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalMDL.g:1513:5: ( (lv_cards_8_0= ruleCard ) )
                    	    // InternalMDL.g:1514:6: (lv_cards_8_0= ruleCard )
                    	    {
                    	    // InternalMDL.g:1514:6: (lv_cards_8_0= ruleCard )
                    	    // InternalMDL.g:1515:7: lv_cards_8_0= ruleCard
                    	    {

                    	    							newCompositeNode(grammarAccess.getSupplyPileAccess().getCardsCardParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_cards_8_0=ruleCard();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getSupplyPileRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"cards",
                    	    								lv_cards_8_0,
                    	    								"metaDominoLang.MDL.Card");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop30;
                        }
                    } while (true);

                    otherlv_9=(Token)match(input,15,FOLLOW_22); 

                    				newLeafNode(otherlv_9, grammarAccess.getSupplyPileAccess().getRightCurlyBracketKeyword_4_4());
                    			

                    }
                    break;

            }

            otherlv_10=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_10, grammarAccess.getSupplyPileAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSupplyPile"


    // $ANTLR start "entryRuleCardsPlayedThisTurn"
    // InternalMDL.g:1546:1: entryRuleCardsPlayedThisTurn returns [EObject current=null] : iv_ruleCardsPlayedThisTurn= ruleCardsPlayedThisTurn EOF ;
    public final EObject entryRuleCardsPlayedThisTurn() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCardsPlayedThisTurn = null;


        try {
            // InternalMDL.g:1546:60: (iv_ruleCardsPlayedThisTurn= ruleCardsPlayedThisTurn EOF )
            // InternalMDL.g:1547:2: iv_ruleCardsPlayedThisTurn= ruleCardsPlayedThisTurn EOF
            {
             newCompositeNode(grammarAccess.getCardsPlayedThisTurnRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCardsPlayedThisTurn=ruleCardsPlayedThisTurn();

            state._fsp--;

             current =iv_ruleCardsPlayedThisTurn; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCardsPlayedThisTurn"


    // $ANTLR start "ruleCardsPlayedThisTurn"
    // InternalMDL.g:1553:1: ruleCardsPlayedThisTurn returns [EObject current=null] : (otherlv_0= 'CardsPlayedThisTurn' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' ) ;
    public final EObject ruleCardsPlayedThisTurn() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        AntlrDatatypeRuleToken lv_cardsNumber_3_0 = null;

        EObject lv_cards_6_0 = null;

        EObject lv_cards_8_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:1559:2: ( (otherlv_0= 'CardsPlayedThisTurn' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' ) )
            // InternalMDL.g:1560:2: (otherlv_0= 'CardsPlayedThisTurn' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' )
            {
            // InternalMDL.g:1560:2: (otherlv_0= 'CardsPlayedThisTurn' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' )
            // InternalMDL.g:1561:3: otherlv_0= 'CardsPlayedThisTurn' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}'
            {
            otherlv_0=(Token)match(input,48,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getCardsPlayedThisTurnAccess().getCardsPlayedThisTurnKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_52); 

            			newLeafNode(otherlv_1, grammarAccess.getCardsPlayedThisTurnAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,47,FOLLOW_33); 

            			newLeafNode(otherlv_2, grammarAccess.getCardsPlayedThisTurnAccess().getCardsNumberKeyword_2());
            		
            // InternalMDL.g:1573:3: ( (lv_cardsNumber_3_0= ruleEInt ) )
            // InternalMDL.g:1574:4: (lv_cardsNumber_3_0= ruleEInt )
            {
            // InternalMDL.g:1574:4: (lv_cardsNumber_3_0= ruleEInt )
            // InternalMDL.g:1575:5: lv_cardsNumber_3_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getCardsPlayedThisTurnAccess().getCardsNumberEIntParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_51);
            lv_cardsNumber_3_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getCardsPlayedThisTurnRule());
            					}
            					set(
            						current,
            						"cardsNumber",
            						lv_cardsNumber_3_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMDL.g:1592:3: (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==45) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalMDL.g:1593:4: otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}'
                    {
                    otherlv_4=(Token)match(input,45,FOLLOW_5); 

                    				newLeafNode(otherlv_4, grammarAccess.getCardsPlayedThisTurnAccess().getCardsKeyword_4_0());
                    			
                    otherlv_5=(Token)match(input,13,FOLLOW_24); 

                    				newLeafNode(otherlv_5, grammarAccess.getCardsPlayedThisTurnAccess().getLeftCurlyBracketKeyword_4_1());
                    			
                    // InternalMDL.g:1601:4: ( (lv_cards_6_0= ruleCard ) )
                    // InternalMDL.g:1602:5: (lv_cards_6_0= ruleCard )
                    {
                    // InternalMDL.g:1602:5: (lv_cards_6_0= ruleCard )
                    // InternalMDL.g:1603:6: lv_cards_6_0= ruleCard
                    {

                    						newCompositeNode(grammarAccess.getCardsPlayedThisTurnAccess().getCardsCardParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_cards_6_0=ruleCard();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCardsPlayedThisTurnRule());
                    						}
                    						add(
                    							current,
                    							"cards",
                    							lv_cards_6_0,
                    							"metaDominoLang.MDL.Card");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:1620:4: (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )*
                    loop32:
                    do {
                        int alt32=2;
                        int LA32_0 = input.LA(1);

                        if ( (LA32_0==14) ) {
                            alt32=1;
                        }


                        switch (alt32) {
                    	case 1 :
                    	    // InternalMDL.g:1621:5: otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) )
                    	    {
                    	    otherlv_7=(Token)match(input,14,FOLLOW_24); 

                    	    					newLeafNode(otherlv_7, grammarAccess.getCardsPlayedThisTurnAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalMDL.g:1625:5: ( (lv_cards_8_0= ruleCard ) )
                    	    // InternalMDL.g:1626:6: (lv_cards_8_0= ruleCard )
                    	    {
                    	    // InternalMDL.g:1626:6: (lv_cards_8_0= ruleCard )
                    	    // InternalMDL.g:1627:7: lv_cards_8_0= ruleCard
                    	    {

                    	    							newCompositeNode(grammarAccess.getCardsPlayedThisTurnAccess().getCardsCardParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_cards_8_0=ruleCard();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getCardsPlayedThisTurnRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"cards",
                    	    								lv_cards_8_0,
                    	    								"metaDominoLang.MDL.Card");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop32;
                        }
                    } while (true);

                    otherlv_9=(Token)match(input,15,FOLLOW_22); 

                    				newLeafNode(otherlv_9, grammarAccess.getCardsPlayedThisTurnAccess().getRightCurlyBracketKeyword_4_4());
                    			

                    }
                    break;

            }

            otherlv_10=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_10, grammarAccess.getCardsPlayedThisTurnAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCardsPlayedThisTurn"


    // $ANTLR start "entryRulePlayersDeck"
    // InternalMDL.g:1658:1: entryRulePlayersDeck returns [EObject current=null] : iv_rulePlayersDeck= rulePlayersDeck EOF ;
    public final EObject entryRulePlayersDeck() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePlayersDeck = null;


        try {
            // InternalMDL.g:1658:52: (iv_rulePlayersDeck= rulePlayersDeck EOF )
            // InternalMDL.g:1659:2: iv_rulePlayersDeck= rulePlayersDeck EOF
            {
             newCompositeNode(grammarAccess.getPlayersDeckRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePlayersDeck=rulePlayersDeck();

            state._fsp--;

             current =iv_rulePlayersDeck; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePlayersDeck"


    // $ANTLR start "rulePlayersDeck"
    // InternalMDL.g:1665:1: rulePlayersDeck returns [EObject current=null] : (otherlv_0= 'PlayersDeck' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' ) ;
    public final EObject rulePlayersDeck() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        AntlrDatatypeRuleToken lv_cardsNumber_3_0 = null;

        EObject lv_cards_6_0 = null;

        EObject lv_cards_8_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:1671:2: ( (otherlv_0= 'PlayersDeck' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' ) )
            // InternalMDL.g:1672:2: (otherlv_0= 'PlayersDeck' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' )
            {
            // InternalMDL.g:1672:2: (otherlv_0= 'PlayersDeck' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' )
            // InternalMDL.g:1673:3: otherlv_0= 'PlayersDeck' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}'
            {
            otherlv_0=(Token)match(input,49,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getPlayersDeckAccess().getPlayersDeckKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_52); 

            			newLeafNode(otherlv_1, grammarAccess.getPlayersDeckAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,47,FOLLOW_33); 

            			newLeafNode(otherlv_2, grammarAccess.getPlayersDeckAccess().getCardsNumberKeyword_2());
            		
            // InternalMDL.g:1685:3: ( (lv_cardsNumber_3_0= ruleEInt ) )
            // InternalMDL.g:1686:4: (lv_cardsNumber_3_0= ruleEInt )
            {
            // InternalMDL.g:1686:4: (lv_cardsNumber_3_0= ruleEInt )
            // InternalMDL.g:1687:5: lv_cardsNumber_3_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getPlayersDeckAccess().getCardsNumberEIntParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_51);
            lv_cardsNumber_3_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPlayersDeckRule());
            					}
            					set(
            						current,
            						"cardsNumber",
            						lv_cardsNumber_3_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMDL.g:1704:3: (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==45) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalMDL.g:1705:4: otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}'
                    {
                    otherlv_4=(Token)match(input,45,FOLLOW_5); 

                    				newLeafNode(otherlv_4, grammarAccess.getPlayersDeckAccess().getCardsKeyword_4_0());
                    			
                    otherlv_5=(Token)match(input,13,FOLLOW_24); 

                    				newLeafNode(otherlv_5, grammarAccess.getPlayersDeckAccess().getLeftCurlyBracketKeyword_4_1());
                    			
                    // InternalMDL.g:1713:4: ( (lv_cards_6_0= ruleCard ) )
                    // InternalMDL.g:1714:5: (lv_cards_6_0= ruleCard )
                    {
                    // InternalMDL.g:1714:5: (lv_cards_6_0= ruleCard )
                    // InternalMDL.g:1715:6: lv_cards_6_0= ruleCard
                    {

                    						newCompositeNode(grammarAccess.getPlayersDeckAccess().getCardsCardParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_cards_6_0=ruleCard();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPlayersDeckRule());
                    						}
                    						add(
                    							current,
                    							"cards",
                    							lv_cards_6_0,
                    							"metaDominoLang.MDL.Card");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:1732:4: (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )*
                    loop34:
                    do {
                        int alt34=2;
                        int LA34_0 = input.LA(1);

                        if ( (LA34_0==14) ) {
                            alt34=1;
                        }


                        switch (alt34) {
                    	case 1 :
                    	    // InternalMDL.g:1733:5: otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) )
                    	    {
                    	    otherlv_7=(Token)match(input,14,FOLLOW_24); 

                    	    					newLeafNode(otherlv_7, grammarAccess.getPlayersDeckAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalMDL.g:1737:5: ( (lv_cards_8_0= ruleCard ) )
                    	    // InternalMDL.g:1738:6: (lv_cards_8_0= ruleCard )
                    	    {
                    	    // InternalMDL.g:1738:6: (lv_cards_8_0= ruleCard )
                    	    // InternalMDL.g:1739:7: lv_cards_8_0= ruleCard
                    	    {

                    	    							newCompositeNode(grammarAccess.getPlayersDeckAccess().getCardsCardParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_cards_8_0=ruleCard();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getPlayersDeckRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"cards",
                    	    								lv_cards_8_0,
                    	    								"metaDominoLang.MDL.Card");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop34;
                        }
                    } while (true);

                    otherlv_9=(Token)match(input,15,FOLLOW_22); 

                    				newLeafNode(otherlv_9, grammarAccess.getPlayersDeckAccess().getRightCurlyBracketKeyword_4_4());
                    			

                    }
                    break;

            }

            otherlv_10=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_10, grammarAccess.getPlayersDeckAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePlayersDeck"


    // $ANTLR start "entryRulePlayersHand"
    // InternalMDL.g:1770:1: entryRulePlayersHand returns [EObject current=null] : iv_rulePlayersHand= rulePlayersHand EOF ;
    public final EObject entryRulePlayersHand() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePlayersHand = null;


        try {
            // InternalMDL.g:1770:52: (iv_rulePlayersHand= rulePlayersHand EOF )
            // InternalMDL.g:1771:2: iv_rulePlayersHand= rulePlayersHand EOF
            {
             newCompositeNode(grammarAccess.getPlayersHandRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePlayersHand=rulePlayersHand();

            state._fsp--;

             current =iv_rulePlayersHand; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePlayersHand"


    // $ANTLR start "rulePlayersHand"
    // InternalMDL.g:1777:1: rulePlayersHand returns [EObject current=null] : (otherlv_0= 'PlayersHand' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' ) ;
    public final EObject rulePlayersHand() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        AntlrDatatypeRuleToken lv_cardsNumber_3_0 = null;

        EObject lv_cards_6_0 = null;

        EObject lv_cards_8_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:1783:2: ( (otherlv_0= 'PlayersHand' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' ) )
            // InternalMDL.g:1784:2: (otherlv_0= 'PlayersHand' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' )
            {
            // InternalMDL.g:1784:2: (otherlv_0= 'PlayersHand' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' )
            // InternalMDL.g:1785:3: otherlv_0= 'PlayersHand' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}'
            {
            otherlv_0=(Token)match(input,50,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getPlayersHandAccess().getPlayersHandKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_52); 

            			newLeafNode(otherlv_1, grammarAccess.getPlayersHandAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,47,FOLLOW_33); 

            			newLeafNode(otherlv_2, grammarAccess.getPlayersHandAccess().getCardsNumberKeyword_2());
            		
            // InternalMDL.g:1797:3: ( (lv_cardsNumber_3_0= ruleEInt ) )
            // InternalMDL.g:1798:4: (lv_cardsNumber_3_0= ruleEInt )
            {
            // InternalMDL.g:1798:4: (lv_cardsNumber_3_0= ruleEInt )
            // InternalMDL.g:1799:5: lv_cardsNumber_3_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getPlayersHandAccess().getCardsNumberEIntParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_51);
            lv_cardsNumber_3_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPlayersHandRule());
            					}
            					set(
            						current,
            						"cardsNumber",
            						lv_cardsNumber_3_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMDL.g:1816:3: (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==45) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalMDL.g:1817:4: otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}'
                    {
                    otherlv_4=(Token)match(input,45,FOLLOW_5); 

                    				newLeafNode(otherlv_4, grammarAccess.getPlayersHandAccess().getCardsKeyword_4_0());
                    			
                    otherlv_5=(Token)match(input,13,FOLLOW_24); 

                    				newLeafNode(otherlv_5, grammarAccess.getPlayersHandAccess().getLeftCurlyBracketKeyword_4_1());
                    			
                    // InternalMDL.g:1825:4: ( (lv_cards_6_0= ruleCard ) )
                    // InternalMDL.g:1826:5: (lv_cards_6_0= ruleCard )
                    {
                    // InternalMDL.g:1826:5: (lv_cards_6_0= ruleCard )
                    // InternalMDL.g:1827:6: lv_cards_6_0= ruleCard
                    {

                    						newCompositeNode(grammarAccess.getPlayersHandAccess().getCardsCardParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_cards_6_0=ruleCard();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getPlayersHandRule());
                    						}
                    						add(
                    							current,
                    							"cards",
                    							lv_cards_6_0,
                    							"metaDominoLang.MDL.Card");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:1844:4: (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )*
                    loop36:
                    do {
                        int alt36=2;
                        int LA36_0 = input.LA(1);

                        if ( (LA36_0==14) ) {
                            alt36=1;
                        }


                        switch (alt36) {
                    	case 1 :
                    	    // InternalMDL.g:1845:5: otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) )
                    	    {
                    	    otherlv_7=(Token)match(input,14,FOLLOW_24); 

                    	    					newLeafNode(otherlv_7, grammarAccess.getPlayersHandAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalMDL.g:1849:5: ( (lv_cards_8_0= ruleCard ) )
                    	    // InternalMDL.g:1850:6: (lv_cards_8_0= ruleCard )
                    	    {
                    	    // InternalMDL.g:1850:6: (lv_cards_8_0= ruleCard )
                    	    // InternalMDL.g:1851:7: lv_cards_8_0= ruleCard
                    	    {

                    	    							newCompositeNode(grammarAccess.getPlayersHandAccess().getCardsCardParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_cards_8_0=ruleCard();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getPlayersHandRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"cards",
                    	    								lv_cards_8_0,
                    	    								"metaDominoLang.MDL.Card");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop36;
                        }
                    } while (true);

                    otherlv_9=(Token)match(input,15,FOLLOW_22); 

                    				newLeafNode(otherlv_9, grammarAccess.getPlayersHandAccess().getRightCurlyBracketKeyword_4_4());
                    			

                    }
                    break;

            }

            otherlv_10=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_10, grammarAccess.getPlayersHandAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePlayersHand"


    // $ANTLR start "entryRuleDiscardPile"
    // InternalMDL.g:1882:1: entryRuleDiscardPile returns [EObject current=null] : iv_ruleDiscardPile= ruleDiscardPile EOF ;
    public final EObject entryRuleDiscardPile() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDiscardPile = null;


        try {
            // InternalMDL.g:1882:52: (iv_ruleDiscardPile= ruleDiscardPile EOF )
            // InternalMDL.g:1883:2: iv_ruleDiscardPile= ruleDiscardPile EOF
            {
             newCompositeNode(grammarAccess.getDiscardPileRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDiscardPile=ruleDiscardPile();

            state._fsp--;

             current =iv_ruleDiscardPile; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDiscardPile"


    // $ANTLR start "ruleDiscardPile"
    // InternalMDL.g:1889:1: ruleDiscardPile returns [EObject current=null] : (otherlv_0= 'DiscardPile' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' ) ;
    public final EObject ruleDiscardPile() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        AntlrDatatypeRuleToken lv_cardsNumber_3_0 = null;

        EObject lv_cards_6_0 = null;

        EObject lv_cards_8_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:1895:2: ( (otherlv_0= 'DiscardPile' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' ) )
            // InternalMDL.g:1896:2: (otherlv_0= 'DiscardPile' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' )
            {
            // InternalMDL.g:1896:2: (otherlv_0= 'DiscardPile' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}' )
            // InternalMDL.g:1897:3: otherlv_0= 'DiscardPile' otherlv_1= '{' otherlv_2= 'cardsNumber' ( (lv_cardsNumber_3_0= ruleEInt ) ) (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )? otherlv_10= '}'
            {
            otherlv_0=(Token)match(input,51,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getDiscardPileAccess().getDiscardPileKeyword_0());
            		
            otherlv_1=(Token)match(input,13,FOLLOW_52); 

            			newLeafNode(otherlv_1, grammarAccess.getDiscardPileAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,47,FOLLOW_33); 

            			newLeafNode(otherlv_2, grammarAccess.getDiscardPileAccess().getCardsNumberKeyword_2());
            		
            // InternalMDL.g:1909:3: ( (lv_cardsNumber_3_0= ruleEInt ) )
            // InternalMDL.g:1910:4: (lv_cardsNumber_3_0= ruleEInt )
            {
            // InternalMDL.g:1910:4: (lv_cardsNumber_3_0= ruleEInt )
            // InternalMDL.g:1911:5: lv_cardsNumber_3_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getDiscardPileAccess().getCardsNumberEIntParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_51);
            lv_cardsNumber_3_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDiscardPileRule());
            					}
            					set(
            						current,
            						"cardsNumber",
            						lv_cardsNumber_3_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMDL.g:1928:3: (otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}' )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==45) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalMDL.g:1929:4: otherlv_4= 'cards' otherlv_5= '{' ( (lv_cards_6_0= ruleCard ) ) (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )* otherlv_9= '}'
                    {
                    otherlv_4=(Token)match(input,45,FOLLOW_5); 

                    				newLeafNode(otherlv_4, grammarAccess.getDiscardPileAccess().getCardsKeyword_4_0());
                    			
                    otherlv_5=(Token)match(input,13,FOLLOW_24); 

                    				newLeafNode(otherlv_5, grammarAccess.getDiscardPileAccess().getLeftCurlyBracketKeyword_4_1());
                    			
                    // InternalMDL.g:1937:4: ( (lv_cards_6_0= ruleCard ) )
                    // InternalMDL.g:1938:5: (lv_cards_6_0= ruleCard )
                    {
                    // InternalMDL.g:1938:5: (lv_cards_6_0= ruleCard )
                    // InternalMDL.g:1939:6: lv_cards_6_0= ruleCard
                    {

                    						newCompositeNode(grammarAccess.getDiscardPileAccess().getCardsCardParserRuleCall_4_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_cards_6_0=ruleCard();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getDiscardPileRule());
                    						}
                    						add(
                    							current,
                    							"cards",
                    							lv_cards_6_0,
                    							"metaDominoLang.MDL.Card");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:1956:4: (otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) ) )*
                    loop38:
                    do {
                        int alt38=2;
                        int LA38_0 = input.LA(1);

                        if ( (LA38_0==14) ) {
                            alt38=1;
                        }


                        switch (alt38) {
                    	case 1 :
                    	    // InternalMDL.g:1957:5: otherlv_7= ',' ( (lv_cards_8_0= ruleCard ) )
                    	    {
                    	    otherlv_7=(Token)match(input,14,FOLLOW_24); 

                    	    					newLeafNode(otherlv_7, grammarAccess.getDiscardPileAccess().getCommaKeyword_4_3_0());
                    	    				
                    	    // InternalMDL.g:1961:5: ( (lv_cards_8_0= ruleCard ) )
                    	    // InternalMDL.g:1962:6: (lv_cards_8_0= ruleCard )
                    	    {
                    	    // InternalMDL.g:1962:6: (lv_cards_8_0= ruleCard )
                    	    // InternalMDL.g:1963:7: lv_cards_8_0= ruleCard
                    	    {

                    	    							newCompositeNode(grammarAccess.getDiscardPileAccess().getCardsCardParserRuleCall_4_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_cards_8_0=ruleCard();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getDiscardPileRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"cards",
                    	    								lv_cards_8_0,
                    	    								"metaDominoLang.MDL.Card");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop38;
                        }
                    } while (true);

                    otherlv_9=(Token)match(input,15,FOLLOW_22); 

                    				newLeafNode(otherlv_9, grammarAccess.getDiscardPileAccess().getRightCurlyBracketKeyword_4_4());
                    			

                    }
                    break;

            }

            otherlv_10=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_10, grammarAccess.getDiscardPileAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDiscardPile"


    // $ANTLR start "entryRuleEString"
    // InternalMDL.g:1994:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalMDL.g:1994:47: (iv_ruleEString= ruleEString EOF )
            // InternalMDL.g:1995:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalMDL.g:2001:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalMDL.g:2007:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalMDL.g:2008:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalMDL.g:2008:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==RULE_STRING) ) {
                alt40=1;
            }
            else if ( (LA40_0==RULE_ID) ) {
                alt40=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 40, 0, input);

                throw nvae;
            }
            switch (alt40) {
                case 1 :
                    // InternalMDL.g:2009:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMDL.g:2017:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleEInt"
    // InternalMDL.g:2028:1: entryRuleEInt returns [String current=null] : iv_ruleEInt= ruleEInt EOF ;
    public final String entryRuleEInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEInt = null;


        try {
            // InternalMDL.g:2028:44: (iv_ruleEInt= ruleEInt EOF )
            // InternalMDL.g:2029:2: iv_ruleEInt= ruleEInt EOF
            {
             newCompositeNode(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEInt=ruleEInt();

            state._fsp--;

             current =iv_ruleEInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalMDL.g:2035:1: ruleEInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? this_INT_1= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleEInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;


        	enterRule();

        try {
            // InternalMDL.g:2041:2: ( ( (kw= '-' )? this_INT_1= RULE_INT ) )
            // InternalMDL.g:2042:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            {
            // InternalMDL.g:2042:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            // InternalMDL.g:2043:3: (kw= '-' )? this_INT_1= RULE_INT
            {
            // InternalMDL.g:2043:3: (kw= '-' )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==52) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalMDL.g:2044:4: kw= '-'
                    {
                    kw=(Token)match(input,52,FOLLOW_53); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEIntAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            this_INT_1=(Token)match(input,RULE_INT,FOLLOW_2); 

            			current.merge(this_INT_1);
            		

            			newLeafNode(this_INT_1, grammarAccess.getEIntAccess().getINTTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleTreasureCard"
    // InternalMDL.g:2061:1: entryRuleTreasureCard returns [EObject current=null] : iv_ruleTreasureCard= ruleTreasureCard EOF ;
    public final EObject entryRuleTreasureCard() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTreasureCard = null;


        try {
            // InternalMDL.g:2061:53: (iv_ruleTreasureCard= ruleTreasureCard EOF )
            // InternalMDL.g:2062:2: iv_ruleTreasureCard= ruleTreasureCard EOF
            {
             newCompositeNode(grammarAccess.getTreasureCardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTreasureCard=ruleTreasureCard();

            state._fsp--;

             current =iv_ruleTreasureCard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTreasureCard"


    // $ANTLR start "ruleTreasureCard"
    // InternalMDL.g:2068:1: ruleTreasureCard returns [EObject current=null] : ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'TreasureCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'value' ( (lv_value_8_0= ruleEInt ) ) otherlv_9= '}' ) ;
    public final EObject ruleTreasureCard() throws RecognitionException {
        EObject current = null;

        Token lv_isPubliclyVisible_0_0=null;
        Token lv_isVisibleToOwner_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        AntlrDatatypeRuleToken lv_name_3_0 = null;

        AntlrDatatypeRuleToken lv_cost_6_0 = null;

        AntlrDatatypeRuleToken lv_value_8_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:2074:2: ( ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'TreasureCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'value' ( (lv_value_8_0= ruleEInt ) ) otherlv_9= '}' ) )
            // InternalMDL.g:2075:2: ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'TreasureCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'value' ( (lv_value_8_0= ruleEInt ) ) otherlv_9= '}' )
            {
            // InternalMDL.g:2075:2: ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'TreasureCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'value' ( (lv_value_8_0= ruleEInt ) ) otherlv_9= '}' )
            // InternalMDL.g:2076:3: ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'TreasureCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'value' ( (lv_value_8_0= ruleEInt ) ) otherlv_9= '}'
            {
            // InternalMDL.g:2076:3: ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==53) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalMDL.g:2077:4: (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' )
                    {
                    // InternalMDL.g:2077:4: (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' )
                    // InternalMDL.g:2078:5: lv_isPubliclyVisible_0_0= 'isPubliclyVisible'
                    {
                    lv_isPubliclyVisible_0_0=(Token)match(input,53,FOLLOW_54); 

                    					newLeafNode(lv_isPubliclyVisible_0_0, grammarAccess.getTreasureCardAccess().getIsPubliclyVisibleIsPubliclyVisibleKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getTreasureCardRule());
                    					}
                    					setWithLastConsumed(current, "isPubliclyVisible", lv_isPubliclyVisible_0_0 != null, "isPubliclyVisible");
                    				

                    }


                    }
                    break;

            }

            // InternalMDL.g:2090:3: ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==54) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalMDL.g:2091:4: (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' )
                    {
                    // InternalMDL.g:2091:4: (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' )
                    // InternalMDL.g:2092:5: lv_isVisibleToOwner_1_0= 'isVisibleToOwner'
                    {
                    lv_isVisibleToOwner_1_0=(Token)match(input,54,FOLLOW_55); 

                    					newLeafNode(lv_isVisibleToOwner_1_0, grammarAccess.getTreasureCardAccess().getIsVisibleToOwnerIsVisibleToOwnerKeyword_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getTreasureCardRule());
                    					}
                    					setWithLastConsumed(current, "isVisibleToOwner", lv_isVisibleToOwner_1_0 != null, "isVisibleToOwner");
                    				

                    }


                    }
                    break;

            }

            otherlv_2=(Token)match(input,55,FOLLOW_31); 

            			newLeafNode(otherlv_2, grammarAccess.getTreasureCardAccess().getTreasureCardKeyword_2());
            		
            // InternalMDL.g:2108:3: ( (lv_name_3_0= ruleEString ) )
            // InternalMDL.g:2109:4: (lv_name_3_0= ruleEString )
            {
            // InternalMDL.g:2109:4: (lv_name_3_0= ruleEString )
            // InternalMDL.g:2110:5: lv_name_3_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getTreasureCardAccess().getNameEStringParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_5);
            lv_name_3_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTreasureCardRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_3_0,
            						"metaDominoLang.MDL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_56); 

            			newLeafNode(otherlv_4, grammarAccess.getTreasureCardAccess().getLeftCurlyBracketKeyword_4());
            		
            otherlv_5=(Token)match(input,56,FOLLOW_33); 

            			newLeafNode(otherlv_5, grammarAccess.getTreasureCardAccess().getCostKeyword_5());
            		
            // InternalMDL.g:2135:3: ( (lv_cost_6_0= ruleEInt ) )
            // InternalMDL.g:2136:4: (lv_cost_6_0= ruleEInt )
            {
            // InternalMDL.g:2136:4: (lv_cost_6_0= ruleEInt )
            // InternalMDL.g:2137:5: lv_cost_6_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getTreasureCardAccess().getCostEIntParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_57);
            lv_cost_6_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTreasureCardRule());
            					}
            					set(
            						current,
            						"cost",
            						lv_cost_6_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_7=(Token)match(input,57,FOLLOW_33); 

            			newLeafNode(otherlv_7, grammarAccess.getTreasureCardAccess().getValueKeyword_7());
            		
            // InternalMDL.g:2158:3: ( (lv_value_8_0= ruleEInt ) )
            // InternalMDL.g:2159:4: (lv_value_8_0= ruleEInt )
            {
            // InternalMDL.g:2159:4: (lv_value_8_0= ruleEInt )
            // InternalMDL.g:2160:5: lv_value_8_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getTreasureCardAccess().getValueEIntParserRuleCall_8_0());
            				
            pushFollow(FOLLOW_22);
            lv_value_8_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTreasureCardRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_8_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_9=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getTreasureCardAccess().getRightCurlyBracketKeyword_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTreasureCard"


    // $ANTLR start "entryRuleVictoryCard"
    // InternalMDL.g:2185:1: entryRuleVictoryCard returns [EObject current=null] : iv_ruleVictoryCard= ruleVictoryCard EOF ;
    public final EObject entryRuleVictoryCard() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVictoryCard = null;


        try {
            // InternalMDL.g:2185:52: (iv_ruleVictoryCard= ruleVictoryCard EOF )
            // InternalMDL.g:2186:2: iv_ruleVictoryCard= ruleVictoryCard EOF
            {
             newCompositeNode(grammarAccess.getVictoryCardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVictoryCard=ruleVictoryCard();

            state._fsp--;

             current =iv_ruleVictoryCard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVictoryCard"


    // $ANTLR start "ruleVictoryCard"
    // InternalMDL.g:2192:1: ruleVictoryCard returns [EObject current=null] : ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'VictoryCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'victoryPoints' ( (lv_victoryPoints_8_0= ruleEInt ) ) otherlv_9= '}' ) ;
    public final EObject ruleVictoryCard() throws RecognitionException {
        EObject current = null;

        Token lv_isPubliclyVisible_0_0=null;
        Token lv_isVisibleToOwner_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        AntlrDatatypeRuleToken lv_name_3_0 = null;

        AntlrDatatypeRuleToken lv_cost_6_0 = null;

        AntlrDatatypeRuleToken lv_victoryPoints_8_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:2198:2: ( ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'VictoryCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'victoryPoints' ( (lv_victoryPoints_8_0= ruleEInt ) ) otherlv_9= '}' ) )
            // InternalMDL.g:2199:2: ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'VictoryCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'victoryPoints' ( (lv_victoryPoints_8_0= ruleEInt ) ) otherlv_9= '}' )
            {
            // InternalMDL.g:2199:2: ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'VictoryCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'victoryPoints' ( (lv_victoryPoints_8_0= ruleEInt ) ) otherlv_9= '}' )
            // InternalMDL.g:2200:3: ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'VictoryCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'victoryPoints' ( (lv_victoryPoints_8_0= ruleEInt ) ) otherlv_9= '}'
            {
            // InternalMDL.g:2200:3: ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==53) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalMDL.g:2201:4: (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' )
                    {
                    // InternalMDL.g:2201:4: (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' )
                    // InternalMDL.g:2202:5: lv_isPubliclyVisible_0_0= 'isPubliclyVisible'
                    {
                    lv_isPubliclyVisible_0_0=(Token)match(input,53,FOLLOW_58); 

                    					newLeafNode(lv_isPubliclyVisible_0_0, grammarAccess.getVictoryCardAccess().getIsPubliclyVisibleIsPubliclyVisibleKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getVictoryCardRule());
                    					}
                    					setWithLastConsumed(current, "isPubliclyVisible", lv_isPubliclyVisible_0_0 != null, "isPubliclyVisible");
                    				

                    }


                    }
                    break;

            }

            // InternalMDL.g:2214:3: ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==54) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalMDL.g:2215:4: (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' )
                    {
                    // InternalMDL.g:2215:4: (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' )
                    // InternalMDL.g:2216:5: lv_isVisibleToOwner_1_0= 'isVisibleToOwner'
                    {
                    lv_isVisibleToOwner_1_0=(Token)match(input,54,FOLLOW_59); 

                    					newLeafNode(lv_isVisibleToOwner_1_0, grammarAccess.getVictoryCardAccess().getIsVisibleToOwnerIsVisibleToOwnerKeyword_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getVictoryCardRule());
                    					}
                    					setWithLastConsumed(current, "isVisibleToOwner", lv_isVisibleToOwner_1_0 != null, "isVisibleToOwner");
                    				

                    }


                    }
                    break;

            }

            otherlv_2=(Token)match(input,58,FOLLOW_31); 

            			newLeafNode(otherlv_2, grammarAccess.getVictoryCardAccess().getVictoryCardKeyword_2());
            		
            // InternalMDL.g:2232:3: ( (lv_name_3_0= ruleEString ) )
            // InternalMDL.g:2233:4: (lv_name_3_0= ruleEString )
            {
            // InternalMDL.g:2233:4: (lv_name_3_0= ruleEString )
            // InternalMDL.g:2234:5: lv_name_3_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getVictoryCardAccess().getNameEStringParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_5);
            lv_name_3_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVictoryCardRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_3_0,
            						"metaDominoLang.MDL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_56); 

            			newLeafNode(otherlv_4, grammarAccess.getVictoryCardAccess().getLeftCurlyBracketKeyword_4());
            		
            otherlv_5=(Token)match(input,56,FOLLOW_33); 

            			newLeafNode(otherlv_5, grammarAccess.getVictoryCardAccess().getCostKeyword_5());
            		
            // InternalMDL.g:2259:3: ( (lv_cost_6_0= ruleEInt ) )
            // InternalMDL.g:2260:4: (lv_cost_6_0= ruleEInt )
            {
            // InternalMDL.g:2260:4: (lv_cost_6_0= ruleEInt )
            // InternalMDL.g:2261:5: lv_cost_6_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getVictoryCardAccess().getCostEIntParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_60);
            lv_cost_6_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVictoryCardRule());
            					}
            					set(
            						current,
            						"cost",
            						lv_cost_6_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_7=(Token)match(input,59,FOLLOW_33); 

            			newLeafNode(otherlv_7, grammarAccess.getVictoryCardAccess().getVictoryPointsKeyword_7());
            		
            // InternalMDL.g:2282:3: ( (lv_victoryPoints_8_0= ruleEInt ) )
            // InternalMDL.g:2283:4: (lv_victoryPoints_8_0= ruleEInt )
            {
            // InternalMDL.g:2283:4: (lv_victoryPoints_8_0= ruleEInt )
            // InternalMDL.g:2284:5: lv_victoryPoints_8_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getVictoryCardAccess().getVictoryPointsEIntParserRuleCall_8_0());
            				
            pushFollow(FOLLOW_22);
            lv_victoryPoints_8_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVictoryCardRule());
            					}
            					set(
            						current,
            						"victoryPoints",
            						lv_victoryPoints_8_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_9=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getVictoryCardAccess().getRightCurlyBracketKeyword_9());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVictoryCard"


    // $ANTLR start "entryRuleActionCard"
    // InternalMDL.g:2309:1: entryRuleActionCard returns [EObject current=null] : iv_ruleActionCard= ruleActionCard EOF ;
    public final EObject entryRuleActionCard() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleActionCard = null;


        try {
            // InternalMDL.g:2309:51: (iv_ruleActionCard= ruleActionCard EOF )
            // InternalMDL.g:2310:2: iv_ruleActionCard= ruleActionCard EOF
            {
             newCompositeNode(grammarAccess.getActionCardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleActionCard=ruleActionCard();

            state._fsp--;

             current =iv_ruleActionCard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleActionCard"


    // $ANTLR start "ruleActionCard"
    // InternalMDL.g:2316:1: ruleActionCard returns [EObject current=null] : ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'ActionCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'ability' otherlv_8= '(' ( ( ruleEString ) ) (otherlv_10= ',' ( ( ruleEString ) ) )* otherlv_12= ')' otherlv_13= '}' ) ;
    public final EObject ruleActionCard() throws RecognitionException {
        EObject current = null;

        Token lv_isPubliclyVisible_0_0=null;
        Token lv_isVisibleToOwner_1_0=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        AntlrDatatypeRuleToken lv_name_3_0 = null;

        AntlrDatatypeRuleToken lv_cost_6_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:2322:2: ( ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'ActionCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'ability' otherlv_8= '(' ( ( ruleEString ) ) (otherlv_10= ',' ( ( ruleEString ) ) )* otherlv_12= ')' otherlv_13= '}' ) )
            // InternalMDL.g:2323:2: ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'ActionCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'ability' otherlv_8= '(' ( ( ruleEString ) ) (otherlv_10= ',' ( ( ruleEString ) ) )* otherlv_12= ')' otherlv_13= '}' )
            {
            // InternalMDL.g:2323:2: ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'ActionCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'ability' otherlv_8= '(' ( ( ruleEString ) ) (otherlv_10= ',' ( ( ruleEString ) ) )* otherlv_12= ')' otherlv_13= '}' )
            // InternalMDL.g:2324:3: ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? otherlv_2= 'ActionCard' ( (lv_name_3_0= ruleEString ) ) otherlv_4= '{' otherlv_5= 'cost' ( (lv_cost_6_0= ruleEInt ) ) otherlv_7= 'ability' otherlv_8= '(' ( ( ruleEString ) ) (otherlv_10= ',' ( ( ruleEString ) ) )* otherlv_12= ')' otherlv_13= '}'
            {
            // InternalMDL.g:2324:3: ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==53) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalMDL.g:2325:4: (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' )
                    {
                    // InternalMDL.g:2325:4: (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' )
                    // InternalMDL.g:2326:5: lv_isPubliclyVisible_0_0= 'isPubliclyVisible'
                    {
                    lv_isPubliclyVisible_0_0=(Token)match(input,53,FOLLOW_61); 

                    					newLeafNode(lv_isPubliclyVisible_0_0, grammarAccess.getActionCardAccess().getIsPubliclyVisibleIsPubliclyVisibleKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getActionCardRule());
                    					}
                    					setWithLastConsumed(current, "isPubliclyVisible", lv_isPubliclyVisible_0_0 != null, "isPubliclyVisible");
                    				

                    }


                    }
                    break;

            }

            // InternalMDL.g:2338:3: ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==54) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalMDL.g:2339:4: (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' )
                    {
                    // InternalMDL.g:2339:4: (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' )
                    // InternalMDL.g:2340:5: lv_isVisibleToOwner_1_0= 'isVisibleToOwner'
                    {
                    lv_isVisibleToOwner_1_0=(Token)match(input,54,FOLLOW_62); 

                    					newLeafNode(lv_isVisibleToOwner_1_0, grammarAccess.getActionCardAccess().getIsVisibleToOwnerIsVisibleToOwnerKeyword_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getActionCardRule());
                    					}
                    					setWithLastConsumed(current, "isVisibleToOwner", lv_isVisibleToOwner_1_0 != null, "isVisibleToOwner");
                    				

                    }


                    }
                    break;

            }

            otherlv_2=(Token)match(input,60,FOLLOW_31); 

            			newLeafNode(otherlv_2, grammarAccess.getActionCardAccess().getActionCardKeyword_2());
            		
            // InternalMDL.g:2356:3: ( (lv_name_3_0= ruleEString ) )
            // InternalMDL.g:2357:4: (lv_name_3_0= ruleEString )
            {
            // InternalMDL.g:2357:4: (lv_name_3_0= ruleEString )
            // InternalMDL.g:2358:5: lv_name_3_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getActionCardAccess().getNameEStringParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_5);
            lv_name_3_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getActionCardRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_3_0,
            						"metaDominoLang.MDL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,13,FOLLOW_56); 

            			newLeafNode(otherlv_4, grammarAccess.getActionCardAccess().getLeftCurlyBracketKeyword_4());
            		
            otherlv_5=(Token)match(input,56,FOLLOW_33); 

            			newLeafNode(otherlv_5, grammarAccess.getActionCardAccess().getCostKeyword_5());
            		
            // InternalMDL.g:2383:3: ( (lv_cost_6_0= ruleEInt ) )
            // InternalMDL.g:2384:4: (lv_cost_6_0= ruleEInt )
            {
            // InternalMDL.g:2384:4: (lv_cost_6_0= ruleEInt )
            // InternalMDL.g:2385:5: lv_cost_6_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getActionCardAccess().getCostEIntParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_63);
            lv_cost_6_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getActionCardRule());
            					}
            					set(
            						current,
            						"cost",
            						lv_cost_6_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_7=(Token)match(input,61,FOLLOW_64); 

            			newLeafNode(otherlv_7, grammarAccess.getActionCardAccess().getAbilityKeyword_7());
            		
            otherlv_8=(Token)match(input,62,FOLLOW_31); 

            			newLeafNode(otherlv_8, grammarAccess.getActionCardAccess().getLeftParenthesisKeyword_8());
            		
            // InternalMDL.g:2410:3: ( ( ruleEString ) )
            // InternalMDL.g:2411:4: ( ruleEString )
            {
            // InternalMDL.g:2411:4: ( ruleEString )
            // InternalMDL.g:2412:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getActionCardRule());
            					}
            				

            					newCompositeNode(grammarAccess.getActionCardAccess().getAbilityAbilityCrossReference_9_0());
            				
            pushFollow(FOLLOW_65);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalMDL.g:2426:3: (otherlv_10= ',' ( ( ruleEString ) ) )*
            loop48:
            do {
                int alt48=2;
                int LA48_0 = input.LA(1);

                if ( (LA48_0==14) ) {
                    alt48=1;
                }


                switch (alt48) {
            	case 1 :
            	    // InternalMDL.g:2427:4: otherlv_10= ',' ( ( ruleEString ) )
            	    {
            	    otherlv_10=(Token)match(input,14,FOLLOW_31); 

            	    				newLeafNode(otherlv_10, grammarAccess.getActionCardAccess().getCommaKeyword_10_0());
            	    			
            	    // InternalMDL.g:2431:4: ( ( ruleEString ) )
            	    // InternalMDL.g:2432:5: ( ruleEString )
            	    {
            	    // InternalMDL.g:2432:5: ( ruleEString )
            	    // InternalMDL.g:2433:6: ruleEString
            	    {

            	    						if (current==null) {
            	    							current = createModelElement(grammarAccess.getActionCardRule());
            	    						}
            	    					

            	    						newCompositeNode(grammarAccess.getActionCardAccess().getAbilityAbilityCrossReference_10_1_0());
            	    					
            	    pushFollow(FOLLOW_65);
            	    ruleEString();

            	    state._fsp--;


            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop48;
                }
            } while (true);

            otherlv_12=(Token)match(input,63,FOLLOW_22); 

            			newLeafNode(otherlv_12, grammarAccess.getActionCardAccess().getRightParenthesisKeyword_11());
            		
            otherlv_13=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_13, grammarAccess.getActionCardAccess().getRightCurlyBracketKeyword_12());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleActionCard"


    // $ANTLR start "entryRuleActionPhase"
    // InternalMDL.g:2460:1: entryRuleActionPhase returns [EObject current=null] : iv_ruleActionPhase= ruleActionPhase EOF ;
    public final EObject entryRuleActionPhase() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleActionPhase = null;


        try {
            // InternalMDL.g:2460:52: (iv_ruleActionPhase= ruleActionPhase EOF )
            // InternalMDL.g:2461:2: iv_ruleActionPhase= ruleActionPhase EOF
            {
             newCompositeNode(grammarAccess.getActionPhaseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleActionPhase=ruleActionPhase();

            state._fsp--;

             current =iv_ruleActionPhase; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleActionPhase"


    // $ANTLR start "ruleActionPhase"
    // InternalMDL.g:2467:1: ruleActionPhase returns [EObject current=null] : ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )* )? ) ;
    public final EObject ruleActionPhase() throws RecognitionException {
        EObject current = null;

        EObject lv_playersactions_1_0 = null;

        EObject lv_playersactions_2_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:2473:2: ( ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )* )? ) )
            // InternalMDL.g:2474:2: ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )* )? )
            {
            // InternalMDL.g:2474:2: ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )* )? )
            // InternalMDL.g:2475:3: () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )* )?
            {
            // InternalMDL.g:2475:3: ()
            // InternalMDL.g:2476:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getActionPhaseAccess().getActionPhaseAction_0(),
            					current);
            			

            }

            // InternalMDL.g:2482:3: ( ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )* )?
            int alt50=2;
            int LA50_0 = input.LA(1);

            if ( ((LA50_0>=66 && LA50_0<=69)) ) {
                alt50=1;
            }
            switch (alt50) {
                case 1 :
                    // InternalMDL.g:2483:4: ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )*
                    {
                    // InternalMDL.g:2483:4: ( (lv_playersactions_1_0= rulePlayersAction ) )
                    // InternalMDL.g:2484:5: (lv_playersactions_1_0= rulePlayersAction )
                    {
                    // InternalMDL.g:2484:5: (lv_playersactions_1_0= rulePlayersAction )
                    // InternalMDL.g:2485:6: lv_playersactions_1_0= rulePlayersAction
                    {

                    						newCompositeNode(grammarAccess.getActionPhaseAccess().getPlayersactionsPlayersActionParserRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_66);
                    lv_playersactions_1_0=rulePlayersAction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getActionPhaseRule());
                    						}
                    						add(
                    							current,
                    							"playersactions",
                    							lv_playersactions_1_0,
                    							"metaDominoLang.MDL.PlayersAction");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:2502:4: ( (lv_playersactions_2_0= rulePlayersAction ) )*
                    loop49:
                    do {
                        int alt49=2;
                        int LA49_0 = input.LA(1);

                        if ( ((LA49_0>=66 && LA49_0<=69)) ) {
                            alt49=1;
                        }


                        switch (alt49) {
                    	case 1 :
                    	    // InternalMDL.g:2503:5: (lv_playersactions_2_0= rulePlayersAction )
                    	    {
                    	    // InternalMDL.g:2503:5: (lv_playersactions_2_0= rulePlayersAction )
                    	    // InternalMDL.g:2504:6: lv_playersactions_2_0= rulePlayersAction
                    	    {

                    	    						newCompositeNode(grammarAccess.getActionPhaseAccess().getPlayersactionsPlayersActionParserRuleCall_1_1_0());
                    	    					
                    	    pushFollow(FOLLOW_66);
                    	    lv_playersactions_2_0=rulePlayersAction();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getActionPhaseRule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"playersactions",
                    	    							lv_playersactions_2_0,
                    	    							"metaDominoLang.MDL.PlayersAction");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop49;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleActionPhase"


    // $ANTLR start "entryRuleBuyPhase"
    // InternalMDL.g:2526:1: entryRuleBuyPhase returns [EObject current=null] : iv_ruleBuyPhase= ruleBuyPhase EOF ;
    public final EObject entryRuleBuyPhase() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBuyPhase = null;


        try {
            // InternalMDL.g:2526:49: (iv_ruleBuyPhase= ruleBuyPhase EOF )
            // InternalMDL.g:2527:2: iv_ruleBuyPhase= ruleBuyPhase EOF
            {
             newCompositeNode(grammarAccess.getBuyPhaseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBuyPhase=ruleBuyPhase();

            state._fsp--;

             current =iv_ruleBuyPhase; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBuyPhase"


    // $ANTLR start "ruleBuyPhase"
    // InternalMDL.g:2533:1: ruleBuyPhase returns [EObject current=null] : ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )* )? ) ;
    public final EObject ruleBuyPhase() throws RecognitionException {
        EObject current = null;

        EObject lv_playersactions_1_0 = null;

        EObject lv_playersactions_2_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:2539:2: ( ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )* )? ) )
            // InternalMDL.g:2540:2: ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )* )? )
            {
            // InternalMDL.g:2540:2: ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )* )? )
            // InternalMDL.g:2541:3: () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )* )?
            {
            // InternalMDL.g:2541:3: ()
            // InternalMDL.g:2542:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getBuyPhaseAccess().getBuyPhaseAction_0(),
            					current);
            			

            }

            // InternalMDL.g:2548:3: ( ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )* )?
            int alt52=2;
            int LA52_0 = input.LA(1);

            if ( ((LA52_0>=66 && LA52_0<=69)) ) {
                alt52=1;
            }
            switch (alt52) {
                case 1 :
                    // InternalMDL.g:2549:4: ( (lv_playersactions_1_0= rulePlayersAction ) ) ( (lv_playersactions_2_0= rulePlayersAction ) )*
                    {
                    // InternalMDL.g:2549:4: ( (lv_playersactions_1_0= rulePlayersAction ) )
                    // InternalMDL.g:2550:5: (lv_playersactions_1_0= rulePlayersAction )
                    {
                    // InternalMDL.g:2550:5: (lv_playersactions_1_0= rulePlayersAction )
                    // InternalMDL.g:2551:6: lv_playersactions_1_0= rulePlayersAction
                    {

                    						newCompositeNode(grammarAccess.getBuyPhaseAccess().getPlayersactionsPlayersActionParserRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_66);
                    lv_playersactions_1_0=rulePlayersAction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getBuyPhaseRule());
                    						}
                    						add(
                    							current,
                    							"playersactions",
                    							lv_playersactions_1_0,
                    							"metaDominoLang.MDL.PlayersAction");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:2568:4: ( (lv_playersactions_2_0= rulePlayersAction ) )*
                    loop51:
                    do {
                        int alt51=2;
                        int LA51_0 = input.LA(1);

                        if ( ((LA51_0>=66 && LA51_0<=69)) ) {
                            alt51=1;
                        }


                        switch (alt51) {
                    	case 1 :
                    	    // InternalMDL.g:2569:5: (lv_playersactions_2_0= rulePlayersAction )
                    	    {
                    	    // InternalMDL.g:2569:5: (lv_playersactions_2_0= rulePlayersAction )
                    	    // InternalMDL.g:2570:6: lv_playersactions_2_0= rulePlayersAction
                    	    {

                    	    						newCompositeNode(grammarAccess.getBuyPhaseAccess().getPlayersactionsPlayersActionParserRuleCall_1_1_0());
                    	    					
                    	    pushFollow(FOLLOW_66);
                    	    lv_playersactions_2_0=rulePlayersAction();

                    	    state._fsp--;


                    	    						if (current==null) {
                    	    							current = createModelElementForParent(grammarAccess.getBuyPhaseRule());
                    	    						}
                    	    						add(
                    	    							current,
                    	    							"playersactions",
                    	    							lv_playersactions_2_0,
                    	    							"metaDominoLang.MDL.PlayersAction");
                    	    						afterParserOrEnumRuleCall();
                    	    					

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop51;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBuyPhase"


    // $ANTLR start "entryRuleCleanupPhase"
    // InternalMDL.g:2592:1: entryRuleCleanupPhase returns [EObject current=null] : iv_ruleCleanupPhase= ruleCleanupPhase EOF ;
    public final EObject entryRuleCleanupPhase() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCleanupPhase = null;


        try {
            // InternalMDL.g:2592:53: (iv_ruleCleanupPhase= ruleCleanupPhase EOF )
            // InternalMDL.g:2593:2: iv_ruleCleanupPhase= ruleCleanupPhase EOF
            {
             newCompositeNode(grammarAccess.getCleanupPhaseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCleanupPhase=ruleCleanupPhase();

            state._fsp--;

             current =iv_ruleCleanupPhase; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCleanupPhase"


    // $ANTLR start "ruleCleanupPhase"
    // InternalMDL.g:2599:1: ruleCleanupPhase returns [EObject current=null] : ( () otherlv_1= 'CleanupPhase' otherlv_2= '{' (otherlv_3= 'put_cards_from_hand_to_discard' otherlv_4= '(' ( ( ruleEString ) ) (otherlv_6= ',' ( ( ruleEString ) ) )* otherlv_8= ')' )? otherlv_9= '}' ) ;
    public final EObject ruleCleanupPhase() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;


        	enterRule();

        try {
            // InternalMDL.g:2605:2: ( ( () otherlv_1= 'CleanupPhase' otherlv_2= '{' (otherlv_3= 'put_cards_from_hand_to_discard' otherlv_4= '(' ( ( ruleEString ) ) (otherlv_6= ',' ( ( ruleEString ) ) )* otherlv_8= ')' )? otherlv_9= '}' ) )
            // InternalMDL.g:2606:2: ( () otherlv_1= 'CleanupPhase' otherlv_2= '{' (otherlv_3= 'put_cards_from_hand_to_discard' otherlv_4= '(' ( ( ruleEString ) ) (otherlv_6= ',' ( ( ruleEString ) ) )* otherlv_8= ')' )? otherlv_9= '}' )
            {
            // InternalMDL.g:2606:2: ( () otherlv_1= 'CleanupPhase' otherlv_2= '{' (otherlv_3= 'put_cards_from_hand_to_discard' otherlv_4= '(' ( ( ruleEString ) ) (otherlv_6= ',' ( ( ruleEString ) ) )* otherlv_8= ')' )? otherlv_9= '}' )
            // InternalMDL.g:2607:3: () otherlv_1= 'CleanupPhase' otherlv_2= '{' (otherlv_3= 'put_cards_from_hand_to_discard' otherlv_4= '(' ( ( ruleEString ) ) (otherlv_6= ',' ( ( ruleEString ) ) )* otherlv_8= ')' )? otherlv_9= '}'
            {
            // InternalMDL.g:2607:3: ()
            // InternalMDL.g:2608:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getCleanupPhaseAccess().getCleanupPhaseAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,64,FOLLOW_5); 

            			newLeafNode(otherlv_1, grammarAccess.getCleanupPhaseAccess().getCleanupPhaseKeyword_1());
            		
            otherlv_2=(Token)match(input,13,FOLLOW_67); 

            			newLeafNode(otherlv_2, grammarAccess.getCleanupPhaseAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalMDL.g:2622:3: (otherlv_3= 'put_cards_from_hand_to_discard' otherlv_4= '(' ( ( ruleEString ) ) (otherlv_6= ',' ( ( ruleEString ) ) )* otherlv_8= ')' )?
            int alt54=2;
            int LA54_0 = input.LA(1);

            if ( (LA54_0==65) ) {
                alt54=1;
            }
            switch (alt54) {
                case 1 :
                    // InternalMDL.g:2623:4: otherlv_3= 'put_cards_from_hand_to_discard' otherlv_4= '(' ( ( ruleEString ) ) (otherlv_6= ',' ( ( ruleEString ) ) )* otherlv_8= ')'
                    {
                    otherlv_3=(Token)match(input,65,FOLLOW_64); 

                    				newLeafNode(otherlv_3, grammarAccess.getCleanupPhaseAccess().getPut_cards_from_hand_to_discardKeyword_3_0());
                    			
                    otherlv_4=(Token)match(input,62,FOLLOW_31); 

                    				newLeafNode(otherlv_4, grammarAccess.getCleanupPhaseAccess().getLeftParenthesisKeyword_3_1());
                    			
                    // InternalMDL.g:2631:4: ( ( ruleEString ) )
                    // InternalMDL.g:2632:5: ( ruleEString )
                    {
                    // InternalMDL.g:2632:5: ( ruleEString )
                    // InternalMDL.g:2633:6: ruleEString
                    {

                    						if (current==null) {
                    							current = createModelElement(grammarAccess.getCleanupPhaseRule());
                    						}
                    					

                    						newCompositeNode(grammarAccess.getCleanupPhaseAccess().getPut_cards_from_hand_to_discardPutCardFromHandToDiscardCrossReference_3_2_0());
                    					
                    pushFollow(FOLLOW_65);
                    ruleEString();

                    state._fsp--;


                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMDL.g:2647:4: (otherlv_6= ',' ( ( ruleEString ) ) )*
                    loop53:
                    do {
                        int alt53=2;
                        int LA53_0 = input.LA(1);

                        if ( (LA53_0==14) ) {
                            alt53=1;
                        }


                        switch (alt53) {
                    	case 1 :
                    	    // InternalMDL.g:2648:5: otherlv_6= ',' ( ( ruleEString ) )
                    	    {
                    	    otherlv_6=(Token)match(input,14,FOLLOW_31); 

                    	    					newLeafNode(otherlv_6, grammarAccess.getCleanupPhaseAccess().getCommaKeyword_3_3_0());
                    	    				
                    	    // InternalMDL.g:2652:5: ( ( ruleEString ) )
                    	    // InternalMDL.g:2653:6: ( ruleEString )
                    	    {
                    	    // InternalMDL.g:2653:6: ( ruleEString )
                    	    // InternalMDL.g:2654:7: ruleEString
                    	    {

                    	    							if (current==null) {
                    	    								current = createModelElement(grammarAccess.getCleanupPhaseRule());
                    	    							}
                    	    						

                    	    							newCompositeNode(grammarAccess.getCleanupPhaseAccess().getPut_cards_from_hand_to_discardPutCardFromHandToDiscardCrossReference_3_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_65);
                    	    ruleEString();

                    	    state._fsp--;


                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop53;
                        }
                    } while (true);

                    otherlv_8=(Token)match(input,63,FOLLOW_22); 

                    				newLeafNode(otherlv_8, grammarAccess.getCleanupPhaseAccess().getRightParenthesisKeyword_3_4());
                    			

                    }
                    break;

            }

            otherlv_9=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_9, grammarAccess.getCleanupPhaseAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCleanupPhase"


    // $ANTLR start "entryRuleBuyCard"
    // InternalMDL.g:2682:1: entryRuleBuyCard returns [EObject current=null] : iv_ruleBuyCard= ruleBuyCard EOF ;
    public final EObject entryRuleBuyCard() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBuyCard = null;


        try {
            // InternalMDL.g:2682:48: (iv_ruleBuyCard= ruleBuyCard EOF )
            // InternalMDL.g:2683:2: iv_ruleBuyCard= ruleBuyCard EOF
            {
             newCompositeNode(grammarAccess.getBuyCardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBuyCard=ruleBuyCard();

            state._fsp--;

             current =iv_ruleBuyCard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBuyCard"


    // $ANTLR start "ruleBuyCard"
    // InternalMDL.g:2689:1: ruleBuyCard returns [EObject current=null] : (otherlv_0= 'buy' ( ( ruleEString ) ) ) ;
    public final EObject ruleBuyCard() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;


        	enterRule();

        try {
            // InternalMDL.g:2695:2: ( (otherlv_0= 'buy' ( ( ruleEString ) ) ) )
            // InternalMDL.g:2696:2: (otherlv_0= 'buy' ( ( ruleEString ) ) )
            {
            // InternalMDL.g:2696:2: (otherlv_0= 'buy' ( ( ruleEString ) ) )
            // InternalMDL.g:2697:3: otherlv_0= 'buy' ( ( ruleEString ) )
            {
            otherlv_0=(Token)match(input,66,FOLLOW_31); 

            			newLeafNode(otherlv_0, grammarAccess.getBuyCardAccess().getBuyKeyword_0());
            		
            // InternalMDL.g:2701:3: ( ( ruleEString ) )
            // InternalMDL.g:2702:4: ( ruleEString )
            {
            // InternalMDL.g:2702:4: ( ruleEString )
            // InternalMDL.g:2703:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getBuyCardRule());
            					}
            				

            					newCompositeNode(grammarAccess.getBuyCardAccess().getCardCardCrossReference_1_0());
            				
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBuyCard"


    // $ANTLR start "entryRulePlayAction"
    // InternalMDL.g:2721:1: entryRulePlayAction returns [EObject current=null] : iv_rulePlayAction= rulePlayAction EOF ;
    public final EObject entryRulePlayAction() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePlayAction = null;


        try {
            // InternalMDL.g:2721:51: (iv_rulePlayAction= rulePlayAction EOF )
            // InternalMDL.g:2722:2: iv_rulePlayAction= rulePlayAction EOF
            {
             newCompositeNode(grammarAccess.getPlayActionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePlayAction=rulePlayAction();

            state._fsp--;

             current =iv_rulePlayAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePlayAction"


    // $ANTLR start "rulePlayAction"
    // InternalMDL.g:2728:1: rulePlayAction returns [EObject current=null] : (otherlv_0= 'play' ( ( ruleEString ) ) ) ;
    public final EObject rulePlayAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;


        	enterRule();

        try {
            // InternalMDL.g:2734:2: ( (otherlv_0= 'play' ( ( ruleEString ) ) ) )
            // InternalMDL.g:2735:2: (otherlv_0= 'play' ( ( ruleEString ) ) )
            {
            // InternalMDL.g:2735:2: (otherlv_0= 'play' ( ( ruleEString ) ) )
            // InternalMDL.g:2736:3: otherlv_0= 'play' ( ( ruleEString ) )
            {
            otherlv_0=(Token)match(input,67,FOLLOW_31); 

            			newLeafNode(otherlv_0, grammarAccess.getPlayActionAccess().getPlayKeyword_0());
            		
            // InternalMDL.g:2740:3: ( ( ruleEString ) )
            // InternalMDL.g:2741:4: ( ruleEString )
            {
            // InternalMDL.g:2741:4: ( ruleEString )
            // InternalMDL.g:2742:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPlayActionRule());
            					}
            				

            					newCompositeNode(grammarAccess.getPlayActionAccess().getAction_cardCardCrossReference_1_0());
            				
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePlayAction"


    // $ANTLR start "entryRuleIfAction"
    // InternalMDL.g:2760:1: entryRuleIfAction returns [EObject current=null] : iv_ruleIfAction= ruleIfAction EOF ;
    public final EObject entryRuleIfAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIfAction = null;


        try {
            // InternalMDL.g:2760:49: (iv_ruleIfAction= ruleIfAction EOF )
            // InternalMDL.g:2761:2: iv_ruleIfAction= ruleIfAction EOF
            {
             newCompositeNode(grammarAccess.getIfActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIfAction=ruleIfAction();

            state._fsp--;

             current =iv_ruleIfAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIfAction"


    // $ANTLR start "ruleIfAction"
    // InternalMDL.g:2767:1: ruleIfAction returns [EObject current=null] : (otherlv_0= 'If' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_consequent_action_3_0= rulePlayersAction ) ) ) ;
    public final EObject ruleIfAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject lv_condition_1_0 = null;

        EObject lv_consequent_action_3_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:2773:2: ( (otherlv_0= 'If' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_consequent_action_3_0= rulePlayersAction ) ) ) )
            // InternalMDL.g:2774:2: (otherlv_0= 'If' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_consequent_action_3_0= rulePlayersAction ) ) )
            {
            // InternalMDL.g:2774:2: (otherlv_0= 'If' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_consequent_action_3_0= rulePlayersAction ) ) )
            // InternalMDL.g:2775:3: otherlv_0= 'If' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_consequent_action_3_0= rulePlayersAction ) )
            {
            otherlv_0=(Token)match(input,68,FOLLOW_68); 

            			newLeafNode(otherlv_0, grammarAccess.getIfActionAccess().getIfKeyword_0());
            		
            // InternalMDL.g:2779:3: ( (lv_condition_1_0= ruleExpression ) )
            // InternalMDL.g:2780:4: (lv_condition_1_0= ruleExpression )
            {
            // InternalMDL.g:2780:4: (lv_condition_1_0= ruleExpression )
            // InternalMDL.g:2781:5: lv_condition_1_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getIfActionAccess().getConditionExpressionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_9);
            lv_condition_1_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIfActionRule());
            					}
            					set(
            						current,
            						"condition",
            						lv_condition_1_0,
            						"metaDominoLang.MDL.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,17,FOLLOW_29); 

            			newLeafNode(otherlv_2, grammarAccess.getIfActionAccess().getColonKeyword_2());
            		
            // InternalMDL.g:2802:3: ( (lv_consequent_action_3_0= rulePlayersAction ) )
            // InternalMDL.g:2803:4: (lv_consequent_action_3_0= rulePlayersAction )
            {
            // InternalMDL.g:2803:4: (lv_consequent_action_3_0= rulePlayersAction )
            // InternalMDL.g:2804:5: lv_consequent_action_3_0= rulePlayersAction
            {

            					newCompositeNode(grammarAccess.getIfActionAccess().getConsequent_actionPlayersActionParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_consequent_action_3_0=rulePlayersAction();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIfActionRule());
            					}
            					set(
            						current,
            						"consequent_action",
            						lv_consequent_action_3_0,
            						"metaDominoLang.MDL.PlayersAction");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIfAction"


    // $ANTLR start "entryRuleWhileAction"
    // InternalMDL.g:2825:1: entryRuleWhileAction returns [EObject current=null] : iv_ruleWhileAction= ruleWhileAction EOF ;
    public final EObject entryRuleWhileAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleWhileAction = null;


        try {
            // InternalMDL.g:2825:52: (iv_ruleWhileAction= ruleWhileAction EOF )
            // InternalMDL.g:2826:2: iv_ruleWhileAction= ruleWhileAction EOF
            {
             newCompositeNode(grammarAccess.getWhileActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleWhileAction=ruleWhileAction();

            state._fsp--;

             current =iv_ruleWhileAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleWhileAction"


    // $ANTLR start "ruleWhileAction"
    // InternalMDL.g:2832:1: ruleWhileAction returns [EObject current=null] : (otherlv_0= 'While' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_playersaction_3_0= rulePlayersAction ) ) ) ;
    public final EObject ruleWhileAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject lv_condition_1_0 = null;

        EObject lv_playersaction_3_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:2838:2: ( (otherlv_0= 'While' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_playersaction_3_0= rulePlayersAction ) ) ) )
            // InternalMDL.g:2839:2: (otherlv_0= 'While' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_playersaction_3_0= rulePlayersAction ) ) )
            {
            // InternalMDL.g:2839:2: (otherlv_0= 'While' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_playersaction_3_0= rulePlayersAction ) ) )
            // InternalMDL.g:2840:3: otherlv_0= 'While' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_playersaction_3_0= rulePlayersAction ) )
            {
            otherlv_0=(Token)match(input,69,FOLLOW_68); 

            			newLeafNode(otherlv_0, grammarAccess.getWhileActionAccess().getWhileKeyword_0());
            		
            // InternalMDL.g:2844:3: ( (lv_condition_1_0= ruleExpression ) )
            // InternalMDL.g:2845:4: (lv_condition_1_0= ruleExpression )
            {
            // InternalMDL.g:2845:4: (lv_condition_1_0= ruleExpression )
            // InternalMDL.g:2846:5: lv_condition_1_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getWhileActionAccess().getConditionExpressionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_9);
            lv_condition_1_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getWhileActionRule());
            					}
            					set(
            						current,
            						"condition",
            						lv_condition_1_0,
            						"metaDominoLang.MDL.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,17,FOLLOW_29); 

            			newLeafNode(otherlv_2, grammarAccess.getWhileActionAccess().getColonKeyword_2());
            		
            // InternalMDL.g:2867:3: ( (lv_playersaction_3_0= rulePlayersAction ) )
            // InternalMDL.g:2868:4: (lv_playersaction_3_0= rulePlayersAction )
            {
            // InternalMDL.g:2868:4: (lv_playersaction_3_0= rulePlayersAction )
            // InternalMDL.g:2869:5: lv_playersaction_3_0= rulePlayersAction
            {

            					newCompositeNode(grammarAccess.getWhileActionAccess().getPlayersactionPlayersActionParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_playersaction_3_0=rulePlayersAction();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getWhileActionRule());
            					}
            					set(
            						current,
            						"playersaction",
            						lv_playersaction_3_0,
            						"metaDominoLang.MDL.PlayersAction");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleWhileAction"


    // $ANTLR start "entryRuleFittingCard"
    // InternalMDL.g:2890:1: entryRuleFittingCard returns [EObject current=null] : iv_ruleFittingCard= ruleFittingCard EOF ;
    public final EObject entryRuleFittingCard() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFittingCard = null;


        try {
            // InternalMDL.g:2890:52: (iv_ruleFittingCard= ruleFittingCard EOF )
            // InternalMDL.g:2891:2: iv_ruleFittingCard= ruleFittingCard EOF
            {
             newCompositeNode(grammarAccess.getFittingCardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFittingCard=ruleFittingCard();

            state._fsp--;

             current =iv_ruleFittingCard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFittingCard"


    // $ANTLR start "ruleFittingCard"
    // InternalMDL.g:2897:1: ruleFittingCard returns [EObject current=null] : (otherlv_0= 'you' otherlv_1= 'have' ( ( ruleEString ) ) ) ;
    public final EObject ruleFittingCard() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;


        	enterRule();

        try {
            // InternalMDL.g:2903:2: ( (otherlv_0= 'you' otherlv_1= 'have' ( ( ruleEString ) ) ) )
            // InternalMDL.g:2904:2: (otherlv_0= 'you' otherlv_1= 'have' ( ( ruleEString ) ) )
            {
            // InternalMDL.g:2904:2: (otherlv_0= 'you' otherlv_1= 'have' ( ( ruleEString ) ) )
            // InternalMDL.g:2905:3: otherlv_0= 'you' otherlv_1= 'have' ( ( ruleEString ) )
            {
            otherlv_0=(Token)match(input,70,FOLLOW_69); 

            			newLeafNode(otherlv_0, grammarAccess.getFittingCardAccess().getYouKeyword_0());
            		
            otherlv_1=(Token)match(input,71,FOLLOW_31); 

            			newLeafNode(otherlv_1, grammarAccess.getFittingCardAccess().getHaveKeyword_1());
            		
            // InternalMDL.g:2913:3: ( ( ruleEString ) )
            // InternalMDL.g:2914:4: ( ruleEString )
            {
            // InternalMDL.g:2914:4: ( ruleEString )
            // InternalMDL.g:2915:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFittingCardRule());
            					}
            				

            					newCompositeNode(grammarAccess.getFittingCardAccess().getCardCardCrossReference_2_0());
            				
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFittingCard"


    // $ANTLR start "entryRuleEnoughCoins"
    // InternalMDL.g:2933:1: entryRuleEnoughCoins returns [EObject current=null] : iv_ruleEnoughCoins= ruleEnoughCoins EOF ;
    public final EObject entryRuleEnoughCoins() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnoughCoins = null;


        try {
            // InternalMDL.g:2933:52: (iv_ruleEnoughCoins= ruleEnoughCoins EOF )
            // InternalMDL.g:2934:2: iv_ruleEnoughCoins= ruleEnoughCoins EOF
            {
             newCompositeNode(grammarAccess.getEnoughCoinsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEnoughCoins=ruleEnoughCoins();

            state._fsp--;

             current =iv_ruleEnoughCoins; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnoughCoins"


    // $ANTLR start "ruleEnoughCoins"
    // InternalMDL.g:2940:1: ruleEnoughCoins returns [EObject current=null] : (otherlv_0= 'you' otherlv_1= 'have' ( (lv_coinNumber_2_0= ruleEInt ) ) otherlv_3= 'coins' ) ;
    public final EObject ruleEnoughCoins() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        AntlrDatatypeRuleToken lv_coinNumber_2_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:2946:2: ( (otherlv_0= 'you' otherlv_1= 'have' ( (lv_coinNumber_2_0= ruleEInt ) ) otherlv_3= 'coins' ) )
            // InternalMDL.g:2947:2: (otherlv_0= 'you' otherlv_1= 'have' ( (lv_coinNumber_2_0= ruleEInt ) ) otherlv_3= 'coins' )
            {
            // InternalMDL.g:2947:2: (otherlv_0= 'you' otherlv_1= 'have' ( (lv_coinNumber_2_0= ruleEInt ) ) otherlv_3= 'coins' )
            // InternalMDL.g:2948:3: otherlv_0= 'you' otherlv_1= 'have' ( (lv_coinNumber_2_0= ruleEInt ) ) otherlv_3= 'coins'
            {
            otherlv_0=(Token)match(input,70,FOLLOW_69); 

            			newLeafNode(otherlv_0, grammarAccess.getEnoughCoinsAccess().getYouKeyword_0());
            		
            otherlv_1=(Token)match(input,71,FOLLOW_33); 

            			newLeafNode(otherlv_1, grammarAccess.getEnoughCoinsAccess().getHaveKeyword_1());
            		
            // InternalMDL.g:2956:3: ( (lv_coinNumber_2_0= ruleEInt ) )
            // InternalMDL.g:2957:4: (lv_coinNumber_2_0= ruleEInt )
            {
            // InternalMDL.g:2957:4: (lv_coinNumber_2_0= ruleEInt )
            // InternalMDL.g:2958:5: lv_coinNumber_2_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getEnoughCoinsAccess().getCoinNumberEIntParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_70);
            lv_coinNumber_2_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getEnoughCoinsRule());
            					}
            					set(
            						current,
            						"coinNumber",
            						lv_coinNumber_2_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,72,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getEnoughCoinsAccess().getCoinsKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnoughCoins"


    // $ANTLR start "entryRulePutCardFromHandToDiscard"
    // InternalMDL.g:2983:1: entryRulePutCardFromHandToDiscard returns [EObject current=null] : iv_rulePutCardFromHandToDiscard= rulePutCardFromHandToDiscard EOF ;
    public final EObject entryRulePutCardFromHandToDiscard() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePutCardFromHandToDiscard = null;


        try {
            // InternalMDL.g:2983:65: (iv_rulePutCardFromHandToDiscard= rulePutCardFromHandToDiscard EOF )
            // InternalMDL.g:2984:2: iv_rulePutCardFromHandToDiscard= rulePutCardFromHandToDiscard EOF
            {
             newCompositeNode(grammarAccess.getPutCardFromHandToDiscardRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePutCardFromHandToDiscard=rulePutCardFromHandToDiscard();

            state._fsp--;

             current =iv_rulePutCardFromHandToDiscard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePutCardFromHandToDiscard"


    // $ANTLR start "rulePutCardFromHandToDiscard"
    // InternalMDL.g:2990:1: rulePutCardFromHandToDiscard returns [EObject current=null] : ( () ( (lv_name_1_0= ruleEString ) ) otherlv_2= 'PutCardFromHandToDiscard' ) ;
    public final EObject rulePutCardFromHandToDiscard() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:2996:2: ( ( () ( (lv_name_1_0= ruleEString ) ) otherlv_2= 'PutCardFromHandToDiscard' ) )
            // InternalMDL.g:2997:2: ( () ( (lv_name_1_0= ruleEString ) ) otherlv_2= 'PutCardFromHandToDiscard' )
            {
            // InternalMDL.g:2997:2: ( () ( (lv_name_1_0= ruleEString ) ) otherlv_2= 'PutCardFromHandToDiscard' )
            // InternalMDL.g:2998:3: () ( (lv_name_1_0= ruleEString ) ) otherlv_2= 'PutCardFromHandToDiscard'
            {
            // InternalMDL.g:2998:3: ()
            // InternalMDL.g:2999:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getPutCardFromHandToDiscardAccess().getPutCardFromHandToDiscardAction_0(),
            					current);
            			

            }

            // InternalMDL.g:3005:3: ( (lv_name_1_0= ruleEString ) )
            // InternalMDL.g:3006:4: (lv_name_1_0= ruleEString )
            {
            // InternalMDL.g:3006:4: (lv_name_1_0= ruleEString )
            // InternalMDL.g:3007:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getPutCardFromHandToDiscardAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_71);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPutCardFromHandToDiscardRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"metaDominoLang.MDL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,73,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getPutCardFromHandToDiscardAccess().getPutCardFromHandToDiscardKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePutCardFromHandToDiscard"


    // $ANTLR start "entryRulePutCardInTrash"
    // InternalMDL.g:3032:1: entryRulePutCardInTrash returns [EObject current=null] : iv_rulePutCardInTrash= rulePutCardInTrash EOF ;
    public final EObject entryRulePutCardInTrash() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePutCardInTrash = null;


        try {
            // InternalMDL.g:3032:55: (iv_rulePutCardInTrash= rulePutCardInTrash EOF )
            // InternalMDL.g:3033:2: iv_rulePutCardInTrash= rulePutCardInTrash EOF
            {
             newCompositeNode(grammarAccess.getPutCardInTrashRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePutCardInTrash=rulePutCardInTrash();

            state._fsp--;

             current =iv_rulePutCardInTrash; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePutCardInTrash"


    // $ANTLR start "rulePutCardInTrash"
    // InternalMDL.g:3039:1: rulePutCardInTrash returns [EObject current=null] : ( () ( (lv_name_1_0= ruleEString ) ) otherlv_2= 'PutCardInTrash' ) ;
    public final EObject rulePutCardInTrash() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:3045:2: ( ( () ( (lv_name_1_0= ruleEString ) ) otherlv_2= 'PutCardInTrash' ) )
            // InternalMDL.g:3046:2: ( () ( (lv_name_1_0= ruleEString ) ) otherlv_2= 'PutCardInTrash' )
            {
            // InternalMDL.g:3046:2: ( () ( (lv_name_1_0= ruleEString ) ) otherlv_2= 'PutCardInTrash' )
            // InternalMDL.g:3047:3: () ( (lv_name_1_0= ruleEString ) ) otherlv_2= 'PutCardInTrash'
            {
            // InternalMDL.g:3047:3: ()
            // InternalMDL.g:3048:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getPutCardInTrashAccess().getPutCardInTrashAction_0(),
            					current);
            			

            }

            // InternalMDL.g:3054:3: ( (lv_name_1_0= ruleEString ) )
            // InternalMDL.g:3055:4: (lv_name_1_0= ruleEString )
            {
            // InternalMDL.g:3055:4: (lv_name_1_0= ruleEString )
            // InternalMDL.g:3056:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getPutCardInTrashAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_72);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPutCardInTrashRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"metaDominoLang.MDL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,74,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getPutCardInTrashAccess().getPutCardInTrashKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePutCardInTrash"


    // $ANTLR start "entryRuleDrawCards"
    // InternalMDL.g:3081:1: entryRuleDrawCards returns [EObject current=null] : iv_ruleDrawCards= ruleDrawCards EOF ;
    public final EObject entryRuleDrawCards() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDrawCards = null;


        try {
            // InternalMDL.g:3081:50: (iv_ruleDrawCards= ruleDrawCards EOF )
            // InternalMDL.g:3082:2: iv_ruleDrawCards= ruleDrawCards EOF
            {
             newCompositeNode(grammarAccess.getDrawCardsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDrawCards=ruleDrawCards();

            state._fsp--;

             current =iv_ruleDrawCards; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDrawCards"


    // $ANTLR start "ruleDrawCards"
    // InternalMDL.g:3088:1: ruleDrawCards returns [EObject current=null] : (otherlv_0= 'DrawCards' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'cardNumber' ( (lv_cardNumber_4_0= ruleEInt ) ) otherlv_5= '}' ) ;
    public final EObject ruleDrawCards() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        AntlrDatatypeRuleToken lv_cardNumber_4_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:3094:2: ( (otherlv_0= 'DrawCards' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'cardNumber' ( (lv_cardNumber_4_0= ruleEInt ) ) otherlv_5= '}' ) )
            // InternalMDL.g:3095:2: (otherlv_0= 'DrawCards' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'cardNumber' ( (lv_cardNumber_4_0= ruleEInt ) ) otherlv_5= '}' )
            {
            // InternalMDL.g:3095:2: (otherlv_0= 'DrawCards' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'cardNumber' ( (lv_cardNumber_4_0= ruleEInt ) ) otherlv_5= '}' )
            // InternalMDL.g:3096:3: otherlv_0= 'DrawCards' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'cardNumber' ( (lv_cardNumber_4_0= ruleEInt ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,75,FOLLOW_31); 

            			newLeafNode(otherlv_0, grammarAccess.getDrawCardsAccess().getDrawCardsKeyword_0());
            		
            // InternalMDL.g:3100:3: ( (lv_name_1_0= ruleEString ) )
            // InternalMDL.g:3101:4: (lv_name_1_0= ruleEString )
            {
            // InternalMDL.g:3101:4: (lv_name_1_0= ruleEString )
            // InternalMDL.g:3102:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getDrawCardsAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_5);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDrawCardsRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"metaDominoLang.MDL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_73); 

            			newLeafNode(otherlv_2, grammarAccess.getDrawCardsAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,76,FOLLOW_33); 

            			newLeafNode(otherlv_3, grammarAccess.getDrawCardsAccess().getCardNumberKeyword_3());
            		
            // InternalMDL.g:3127:3: ( (lv_cardNumber_4_0= ruleEInt ) )
            // InternalMDL.g:3128:4: (lv_cardNumber_4_0= ruleEInt )
            {
            // InternalMDL.g:3128:4: (lv_cardNumber_4_0= ruleEInt )
            // InternalMDL.g:3129:5: lv_cardNumber_4_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getDrawCardsAccess().getCardNumberEIntParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_22);
            lv_cardNumber_4_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDrawCardsRule());
            					}
            					set(
            						current,
            						"cardNumber",
            						lv_cardNumber_4_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getDrawCardsAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDrawCards"


    // $ANTLR start "entryRulePutCardFromPileToDiscard"
    // InternalMDL.g:3154:1: entryRulePutCardFromPileToDiscard returns [EObject current=null] : iv_rulePutCardFromPileToDiscard= rulePutCardFromPileToDiscard EOF ;
    public final EObject entryRulePutCardFromPileToDiscard() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePutCardFromPileToDiscard = null;


        try {
            // InternalMDL.g:3154:65: (iv_rulePutCardFromPileToDiscard= rulePutCardFromPileToDiscard EOF )
            // InternalMDL.g:3155:2: iv_rulePutCardFromPileToDiscard= rulePutCardFromPileToDiscard EOF
            {
             newCompositeNode(grammarAccess.getPutCardFromPileToDiscardRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePutCardFromPileToDiscard=rulePutCardFromPileToDiscard();

            state._fsp--;

             current =iv_rulePutCardFromPileToDiscard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePutCardFromPileToDiscard"


    // $ANTLR start "rulePutCardFromPileToDiscard"
    // InternalMDL.g:3161:1: rulePutCardFromPileToDiscard returns [EObject current=null] : (otherlv_0= 'PutCardFromPileToDiscard' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'discard_pile' ( ( ruleEString ) ) otherlv_5= '}' ) ;
    public final EObject rulePutCardFromPileToDiscard() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:3167:2: ( (otherlv_0= 'PutCardFromPileToDiscard' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'discard_pile' ( ( ruleEString ) ) otherlv_5= '}' ) )
            // InternalMDL.g:3168:2: (otherlv_0= 'PutCardFromPileToDiscard' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'discard_pile' ( ( ruleEString ) ) otherlv_5= '}' )
            {
            // InternalMDL.g:3168:2: (otherlv_0= 'PutCardFromPileToDiscard' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'discard_pile' ( ( ruleEString ) ) otherlv_5= '}' )
            // InternalMDL.g:3169:3: otherlv_0= 'PutCardFromPileToDiscard' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'discard_pile' ( ( ruleEString ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,77,FOLLOW_31); 

            			newLeafNode(otherlv_0, grammarAccess.getPutCardFromPileToDiscardAccess().getPutCardFromPileToDiscardKeyword_0());
            		
            // InternalMDL.g:3173:3: ( (lv_name_1_0= ruleEString ) )
            // InternalMDL.g:3174:4: (lv_name_1_0= ruleEString )
            {
            // InternalMDL.g:3174:4: (lv_name_1_0= ruleEString )
            // InternalMDL.g:3175:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getPutCardFromPileToDiscardAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_5);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getPutCardFromPileToDiscardRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"metaDominoLang.MDL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_41); 

            			newLeafNode(otherlv_2, grammarAccess.getPutCardFromPileToDiscardAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,37,FOLLOW_31); 

            			newLeafNode(otherlv_3, grammarAccess.getPutCardFromPileToDiscardAccess().getDiscard_pileKeyword_3());
            		
            // InternalMDL.g:3200:3: ( ( ruleEString ) )
            // InternalMDL.g:3201:4: ( ruleEString )
            {
            // InternalMDL.g:3201:4: ( ruleEString )
            // InternalMDL.g:3202:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPutCardFromPileToDiscardRule());
            					}
            				

            					newCompositeNode(grammarAccess.getPutCardFromPileToDiscardAccess().getDiscard_pileDiscardPileCrossReference_4_0());
            				
            pushFollow(FOLLOW_22);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getPutCardFromPileToDiscardAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePutCardFromPileToDiscard"


    // $ANTLR start "entryRuleExtraBuys"
    // InternalMDL.g:3224:1: entryRuleExtraBuys returns [EObject current=null] : iv_ruleExtraBuys= ruleExtraBuys EOF ;
    public final EObject entryRuleExtraBuys() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExtraBuys = null;


        try {
            // InternalMDL.g:3224:50: (iv_ruleExtraBuys= ruleExtraBuys EOF )
            // InternalMDL.g:3225:2: iv_ruleExtraBuys= ruleExtraBuys EOF
            {
             newCompositeNode(grammarAccess.getExtraBuysRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExtraBuys=ruleExtraBuys();

            state._fsp--;

             current =iv_ruleExtraBuys; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExtraBuys"


    // $ANTLR start "ruleExtraBuys"
    // InternalMDL.g:3231:1: ruleExtraBuys returns [EObject current=null] : (otherlv_0= 'ExtraBuys' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'buyNumber' ( (lv_buyNumber_4_0= ruleEInt ) ) otherlv_5= '}' ) ;
    public final EObject ruleExtraBuys() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        AntlrDatatypeRuleToken lv_buyNumber_4_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:3237:2: ( (otherlv_0= 'ExtraBuys' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'buyNumber' ( (lv_buyNumber_4_0= ruleEInt ) ) otherlv_5= '}' ) )
            // InternalMDL.g:3238:2: (otherlv_0= 'ExtraBuys' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'buyNumber' ( (lv_buyNumber_4_0= ruleEInt ) ) otherlv_5= '}' )
            {
            // InternalMDL.g:3238:2: (otherlv_0= 'ExtraBuys' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'buyNumber' ( (lv_buyNumber_4_0= ruleEInt ) ) otherlv_5= '}' )
            // InternalMDL.g:3239:3: otherlv_0= 'ExtraBuys' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'buyNumber' ( (lv_buyNumber_4_0= ruleEInt ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,78,FOLLOW_31); 

            			newLeafNode(otherlv_0, grammarAccess.getExtraBuysAccess().getExtraBuysKeyword_0());
            		
            // InternalMDL.g:3243:3: ( (lv_name_1_0= ruleEString ) )
            // InternalMDL.g:3244:4: (lv_name_1_0= ruleEString )
            {
            // InternalMDL.g:3244:4: (lv_name_1_0= ruleEString )
            // InternalMDL.g:3245:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getExtraBuysAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_5);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getExtraBuysRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"metaDominoLang.MDL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_74); 

            			newLeafNode(otherlv_2, grammarAccess.getExtraBuysAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,79,FOLLOW_33); 

            			newLeafNode(otherlv_3, grammarAccess.getExtraBuysAccess().getBuyNumberKeyword_3());
            		
            // InternalMDL.g:3270:3: ( (lv_buyNumber_4_0= ruleEInt ) )
            // InternalMDL.g:3271:4: (lv_buyNumber_4_0= ruleEInt )
            {
            // InternalMDL.g:3271:4: (lv_buyNumber_4_0= ruleEInt )
            // InternalMDL.g:3272:5: lv_buyNumber_4_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getExtraBuysAccess().getBuyNumberEIntParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_22);
            lv_buyNumber_4_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getExtraBuysRule());
            					}
            					set(
            						current,
            						"buyNumber",
            						lv_buyNumber_4_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getExtraBuysAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExtraBuys"


    // $ANTLR start "entryRuleExtraCoins"
    // InternalMDL.g:3297:1: entryRuleExtraCoins returns [EObject current=null] : iv_ruleExtraCoins= ruleExtraCoins EOF ;
    public final EObject entryRuleExtraCoins() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExtraCoins = null;


        try {
            // InternalMDL.g:3297:51: (iv_ruleExtraCoins= ruleExtraCoins EOF )
            // InternalMDL.g:3298:2: iv_ruleExtraCoins= ruleExtraCoins EOF
            {
             newCompositeNode(grammarAccess.getExtraCoinsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExtraCoins=ruleExtraCoins();

            state._fsp--;

             current =iv_ruleExtraCoins; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExtraCoins"


    // $ANTLR start "ruleExtraCoins"
    // InternalMDL.g:3304:1: ruleExtraCoins returns [EObject current=null] : (otherlv_0= 'ExtraCoins' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coinNumber' ( (lv_coinNumber_4_0= ruleEInt ) ) otherlv_5= '}' ) ;
    public final EObject ruleExtraCoins() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        AntlrDatatypeRuleToken lv_coinNumber_4_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:3310:2: ( (otherlv_0= 'ExtraCoins' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coinNumber' ( (lv_coinNumber_4_0= ruleEInt ) ) otherlv_5= '}' ) )
            // InternalMDL.g:3311:2: (otherlv_0= 'ExtraCoins' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coinNumber' ( (lv_coinNumber_4_0= ruleEInt ) ) otherlv_5= '}' )
            {
            // InternalMDL.g:3311:2: (otherlv_0= 'ExtraCoins' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coinNumber' ( (lv_coinNumber_4_0= ruleEInt ) ) otherlv_5= '}' )
            // InternalMDL.g:3312:3: otherlv_0= 'ExtraCoins' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coinNumber' ( (lv_coinNumber_4_0= ruleEInt ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,80,FOLLOW_31); 

            			newLeafNode(otherlv_0, grammarAccess.getExtraCoinsAccess().getExtraCoinsKeyword_0());
            		
            // InternalMDL.g:3316:3: ( (lv_name_1_0= ruleEString ) )
            // InternalMDL.g:3317:4: (lv_name_1_0= ruleEString )
            {
            // InternalMDL.g:3317:4: (lv_name_1_0= ruleEString )
            // InternalMDL.g:3318:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getExtraCoinsAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_5);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getExtraCoinsRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"metaDominoLang.MDL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_75); 

            			newLeafNode(otherlv_2, grammarAccess.getExtraCoinsAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,81,FOLLOW_33); 

            			newLeafNode(otherlv_3, grammarAccess.getExtraCoinsAccess().getCoinNumberKeyword_3());
            		
            // InternalMDL.g:3343:3: ( (lv_coinNumber_4_0= ruleEInt ) )
            // InternalMDL.g:3344:4: (lv_coinNumber_4_0= ruleEInt )
            {
            // InternalMDL.g:3344:4: (lv_coinNumber_4_0= ruleEInt )
            // InternalMDL.g:3345:5: lv_coinNumber_4_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getExtraCoinsAccess().getCoinNumberEIntParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_22);
            lv_coinNumber_4_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getExtraCoinsRule());
            					}
            					set(
            						current,
            						"coinNumber",
            						lv_coinNumber_4_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getExtraCoinsAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExtraCoins"


    // $ANTLR start "entryRuleExtraActions"
    // InternalMDL.g:3370:1: entryRuleExtraActions returns [EObject current=null] : iv_ruleExtraActions= ruleExtraActions EOF ;
    public final EObject entryRuleExtraActions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExtraActions = null;


        try {
            // InternalMDL.g:3370:53: (iv_ruleExtraActions= ruleExtraActions EOF )
            // InternalMDL.g:3371:2: iv_ruleExtraActions= ruleExtraActions EOF
            {
             newCompositeNode(grammarAccess.getExtraActionsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExtraActions=ruleExtraActions();

            state._fsp--;

             current =iv_ruleExtraActions; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExtraActions"


    // $ANTLR start "ruleExtraActions"
    // InternalMDL.g:3377:1: ruleExtraActions returns [EObject current=null] : (otherlv_0= 'ExtraActions' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'actionNumber' ( (lv_actionNumber_4_0= ruleEInt ) ) otherlv_5= '}' ) ;
    public final EObject ruleExtraActions() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        AntlrDatatypeRuleToken lv_actionNumber_4_0 = null;



        	enterRule();

        try {
            // InternalMDL.g:3383:2: ( (otherlv_0= 'ExtraActions' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'actionNumber' ( (lv_actionNumber_4_0= ruleEInt ) ) otherlv_5= '}' ) )
            // InternalMDL.g:3384:2: (otherlv_0= 'ExtraActions' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'actionNumber' ( (lv_actionNumber_4_0= ruleEInt ) ) otherlv_5= '}' )
            {
            // InternalMDL.g:3384:2: (otherlv_0= 'ExtraActions' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'actionNumber' ( (lv_actionNumber_4_0= ruleEInt ) ) otherlv_5= '}' )
            // InternalMDL.g:3385:3: otherlv_0= 'ExtraActions' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'actionNumber' ( (lv_actionNumber_4_0= ruleEInt ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,82,FOLLOW_31); 

            			newLeafNode(otherlv_0, grammarAccess.getExtraActionsAccess().getExtraActionsKeyword_0());
            		
            // InternalMDL.g:3389:3: ( (lv_name_1_0= ruleEString ) )
            // InternalMDL.g:3390:4: (lv_name_1_0= ruleEString )
            {
            // InternalMDL.g:3390:4: (lv_name_1_0= ruleEString )
            // InternalMDL.g:3391:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getExtraActionsAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_5);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getExtraActionsRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"metaDominoLang.MDL.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,13,FOLLOW_76); 

            			newLeafNode(otherlv_2, grammarAccess.getExtraActionsAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,83,FOLLOW_33); 

            			newLeafNode(otherlv_3, grammarAccess.getExtraActionsAccess().getActionNumberKeyword_3());
            		
            // InternalMDL.g:3416:3: ( (lv_actionNumber_4_0= ruleEInt ) )
            // InternalMDL.g:3417:4: (lv_actionNumber_4_0= ruleEInt )
            {
            // InternalMDL.g:3417:4: (lv_actionNumber_4_0= ruleEInt )
            // InternalMDL.g:3418:5: lv_actionNumber_4_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getExtraActionsAccess().getActionNumberEIntParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_22);
            lv_actionNumber_4_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getExtraActionsRule());
            					}
            					set(
            						current,
            						"actionNumber",
            						lv_actionNumber_4_0,
            						"metaDominoLang.MDL.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getExtraActionsAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExtraActions"

    // Delegated rules


    protected DFA6 dfa6 = new DFA6(this);
    static final String dfa_1s = "\12\uffff";
    static final String dfa_2s = "\1\4\2\111\7\uffff";
    static final String dfa_3s = "\1\122\2\112\7\uffff";
    static final String dfa_4s = "\3\uffff\1\2\1\3\1\4\1\5\1\6\1\7\1\1";
    static final String dfa_5s = "\12\uffff}>";
    static final String[] dfa_6s = {
            "\1\1\1\2\105\uffff\1\3\1\uffff\1\4\1\5\1\uffff\1\6\1\uffff\1\7",
            "\1\10\1\11",
            "\1\10\1\11",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA6 extends DFA {

        public DFA6(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 6;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "241:2: (this_PutCardInTrash_0= rulePutCardInTrash | this_DrawCards_1= ruleDrawCards | this_PutCardFromPileToDiscard_2= rulePutCardFromPileToDiscard | this_ExtraBuys_3= ruleExtraBuys | this_ExtraCoins_4= ruleExtraCoins | this_ExtraActions_5= ruleExtraActions | this_PutCardFromHandToDiscard_6= rulePutCardFromHandToDiscard )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000011002L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x000000000000C000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000028000000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000F88000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000F08000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000E08000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000000030L,0x0000000000056800L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000C08000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000000808000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000006008000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x14E0000000000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000004008000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000020000000L,0x000000000000003CL});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000000000000000L,0x000000000000003CL});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000780000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000700000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0010000000000040L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000000600000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000018000000000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000040000000000L,0x000000000000003CL});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000040000000000L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0000080000000000L,0x000000000000003CL});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0000200000008000L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_54 = new BitSet(new long[]{0x00C0000000000000L});
    public static final BitSet FOLLOW_55 = new BitSet(new long[]{0x0080000000000000L});
    public static final BitSet FOLLOW_56 = new BitSet(new long[]{0x0100000000000000L});
    public static final BitSet FOLLOW_57 = new BitSet(new long[]{0x0200000000000000L});
    public static final BitSet FOLLOW_58 = new BitSet(new long[]{0x0440000000000000L});
    public static final BitSet FOLLOW_59 = new BitSet(new long[]{0x0400000000000000L});
    public static final BitSet FOLLOW_60 = new BitSet(new long[]{0x0800000000000000L});
    public static final BitSet FOLLOW_61 = new BitSet(new long[]{0x1040000000000000L});
    public static final BitSet FOLLOW_62 = new BitSet(new long[]{0x1000000000000000L});
    public static final BitSet FOLLOW_63 = new BitSet(new long[]{0x2000000000000000L});
    public static final BitSet FOLLOW_64 = new BitSet(new long[]{0x4000000000000000L});
    public static final BitSet FOLLOW_65 = new BitSet(new long[]{0x8000000000004000L});
    public static final BitSet FOLLOW_66 = new BitSet(new long[]{0x0000000000000002L,0x000000000000003CL});
    public static final BitSet FOLLOW_67 = new BitSet(new long[]{0x0000000000008000L,0x0000000000000002L});
    public static final BitSet FOLLOW_68 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000040L});
    public static final BitSet FOLLOW_69 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000080L});
    public static final BitSet FOLLOW_70 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000100L});
    public static final BitSet FOLLOW_71 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000200L});
    public static final BitSet FOLLOW_72 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000400L});
    public static final BitSet FOLLOW_73 = new BitSet(new long[]{0x0000000000000000L,0x0000000000001000L});
    public static final BitSet FOLLOW_74 = new BitSet(new long[]{0x0000000000000000L,0x0000000000008000L});
    public static final BitSet FOLLOW_75 = new BitSet(new long[]{0x0000000000000000L,0x0000000000020000L});
    public static final BitSet FOLLOW_76 = new BitSet(new long[]{0x0000000000000000L,0x0000000000080000L});

}