package dominion.tools;

import dominion.DominionFactory;
import dominion.TreasureCard;
import dominion.VictoryCard;
import dominion.impl.DominionFactoryImpl;

public class BasicCardLibrary {
	static DominionFactory factory = DominionFactoryImpl.eINSTANCE;

	public static TreasureCard getCardCopper() {
		TreasureCard card = factory.createTreasureCard();
		card.setCost(0);
		card.setName("Copper");
		card.setValue(1);
		return card;
	}
	
	public static TreasureCard getCardSilver() {
		TreasureCard card = factory.createTreasureCard();
		card.setCost(3);
		card.setName("Silver");
		card.setValue(2);
		return card;
	}
	
	public static TreasureCard getCardGold() {
		TreasureCard card = factory.createTreasureCard();
		card.setCost(6);
		card.setName("Gold");
		card.setValue(3);
		return card;
	}
	
	public static VictoryCard getCardEstate() {
		VictoryCard card = factory.createVictoryCard();
		card.setCost(2);
		card.setName("Estate");
		card.setVictoryPoints(1);
		return card;
	}
	
	public static VictoryCard getCardDuchy() {
		VictoryCard card = factory.createVictoryCard();
		card.setCost(5);
		card.setName("Duchy");
		card.setVictoryPoints(3);
		return card;
	}
	
	public static VictoryCard getCardProvince() {
		VictoryCard card = factory.createVictoryCard();
		card.setCost(8);
		card.setName("Province");
		card.setVictoryPoints(6);
		return card;
	}
}
