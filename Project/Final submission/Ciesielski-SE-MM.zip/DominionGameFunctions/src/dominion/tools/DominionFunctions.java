package dominion.tools;

import java.util.Collections;

import dominion.CardsPlayedThisTurn;
import dominion.DiscardPile;
import dominion.DominionFactory;
import dominion.DominionGame;
import dominion.DominionProgram;
import dominion.PlayersDeck;
import dominion.PlayersHand;
import dominion.PlayersPlayArea;
import dominion.TreasureCard;
import dominion.VictoryCard;
import dominion.impl.DominionFactoryImpl;

public class DominionFunctions {
	public static DominionGame generate2PlayersGame() {
		DominionFactory factory = DominionFactoryImpl.eINSTANCE;
		DominionGame game = factory.createDominionGame();
		
		PlayersPlayArea player1 = factory.createPlayersPlayArea();
		PlayersPlayArea player2 = factory.createPlayersPlayArea();

		PlayersDeck deck1 = factory.createPlayersDeck();
		PlayersDeck deck2 = factory.createPlayersDeck();
		for (int i = 1; i <= 7; i++ ) {
			TreasureCard card1 = BasicCardLibrary.getCardCopper();
			TreasureCard card2 = BasicCardLibrary.getCardCopper();
			deck1.getCards().add(card1);
			deck2.getCards().add(card2);
		}
		for (int i =1; i <=3; i++) {
			VictoryCard card1 = BasicCardLibrary.getCardEstate();
			VictoryCard card2 = BasicCardLibrary.getCardEstate();
			deck1.getCards().add(card1);
			deck2.getCards().add(card2);
		}
		deck1.setCardsNumber(10);
		deck2.setCardsNumber(10);
		player1.setPlayers_deck(deck1);
		player2.setPlayers_deck(deck2);
		player1.setPlayersName("Player 1");
		player2.setPlayersName("Turing machine");
		
		CardsPlayedThisTurn played1 = factory.createCardsPlayedThisTurn();
		CardsPlayedThisTurn played2 = factory.createCardsPlayedThisTurn();
		played1.setCardsNumber(0);
		played2.setCardsNumber(0);
		player1.setCards_played_this_turn(played1);
		player2.setCards_played_this_turn(played2);
		DiscardPile discard1 = factory.createDiscardPile();
		DiscardPile discard2 = factory.createDiscardPile();
		discard1.setCardsNumber(0);
		discard2.setCardsNumber(0);
		player1.setDiscard_pile(discard1);
		player2.setDiscard_pile(discard2);
		PlayersHand hand1 = factory.createPlayersHand();
		PlayersHand hand2 = factory.createPlayersHand();
		hand1.setCardsNumber(0);
		hand2.setCardsNumber(0);
		player1.setPlayers_hand(hand1);
		player2.setPlayers_hand(hand2);
		
//		Collections.shuffle(player1.getPlayers_deck().getCards());
//		Collections.shuffle(player2.getPlayers_deck().getCards());
		game.getPlayersplayarea().add(player1);
		game.getPlayersplayarea().add(player2);
		return game;
		
	}
	public static DominionProgram generateProgram() {
		DominionFactory factory = DominionFactoryImpl.eINSTANCE;
		DominionProgram program = factory.createDominionProgram();
		program.setDominiongame(generate2PlayersGame());
		System.out.println(program.getDominiongame());
		return program;
	}
	public static PlayersHand drawNCards(PlayersPlayArea player, int cardNumber) {
		assert player.getPlayers_deck().getCardsNumber() >= cardNumber : "Need to reshuffle";
		player.getPlayers_hand().getCards().addAll(player.getPlayers_deck().getCards().subList(0, cardNumber));
		player.getPlayers_hand().setCardsNumber(cardNumber);
		player.getPlayers_deck().setCardsNumber(player.getPlayers_deck().getCardsNumber() - cardNumber);
		return player.getPlayers_hand();
	}
	
//	public static PlayersHand reshuffleDeck(PlayersPlayArea player) {
//		
//	}
}
