package dominion_strategy_lang.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import dominion_strategy_lang.services.MyDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalMyDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_STRING", "RULE_ID", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Strategy'", "'{'", "'Action:'", "'Buy:'", "'}'", "','", "'buy'", "'play'", "'If'", "':'", "'While'", "'-'", "'isPubliclyVisible'", "'isVisibleToOwner'", "'cost'", "'value'", "'victoryPoints'", "'PutCardInTrash'", "'DrawCards'", "'cardNumber'", "'PutCardFromPileToDiscard'", "'discard_pile'", "'ExtraBuys'", "'buyNumber'", "'ExtraCoins'", "'coinNumber'", "'ExtraActions'", "'actionNumber'", "'PutCardFromHandToDiscard'", "'you'", "'have'", "'EnoughCoins'", "'newAttribute'"
    };
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int RULE_ID=6;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=4;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalMyDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalMyDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalMyDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalMyDsl.g"; }



     	private MyDslGrammarAccess grammarAccess;

        public InternalMyDslParser(TokenStream input, MyDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Strategy";
       	}

       	@Override
       	protected MyDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleStrategy"
    // InternalMyDsl.g:64:1: entryRuleStrategy returns [EObject current=null] : iv_ruleStrategy= ruleStrategy EOF ;
    public final EObject entryRuleStrategy() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStrategy = null;


        try {
            // InternalMyDsl.g:64:49: (iv_ruleStrategy= ruleStrategy EOF )
            // InternalMyDsl.g:65:2: iv_ruleStrategy= ruleStrategy EOF
            {
             newCompositeNode(grammarAccess.getStrategyRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStrategy=ruleStrategy();

            state._fsp--;

             current =iv_ruleStrategy; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStrategy"


    // $ANTLR start "ruleStrategy"
    // InternalMyDsl.g:71:1: ruleStrategy returns [EObject current=null] : (otherlv_0= 'Strategy' otherlv_1= '{' (otherlv_2= 'Action:' ( (lv_actionphase_3_0= ruleActionPhase ) ) )? otherlv_4= 'Buy:' ( (lv_buyphase_5_0= ruleBuyPhase ) ) otherlv_6= '}' ) ;
    public final EObject ruleStrategy() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        EObject lv_actionphase_3_0 = null;

        EObject lv_buyphase_5_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:77:2: ( (otherlv_0= 'Strategy' otherlv_1= '{' (otherlv_2= 'Action:' ( (lv_actionphase_3_0= ruleActionPhase ) ) )? otherlv_4= 'Buy:' ( (lv_buyphase_5_0= ruleBuyPhase ) ) otherlv_6= '}' ) )
            // InternalMyDsl.g:78:2: (otherlv_0= 'Strategy' otherlv_1= '{' (otherlv_2= 'Action:' ( (lv_actionphase_3_0= ruleActionPhase ) ) )? otherlv_4= 'Buy:' ( (lv_buyphase_5_0= ruleBuyPhase ) ) otherlv_6= '}' )
            {
            // InternalMyDsl.g:78:2: (otherlv_0= 'Strategy' otherlv_1= '{' (otherlv_2= 'Action:' ( (lv_actionphase_3_0= ruleActionPhase ) ) )? otherlv_4= 'Buy:' ( (lv_buyphase_5_0= ruleBuyPhase ) ) otherlv_6= '}' )
            // InternalMyDsl.g:79:3: otherlv_0= 'Strategy' otherlv_1= '{' (otherlv_2= 'Action:' ( (lv_actionphase_3_0= ruleActionPhase ) ) )? otherlv_4= 'Buy:' ( (lv_buyphase_5_0= ruleBuyPhase ) ) otherlv_6= '}'
            {
            otherlv_0=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getStrategyAccess().getStrategyKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getStrategyAccess().getLeftCurlyBracketKeyword_1());
            		
            // InternalMyDsl.g:87:3: (otherlv_2= 'Action:' ( (lv_actionphase_3_0= ruleActionPhase ) ) )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==13) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // InternalMyDsl.g:88:4: otherlv_2= 'Action:' ( (lv_actionphase_3_0= ruleActionPhase ) )
                    {
                    otherlv_2=(Token)match(input,13,FOLLOW_5); 

                    				newLeafNode(otherlv_2, grammarAccess.getStrategyAccess().getActionKeyword_2_0());
                    			
                    // InternalMyDsl.g:92:4: ( (lv_actionphase_3_0= ruleActionPhase ) )
                    // InternalMyDsl.g:93:5: (lv_actionphase_3_0= ruleActionPhase )
                    {
                    // InternalMyDsl.g:93:5: (lv_actionphase_3_0= ruleActionPhase )
                    // InternalMyDsl.g:94:6: lv_actionphase_3_0= ruleActionPhase
                    {

                    						newCompositeNode(grammarAccess.getStrategyAccess().getActionphaseActionPhaseParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_6);
                    lv_actionphase_3_0=ruleActionPhase();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getStrategyRule());
                    						}
                    						set(
                    							current,
                    							"actionphase",
                    							lv_actionphase_3_0,
                    							"dominion_strategy_lang.MyDsl.ActionPhase");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_4=(Token)match(input,14,FOLLOW_7); 

            			newLeafNode(otherlv_4, grammarAccess.getStrategyAccess().getBuyKeyword_3());
            		
            // InternalMyDsl.g:116:3: ( (lv_buyphase_5_0= ruleBuyPhase ) )
            // InternalMyDsl.g:117:4: (lv_buyphase_5_0= ruleBuyPhase )
            {
            // InternalMyDsl.g:117:4: (lv_buyphase_5_0= ruleBuyPhase )
            // InternalMyDsl.g:118:5: lv_buyphase_5_0= ruleBuyPhase
            {

            					newCompositeNode(grammarAccess.getStrategyAccess().getBuyphaseBuyPhaseParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_8);
            lv_buyphase_5_0=ruleBuyPhase();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getStrategyRule());
            					}
            					set(
            						current,
            						"buyphase",
            						lv_buyphase_5_0,
            						"dominion_strategy_lang.MyDsl.BuyPhase");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_6=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_6, grammarAccess.getStrategyAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStrategy"


    // $ANTLR start "entryRulePlayersAction"
    // InternalMyDsl.g:143:1: entryRulePlayersAction returns [EObject current=null] : iv_rulePlayersAction= rulePlayersAction EOF ;
    public final EObject entryRulePlayersAction() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePlayersAction = null;


        try {
            // InternalMyDsl.g:143:54: (iv_rulePlayersAction= rulePlayersAction EOF )
            // InternalMyDsl.g:144:2: iv_rulePlayersAction= rulePlayersAction EOF
            {
             newCompositeNode(grammarAccess.getPlayersActionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePlayersAction=rulePlayersAction();

            state._fsp--;

             current =iv_rulePlayersAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePlayersAction"


    // $ANTLR start "rulePlayersAction"
    // InternalMyDsl.g:150:1: rulePlayersAction returns [EObject current=null] : (this_BuyCard_0= ruleBuyCard | this_PlayAction_1= rulePlayAction | this_IfAction_2= ruleIfAction | this_WhileAction_3= ruleWhileAction ) ;
    public final EObject rulePlayersAction() throws RecognitionException {
        EObject current = null;

        EObject this_BuyCard_0 = null;

        EObject this_PlayAction_1 = null;

        EObject this_IfAction_2 = null;

        EObject this_WhileAction_3 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:156:2: ( (this_BuyCard_0= ruleBuyCard | this_PlayAction_1= rulePlayAction | this_IfAction_2= ruleIfAction | this_WhileAction_3= ruleWhileAction ) )
            // InternalMyDsl.g:157:2: (this_BuyCard_0= ruleBuyCard | this_PlayAction_1= rulePlayAction | this_IfAction_2= ruleIfAction | this_WhileAction_3= ruleWhileAction )
            {
            // InternalMyDsl.g:157:2: (this_BuyCard_0= ruleBuyCard | this_PlayAction_1= rulePlayAction | this_IfAction_2= ruleIfAction | this_WhileAction_3= ruleWhileAction )
            int alt2=4;
            switch ( input.LA(1) ) {
            case 17:
                {
                alt2=1;
                }
                break;
            case 18:
                {
                alt2=2;
                }
                break;
            case 19:
                {
                alt2=3;
                }
                break;
            case 21:
                {
                alt2=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalMyDsl.g:158:3: this_BuyCard_0= ruleBuyCard
                    {

                    			newCompositeNode(grammarAccess.getPlayersActionAccess().getBuyCardParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_BuyCard_0=ruleBuyCard();

                    state._fsp--;


                    			current = this_BuyCard_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:167:3: this_PlayAction_1= rulePlayAction
                    {

                    			newCompositeNode(grammarAccess.getPlayersActionAccess().getPlayActionParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_PlayAction_1=rulePlayAction();

                    state._fsp--;


                    			current = this_PlayAction_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:176:3: this_IfAction_2= ruleIfAction
                    {

                    			newCompositeNode(grammarAccess.getPlayersActionAccess().getIfActionParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_IfAction_2=ruleIfAction();

                    state._fsp--;


                    			current = this_IfAction_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalMyDsl.g:185:3: this_WhileAction_3= ruleWhileAction
                    {

                    			newCompositeNode(grammarAccess.getPlayersActionAccess().getWhileActionParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_WhileAction_3=ruleWhileAction();

                    state._fsp--;


                    			current = this_WhileAction_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePlayersAction"


    // $ANTLR start "entryRuleCard"
    // InternalMyDsl.g:197:1: entryRuleCard returns [EObject current=null] : iv_ruleCard= ruleCard EOF ;
    public final EObject entryRuleCard() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCard = null;


        try {
            // InternalMyDsl.g:197:45: (iv_ruleCard= ruleCard EOF )
            // InternalMyDsl.g:198:2: iv_ruleCard= ruleCard EOF
            {
             newCompositeNode(grammarAccess.getCardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCard=ruleCard();

            state._fsp--;

             current =iv_ruleCard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCard"


    // $ANTLR start "ruleCard"
    // InternalMyDsl.g:204:1: ruleCard returns [EObject current=null] : (this_TreasureCard_0= ruleTreasureCard | this_VictoryCard_1= ruleVictoryCard | this_ActionCard_2= ruleActionCard ) ;
    public final EObject ruleCard() throws RecognitionException {
        EObject current = null;

        EObject this_TreasureCard_0 = null;

        EObject this_VictoryCard_1 = null;

        EObject this_ActionCard_2 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:210:2: ( (this_TreasureCard_0= ruleTreasureCard | this_VictoryCard_1= ruleVictoryCard | this_ActionCard_2= ruleActionCard ) )
            // InternalMyDsl.g:211:2: (this_TreasureCard_0= ruleTreasureCard | this_VictoryCard_1= ruleVictoryCard | this_ActionCard_2= ruleActionCard )
            {
            // InternalMyDsl.g:211:2: (this_TreasureCard_0= ruleTreasureCard | this_VictoryCard_1= ruleVictoryCard | this_ActionCard_2= ruleActionCard )
            int alt3=3;
            alt3 = dfa3.predict(input);
            switch (alt3) {
                case 1 :
                    // InternalMyDsl.g:212:3: this_TreasureCard_0= ruleTreasureCard
                    {

                    			newCompositeNode(grammarAccess.getCardAccess().getTreasureCardParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_TreasureCard_0=ruleTreasureCard();

                    state._fsp--;


                    			current = this_TreasureCard_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:221:3: this_VictoryCard_1= ruleVictoryCard
                    {

                    			newCompositeNode(grammarAccess.getCardAccess().getVictoryCardParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_VictoryCard_1=ruleVictoryCard();

                    state._fsp--;


                    			current = this_VictoryCard_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalMyDsl.g:230:3: this_ActionCard_2= ruleActionCard
                    {

                    			newCompositeNode(grammarAccess.getCardAccess().getActionCardParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_ActionCard_2=ruleActionCard();

                    state._fsp--;


                    			current = this_ActionCard_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCard"


    // $ANTLR start "entryRuleExpression"
    // InternalMyDsl.g:242:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // InternalMyDsl.g:242:51: (iv_ruleExpression= ruleExpression EOF )
            // InternalMyDsl.g:243:2: iv_ruleExpression= ruleExpression EOF
            {
             newCompositeNode(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExpression=ruleExpression();

            state._fsp--;

             current =iv_ruleExpression; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // InternalMyDsl.g:249:1: ruleExpression returns [EObject current=null] : (this_FittingCard_0= ruleFittingCard | this_EnoughCoins_1= ruleEnoughCoins ) ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_FittingCard_0 = null;

        EObject this_EnoughCoins_1 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:255:2: ( (this_FittingCard_0= ruleFittingCard | this_EnoughCoins_1= ruleEnoughCoins ) )
            // InternalMyDsl.g:256:2: (this_FittingCard_0= ruleFittingCard | this_EnoughCoins_1= ruleEnoughCoins )
            {
            // InternalMyDsl.g:256:2: (this_FittingCard_0= ruleFittingCard | this_EnoughCoins_1= ruleEnoughCoins )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==40) ) {
                alt4=1;
            }
            else if ( (LA4_0==42) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalMyDsl.g:257:3: this_FittingCard_0= ruleFittingCard
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getFittingCardParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_FittingCard_0=ruleFittingCard();

                    state._fsp--;


                    			current = this_FittingCard_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:266:3: this_EnoughCoins_1= ruleEnoughCoins
                    {

                    			newCompositeNode(grammarAccess.getExpressionAccess().getEnoughCoinsParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_EnoughCoins_1=ruleEnoughCoins();

                    state._fsp--;


                    			current = this_EnoughCoins_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleActionPhase"
    // InternalMyDsl.g:278:1: entryRuleActionPhase returns [EObject current=null] : iv_ruleActionPhase= ruleActionPhase EOF ;
    public final EObject entryRuleActionPhase() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleActionPhase = null;


        try {
            // InternalMyDsl.g:278:52: (iv_ruleActionPhase= ruleActionPhase EOF )
            // InternalMyDsl.g:279:2: iv_ruleActionPhase= ruleActionPhase EOF
            {
             newCompositeNode(grammarAccess.getActionPhaseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleActionPhase=ruleActionPhase();

            state._fsp--;

             current =iv_ruleActionPhase; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleActionPhase"


    // $ANTLR start "ruleActionPhase"
    // InternalMyDsl.g:285:1: ruleActionPhase returns [EObject current=null] : ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )* )? ) ;
    public final EObject ruleActionPhase() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        EObject lv_playersactions_1_0 = null;

        EObject lv_playersactions_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:291:2: ( ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )* )? ) )
            // InternalMyDsl.g:292:2: ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )* )? )
            {
            // InternalMyDsl.g:292:2: ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )* )? )
            // InternalMyDsl.g:293:3: () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )* )?
            {
            // InternalMyDsl.g:293:3: ()
            // InternalMyDsl.g:294:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getActionPhaseAccess().getActionPhaseAction_0(),
            					current);
            			

            }

            // InternalMyDsl.g:300:3: ( ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )* )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( ((LA6_0>=17 && LA6_0<=19)||LA6_0==21) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalMyDsl.g:301:4: ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )*
                    {
                    // InternalMyDsl.g:301:4: ( (lv_playersactions_1_0= rulePlayersAction ) )
                    // InternalMyDsl.g:302:5: (lv_playersactions_1_0= rulePlayersAction )
                    {
                    // InternalMyDsl.g:302:5: (lv_playersactions_1_0= rulePlayersAction )
                    // InternalMyDsl.g:303:6: lv_playersactions_1_0= rulePlayersAction
                    {

                    						newCompositeNode(grammarAccess.getActionPhaseAccess().getPlayersactionsPlayersActionParserRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_9);
                    lv_playersactions_1_0=rulePlayersAction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getActionPhaseRule());
                    						}
                    						add(
                    							current,
                    							"playersactions",
                    							lv_playersactions_1_0,
                    							"dominion_strategy_lang.MyDsl.PlayersAction");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMyDsl.g:320:4: (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )*
                    loop5:
                    do {
                        int alt5=2;
                        int LA5_0 = input.LA(1);

                        if ( (LA5_0==16) ) {
                            alt5=1;
                        }


                        switch (alt5) {
                    	case 1 :
                    	    // InternalMyDsl.g:321:5: otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) )
                    	    {
                    	    otherlv_2=(Token)match(input,16,FOLLOW_10); 

                    	    					newLeafNode(otherlv_2, grammarAccess.getActionPhaseAccess().getCommaKeyword_1_1_0());
                    	    				
                    	    // InternalMyDsl.g:325:5: ( (lv_playersactions_3_0= rulePlayersAction ) )
                    	    // InternalMyDsl.g:326:6: (lv_playersactions_3_0= rulePlayersAction )
                    	    {
                    	    // InternalMyDsl.g:326:6: (lv_playersactions_3_0= rulePlayersAction )
                    	    // InternalMyDsl.g:327:7: lv_playersactions_3_0= rulePlayersAction
                    	    {

                    	    							newCompositeNode(grammarAccess.getActionPhaseAccess().getPlayersactionsPlayersActionParserRuleCall_1_1_1_0());
                    	    						
                    	    pushFollow(FOLLOW_9);
                    	    lv_playersactions_3_0=rulePlayersAction();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getActionPhaseRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"playersactions",
                    	    								lv_playersactions_3_0,
                    	    								"dominion_strategy_lang.MyDsl.PlayersAction");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop5;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleActionPhase"


    // $ANTLR start "entryRuleBuyPhase"
    // InternalMyDsl.g:350:1: entryRuleBuyPhase returns [EObject current=null] : iv_ruleBuyPhase= ruleBuyPhase EOF ;
    public final EObject entryRuleBuyPhase() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBuyPhase = null;


        try {
            // InternalMyDsl.g:350:49: (iv_ruleBuyPhase= ruleBuyPhase EOF )
            // InternalMyDsl.g:351:2: iv_ruleBuyPhase= ruleBuyPhase EOF
            {
             newCompositeNode(grammarAccess.getBuyPhaseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBuyPhase=ruleBuyPhase();

            state._fsp--;

             current =iv_ruleBuyPhase; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBuyPhase"


    // $ANTLR start "ruleBuyPhase"
    // InternalMyDsl.g:357:1: ruleBuyPhase returns [EObject current=null] : ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )* )? ) ;
    public final EObject ruleBuyPhase() throws RecognitionException {
        EObject current = null;

        Token otherlv_2=null;
        EObject lv_playersactions_1_0 = null;

        EObject lv_playersactions_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:363:2: ( ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )* )? ) )
            // InternalMyDsl.g:364:2: ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )* )? )
            {
            // InternalMyDsl.g:364:2: ( () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )* )? )
            // InternalMyDsl.g:365:3: () ( ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )* )?
            {
            // InternalMyDsl.g:365:3: ()
            // InternalMyDsl.g:366:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getBuyPhaseAccess().getBuyPhaseAction_0(),
            					current);
            			

            }

            // InternalMyDsl.g:372:3: ( ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )* )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( ((LA8_0>=17 && LA8_0<=19)||LA8_0==21) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalMyDsl.g:373:4: ( (lv_playersactions_1_0= rulePlayersAction ) ) (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )*
                    {
                    // InternalMyDsl.g:373:4: ( (lv_playersactions_1_0= rulePlayersAction ) )
                    // InternalMyDsl.g:374:5: (lv_playersactions_1_0= rulePlayersAction )
                    {
                    // InternalMyDsl.g:374:5: (lv_playersactions_1_0= rulePlayersAction )
                    // InternalMyDsl.g:375:6: lv_playersactions_1_0= rulePlayersAction
                    {

                    						newCompositeNode(grammarAccess.getBuyPhaseAccess().getPlayersactionsPlayersActionParserRuleCall_1_0_0());
                    					
                    pushFollow(FOLLOW_9);
                    lv_playersactions_1_0=rulePlayersAction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getBuyPhaseRule());
                    						}
                    						add(
                    							current,
                    							"playersactions",
                    							lv_playersactions_1_0,
                    							"dominion_strategy_lang.MyDsl.PlayersAction");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalMyDsl.g:392:4: (otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) ) )*
                    loop7:
                    do {
                        int alt7=2;
                        int LA7_0 = input.LA(1);

                        if ( (LA7_0==16) ) {
                            alt7=1;
                        }


                        switch (alt7) {
                    	case 1 :
                    	    // InternalMyDsl.g:393:5: otherlv_2= ',' ( (lv_playersactions_3_0= rulePlayersAction ) )
                    	    {
                    	    otherlv_2=(Token)match(input,16,FOLLOW_10); 

                    	    					newLeafNode(otherlv_2, grammarAccess.getBuyPhaseAccess().getCommaKeyword_1_1_0());
                    	    				
                    	    // InternalMyDsl.g:397:5: ( (lv_playersactions_3_0= rulePlayersAction ) )
                    	    // InternalMyDsl.g:398:6: (lv_playersactions_3_0= rulePlayersAction )
                    	    {
                    	    // InternalMyDsl.g:398:6: (lv_playersactions_3_0= rulePlayersAction )
                    	    // InternalMyDsl.g:399:7: lv_playersactions_3_0= rulePlayersAction
                    	    {

                    	    							newCompositeNode(grammarAccess.getBuyPhaseAccess().getPlayersactionsPlayersActionParserRuleCall_1_1_1_0());
                    	    						
                    	    pushFollow(FOLLOW_9);
                    	    lv_playersactions_3_0=rulePlayersAction();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getBuyPhaseRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"playersactions",
                    	    								lv_playersactions_3_0,
                    	    								"dominion_strategy_lang.MyDsl.PlayersAction");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop7;
                        }
                    } while (true);


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBuyPhase"


    // $ANTLR start "entryRuleBuyCard"
    // InternalMyDsl.g:422:1: entryRuleBuyCard returns [EObject current=null] : iv_ruleBuyCard= ruleBuyCard EOF ;
    public final EObject entryRuleBuyCard() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBuyCard = null;


        try {
            // InternalMyDsl.g:422:48: (iv_ruleBuyCard= ruleBuyCard EOF )
            // InternalMyDsl.g:423:2: iv_ruleBuyCard= ruleBuyCard EOF
            {
             newCompositeNode(grammarAccess.getBuyCardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBuyCard=ruleBuyCard();

            state._fsp--;

             current =iv_ruleBuyCard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBuyCard"


    // $ANTLR start "ruleBuyCard"
    // InternalMyDsl.g:429:1: ruleBuyCard returns [EObject current=null] : (otherlv_0= 'buy' ( ( ruleEString ) ) ) ;
    public final EObject ruleBuyCard() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;


        	enterRule();

        try {
            // InternalMyDsl.g:435:2: ( (otherlv_0= 'buy' ( ( ruleEString ) ) ) )
            // InternalMyDsl.g:436:2: (otherlv_0= 'buy' ( ( ruleEString ) ) )
            {
            // InternalMyDsl.g:436:2: (otherlv_0= 'buy' ( ( ruleEString ) ) )
            // InternalMyDsl.g:437:3: otherlv_0= 'buy' ( ( ruleEString ) )
            {
            otherlv_0=(Token)match(input,17,FOLLOW_11); 

            			newLeafNode(otherlv_0, grammarAccess.getBuyCardAccess().getBuyKeyword_0());
            		
            // InternalMyDsl.g:441:3: ( ( ruleEString ) )
            // InternalMyDsl.g:442:4: ( ruleEString )
            {
            // InternalMyDsl.g:442:4: ( ruleEString )
            // InternalMyDsl.g:443:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getBuyCardRule());
            					}
            				

            					newCompositeNode(grammarAccess.getBuyCardAccess().getCardCardCrossReference_1_0());
            				
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBuyCard"


    // $ANTLR start "entryRulePlayAction"
    // InternalMyDsl.g:461:1: entryRulePlayAction returns [EObject current=null] : iv_rulePlayAction= rulePlayAction EOF ;
    public final EObject entryRulePlayAction() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePlayAction = null;


        try {
            // InternalMyDsl.g:461:51: (iv_rulePlayAction= rulePlayAction EOF )
            // InternalMyDsl.g:462:2: iv_rulePlayAction= rulePlayAction EOF
            {
             newCompositeNode(grammarAccess.getPlayActionRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePlayAction=rulePlayAction();

            state._fsp--;

             current =iv_rulePlayAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePlayAction"


    // $ANTLR start "rulePlayAction"
    // InternalMyDsl.g:468:1: rulePlayAction returns [EObject current=null] : (otherlv_0= 'play' ( ( ruleEString ) ) ) ;
    public final EObject rulePlayAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;


        	enterRule();

        try {
            // InternalMyDsl.g:474:2: ( (otherlv_0= 'play' ( ( ruleEString ) ) ) )
            // InternalMyDsl.g:475:2: (otherlv_0= 'play' ( ( ruleEString ) ) )
            {
            // InternalMyDsl.g:475:2: (otherlv_0= 'play' ( ( ruleEString ) ) )
            // InternalMyDsl.g:476:3: otherlv_0= 'play' ( ( ruleEString ) )
            {
            otherlv_0=(Token)match(input,18,FOLLOW_11); 

            			newLeafNode(otherlv_0, grammarAccess.getPlayActionAccess().getPlayKeyword_0());
            		
            // InternalMyDsl.g:480:3: ( ( ruleEString ) )
            // InternalMyDsl.g:481:4: ( ruleEString )
            {
            // InternalMyDsl.g:481:4: ( ruleEString )
            // InternalMyDsl.g:482:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPlayActionRule());
            					}
            				

            					newCompositeNode(grammarAccess.getPlayActionAccess().getAction_cardCardCrossReference_1_0());
            				
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePlayAction"


    // $ANTLR start "entryRuleIfAction"
    // InternalMyDsl.g:500:1: entryRuleIfAction returns [EObject current=null] : iv_ruleIfAction= ruleIfAction EOF ;
    public final EObject entryRuleIfAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIfAction = null;


        try {
            // InternalMyDsl.g:500:49: (iv_ruleIfAction= ruleIfAction EOF )
            // InternalMyDsl.g:501:2: iv_ruleIfAction= ruleIfAction EOF
            {
             newCompositeNode(grammarAccess.getIfActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIfAction=ruleIfAction();

            state._fsp--;

             current =iv_ruleIfAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIfAction"


    // $ANTLR start "ruleIfAction"
    // InternalMyDsl.g:507:1: ruleIfAction returns [EObject current=null] : (otherlv_0= 'If' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_consequent_action_3_0= rulePlayersAction ) ) ) ;
    public final EObject ruleIfAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject lv_condition_1_0 = null;

        EObject lv_consequent_action_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:513:2: ( (otherlv_0= 'If' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_consequent_action_3_0= rulePlayersAction ) ) ) )
            // InternalMyDsl.g:514:2: (otherlv_0= 'If' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_consequent_action_3_0= rulePlayersAction ) ) )
            {
            // InternalMyDsl.g:514:2: (otherlv_0= 'If' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_consequent_action_3_0= rulePlayersAction ) ) )
            // InternalMyDsl.g:515:3: otherlv_0= 'If' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_consequent_action_3_0= rulePlayersAction ) )
            {
            otherlv_0=(Token)match(input,19,FOLLOW_12); 

            			newLeafNode(otherlv_0, grammarAccess.getIfActionAccess().getIfKeyword_0());
            		
            // InternalMyDsl.g:519:3: ( (lv_condition_1_0= ruleExpression ) )
            // InternalMyDsl.g:520:4: (lv_condition_1_0= ruleExpression )
            {
            // InternalMyDsl.g:520:4: (lv_condition_1_0= ruleExpression )
            // InternalMyDsl.g:521:5: lv_condition_1_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getIfActionAccess().getConditionExpressionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_13);
            lv_condition_1_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIfActionRule());
            					}
            					set(
            						current,
            						"condition",
            						lv_condition_1_0,
            						"dominion_strategy_lang.MyDsl.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,20,FOLLOW_10); 

            			newLeafNode(otherlv_2, grammarAccess.getIfActionAccess().getColonKeyword_2());
            		
            // InternalMyDsl.g:542:3: ( (lv_consequent_action_3_0= rulePlayersAction ) )
            // InternalMyDsl.g:543:4: (lv_consequent_action_3_0= rulePlayersAction )
            {
            // InternalMyDsl.g:543:4: (lv_consequent_action_3_0= rulePlayersAction )
            // InternalMyDsl.g:544:5: lv_consequent_action_3_0= rulePlayersAction
            {

            					newCompositeNode(grammarAccess.getIfActionAccess().getConsequent_actionPlayersActionParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_consequent_action_3_0=rulePlayersAction();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIfActionRule());
            					}
            					set(
            						current,
            						"consequent_action",
            						lv_consequent_action_3_0,
            						"dominion_strategy_lang.MyDsl.PlayersAction");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIfAction"


    // $ANTLR start "entryRuleWhileAction"
    // InternalMyDsl.g:565:1: entryRuleWhileAction returns [EObject current=null] : iv_ruleWhileAction= ruleWhileAction EOF ;
    public final EObject entryRuleWhileAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleWhileAction = null;


        try {
            // InternalMyDsl.g:565:52: (iv_ruleWhileAction= ruleWhileAction EOF )
            // InternalMyDsl.g:566:2: iv_ruleWhileAction= ruleWhileAction EOF
            {
             newCompositeNode(grammarAccess.getWhileActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleWhileAction=ruleWhileAction();

            state._fsp--;

             current =iv_ruleWhileAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleWhileAction"


    // $ANTLR start "ruleWhileAction"
    // InternalMyDsl.g:572:1: ruleWhileAction returns [EObject current=null] : (otherlv_0= 'While' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_playersaction_3_0= rulePlayersAction ) ) ) ;
    public final EObject ruleWhileAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject lv_condition_1_0 = null;

        EObject lv_playersaction_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:578:2: ( (otherlv_0= 'While' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_playersaction_3_0= rulePlayersAction ) ) ) )
            // InternalMyDsl.g:579:2: (otherlv_0= 'While' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_playersaction_3_0= rulePlayersAction ) ) )
            {
            // InternalMyDsl.g:579:2: (otherlv_0= 'While' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_playersaction_3_0= rulePlayersAction ) ) )
            // InternalMyDsl.g:580:3: otherlv_0= 'While' ( (lv_condition_1_0= ruleExpression ) ) otherlv_2= ':' ( (lv_playersaction_3_0= rulePlayersAction ) )
            {
            otherlv_0=(Token)match(input,21,FOLLOW_12); 

            			newLeafNode(otherlv_0, grammarAccess.getWhileActionAccess().getWhileKeyword_0());
            		
            // InternalMyDsl.g:584:3: ( (lv_condition_1_0= ruleExpression ) )
            // InternalMyDsl.g:585:4: (lv_condition_1_0= ruleExpression )
            {
            // InternalMyDsl.g:585:4: (lv_condition_1_0= ruleExpression )
            // InternalMyDsl.g:586:5: lv_condition_1_0= ruleExpression
            {

            					newCompositeNode(grammarAccess.getWhileActionAccess().getConditionExpressionParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_13);
            lv_condition_1_0=ruleExpression();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getWhileActionRule());
            					}
            					set(
            						current,
            						"condition",
            						lv_condition_1_0,
            						"dominion_strategy_lang.MyDsl.Expression");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,20,FOLLOW_10); 

            			newLeafNode(otherlv_2, grammarAccess.getWhileActionAccess().getColonKeyword_2());
            		
            // InternalMyDsl.g:607:3: ( (lv_playersaction_3_0= rulePlayersAction ) )
            // InternalMyDsl.g:608:4: (lv_playersaction_3_0= rulePlayersAction )
            {
            // InternalMyDsl.g:608:4: (lv_playersaction_3_0= rulePlayersAction )
            // InternalMyDsl.g:609:5: lv_playersaction_3_0= rulePlayersAction
            {

            					newCompositeNode(grammarAccess.getWhileActionAccess().getPlayersactionPlayersActionParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_playersaction_3_0=rulePlayersAction();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getWhileActionRule());
            					}
            					set(
            						current,
            						"playersaction",
            						lv_playersaction_3_0,
            						"dominion_strategy_lang.MyDsl.PlayersAction");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleWhileAction"


    // $ANTLR start "entryRuleEInt"
    // InternalMyDsl.g:630:1: entryRuleEInt returns [String current=null] : iv_ruleEInt= ruleEInt EOF ;
    public final String entryRuleEInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEInt = null;


        try {
            // InternalMyDsl.g:630:44: (iv_ruleEInt= ruleEInt EOF )
            // InternalMyDsl.g:631:2: iv_ruleEInt= ruleEInt EOF
            {
             newCompositeNode(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEInt=ruleEInt();

            state._fsp--;

             current =iv_ruleEInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalMyDsl.g:637:1: ruleEInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? this_INT_1= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleEInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;


        	enterRule();

        try {
            // InternalMyDsl.g:643:2: ( ( (kw= '-' )? this_INT_1= RULE_INT ) )
            // InternalMyDsl.g:644:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            {
            // InternalMyDsl.g:644:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            // InternalMyDsl.g:645:3: (kw= '-' )? this_INT_1= RULE_INT
            {
            // InternalMyDsl.g:645:3: (kw= '-' )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==22) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalMyDsl.g:646:4: kw= '-'
                    {
                    kw=(Token)match(input,22,FOLLOW_14); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEIntAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            this_INT_1=(Token)match(input,RULE_INT,FOLLOW_2); 

            			current.merge(this_INT_1);
            		

            			newLeafNode(this_INT_1, grammarAccess.getEIntAccess().getINTTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleEString"
    // InternalMyDsl.g:663:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalMyDsl.g:663:47: (iv_ruleEString= ruleEString EOF )
            // InternalMyDsl.g:664:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalMyDsl.g:670:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalMyDsl.g:676:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalMyDsl.g:677:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalMyDsl.g:677:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==RULE_STRING) ) {
                alt10=1;
            }
            else if ( (LA10_0==RULE_ID) ) {
                alt10=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }
            switch (alt10) {
                case 1 :
                    // InternalMyDsl.g:678:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalMyDsl.g:686:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "entryRuleTreasureCard"
    // InternalMyDsl.g:697:1: entryRuleTreasureCard returns [EObject current=null] : iv_ruleTreasureCard= ruleTreasureCard EOF ;
    public final EObject entryRuleTreasureCard() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTreasureCard = null;


        try {
            // InternalMyDsl.g:697:53: (iv_ruleTreasureCard= ruleTreasureCard EOF )
            // InternalMyDsl.g:698:2: iv_ruleTreasureCard= ruleTreasureCard EOF
            {
             newCompositeNode(grammarAccess.getTreasureCardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTreasureCard=ruleTreasureCard();

            state._fsp--;

             current =iv_ruleTreasureCard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTreasureCard"


    // $ANTLR start "ruleTreasureCard"
    // InternalMyDsl.g:704:1: ruleTreasureCard returns [EObject current=null] : ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'cost' ( (lv_cost_5_0= ruleEInt ) ) otherlv_6= 'value' ( (lv_value_7_0= ruleEInt ) ) otherlv_8= '}' ) ;
    public final EObject ruleTreasureCard() throws RecognitionException {
        EObject current = null;

        Token lv_isPubliclyVisible_0_0=null;
        Token lv_isVisibleToOwner_1_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        AntlrDatatypeRuleToken lv_cost_5_0 = null;

        AntlrDatatypeRuleToken lv_value_7_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:710:2: ( ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'cost' ( (lv_cost_5_0= ruleEInt ) ) otherlv_6= 'value' ( (lv_value_7_0= ruleEInt ) ) otherlv_8= '}' ) )
            // InternalMyDsl.g:711:2: ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'cost' ( (lv_cost_5_0= ruleEInt ) ) otherlv_6= 'value' ( (lv_value_7_0= ruleEInt ) ) otherlv_8= '}' )
            {
            // InternalMyDsl.g:711:2: ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'cost' ( (lv_cost_5_0= ruleEInt ) ) otherlv_6= 'value' ( (lv_value_7_0= ruleEInt ) ) otherlv_8= '}' )
            // InternalMyDsl.g:712:3: ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'cost' ( (lv_cost_5_0= ruleEInt ) ) otherlv_6= 'value' ( (lv_value_7_0= ruleEInt ) ) otherlv_8= '}'
            {
            // InternalMyDsl.g:712:3: ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==23) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalMyDsl.g:713:4: (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' )
                    {
                    // InternalMyDsl.g:713:4: (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' )
                    // InternalMyDsl.g:714:5: lv_isPubliclyVisible_0_0= 'isPubliclyVisible'
                    {
                    lv_isPubliclyVisible_0_0=(Token)match(input,23,FOLLOW_15); 

                    					newLeafNode(lv_isPubliclyVisible_0_0, grammarAccess.getTreasureCardAccess().getIsPubliclyVisibleIsPubliclyVisibleKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getTreasureCardRule());
                    					}
                    					setWithLastConsumed(current, "isPubliclyVisible", lv_isPubliclyVisible_0_0 != null, "isPubliclyVisible");
                    				

                    }


                    }
                    break;

            }

            // InternalMyDsl.g:726:3: ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==24) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalMyDsl.g:727:4: (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' )
                    {
                    // InternalMyDsl.g:727:4: (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' )
                    // InternalMyDsl.g:728:5: lv_isVisibleToOwner_1_0= 'isVisibleToOwner'
                    {
                    lv_isVisibleToOwner_1_0=(Token)match(input,24,FOLLOW_11); 

                    					newLeafNode(lv_isVisibleToOwner_1_0, grammarAccess.getTreasureCardAccess().getIsVisibleToOwnerIsVisibleToOwnerKeyword_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getTreasureCardRule());
                    					}
                    					setWithLastConsumed(current, "isVisibleToOwner", lv_isVisibleToOwner_1_0 != null, "isVisibleToOwner");
                    				

                    }


                    }
                    break;

            }

            // InternalMyDsl.g:740:3: ( (lv_name_2_0= ruleEString ) )
            // InternalMyDsl.g:741:4: (lv_name_2_0= ruleEString )
            {
            // InternalMyDsl.g:741:4: (lv_name_2_0= ruleEString )
            // InternalMyDsl.g:742:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getTreasureCardAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_3);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTreasureCardRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"dominion_strategy_lang.MyDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_16); 

            			newLeafNode(otherlv_3, grammarAccess.getTreasureCardAccess().getLeftCurlyBracketKeyword_3());
            		
            otherlv_4=(Token)match(input,25,FOLLOW_17); 

            			newLeafNode(otherlv_4, grammarAccess.getTreasureCardAccess().getCostKeyword_4());
            		
            // InternalMyDsl.g:767:3: ( (lv_cost_5_0= ruleEInt ) )
            // InternalMyDsl.g:768:4: (lv_cost_5_0= ruleEInt )
            {
            // InternalMyDsl.g:768:4: (lv_cost_5_0= ruleEInt )
            // InternalMyDsl.g:769:5: lv_cost_5_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getTreasureCardAccess().getCostEIntParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_18);
            lv_cost_5_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTreasureCardRule());
            					}
            					set(
            						current,
            						"cost",
            						lv_cost_5_0,
            						"dominion_strategy_lang.MyDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_6=(Token)match(input,26,FOLLOW_17); 

            			newLeafNode(otherlv_6, grammarAccess.getTreasureCardAccess().getValueKeyword_6());
            		
            // InternalMyDsl.g:790:3: ( (lv_value_7_0= ruleEInt ) )
            // InternalMyDsl.g:791:4: (lv_value_7_0= ruleEInt )
            {
            // InternalMyDsl.g:791:4: (lv_value_7_0= ruleEInt )
            // InternalMyDsl.g:792:5: lv_value_7_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getTreasureCardAccess().getValueEIntParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_8);
            lv_value_7_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTreasureCardRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_7_0,
            						"dominion_strategy_lang.MyDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getTreasureCardAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTreasureCard"


    // $ANTLR start "entryRuleVictoryCard"
    // InternalMyDsl.g:817:1: entryRuleVictoryCard returns [EObject current=null] : iv_ruleVictoryCard= ruleVictoryCard EOF ;
    public final EObject entryRuleVictoryCard() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleVictoryCard = null;


        try {
            // InternalMyDsl.g:817:52: (iv_ruleVictoryCard= ruleVictoryCard EOF )
            // InternalMyDsl.g:818:2: iv_ruleVictoryCard= ruleVictoryCard EOF
            {
             newCompositeNode(grammarAccess.getVictoryCardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVictoryCard=ruleVictoryCard();

            state._fsp--;

             current =iv_ruleVictoryCard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVictoryCard"


    // $ANTLR start "ruleVictoryCard"
    // InternalMyDsl.g:824:1: ruleVictoryCard returns [EObject current=null] : ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'cost' ( (lv_cost_5_0= ruleEInt ) ) otherlv_6= 'victoryPoints' ( (lv_victoryPoints_7_0= ruleEInt ) ) otherlv_8= '}' ) ;
    public final EObject ruleVictoryCard() throws RecognitionException {
        EObject current = null;

        Token lv_isPubliclyVisible_0_0=null;
        Token lv_isVisibleToOwner_1_0=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        AntlrDatatypeRuleToken lv_cost_5_0 = null;

        AntlrDatatypeRuleToken lv_victoryPoints_7_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:830:2: ( ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'cost' ( (lv_cost_5_0= ruleEInt ) ) otherlv_6= 'victoryPoints' ( (lv_victoryPoints_7_0= ruleEInt ) ) otherlv_8= '}' ) )
            // InternalMyDsl.g:831:2: ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'cost' ( (lv_cost_5_0= ruleEInt ) ) otherlv_6= 'victoryPoints' ( (lv_victoryPoints_7_0= ruleEInt ) ) otherlv_8= '}' )
            {
            // InternalMyDsl.g:831:2: ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'cost' ( (lv_cost_5_0= ruleEInt ) ) otherlv_6= 'victoryPoints' ( (lv_victoryPoints_7_0= ruleEInt ) ) otherlv_8= '}' )
            // InternalMyDsl.g:832:3: ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' otherlv_4= 'cost' ( (lv_cost_5_0= ruleEInt ) ) otherlv_6= 'victoryPoints' ( (lv_victoryPoints_7_0= ruleEInt ) ) otherlv_8= '}'
            {
            // InternalMyDsl.g:832:3: ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==23) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalMyDsl.g:833:4: (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' )
                    {
                    // InternalMyDsl.g:833:4: (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' )
                    // InternalMyDsl.g:834:5: lv_isPubliclyVisible_0_0= 'isPubliclyVisible'
                    {
                    lv_isPubliclyVisible_0_0=(Token)match(input,23,FOLLOW_15); 

                    					newLeafNode(lv_isPubliclyVisible_0_0, grammarAccess.getVictoryCardAccess().getIsPubliclyVisibleIsPubliclyVisibleKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getVictoryCardRule());
                    					}
                    					setWithLastConsumed(current, "isPubliclyVisible", lv_isPubliclyVisible_0_0 != null, "isPubliclyVisible");
                    				

                    }


                    }
                    break;

            }

            // InternalMyDsl.g:846:3: ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==24) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalMyDsl.g:847:4: (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' )
                    {
                    // InternalMyDsl.g:847:4: (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' )
                    // InternalMyDsl.g:848:5: lv_isVisibleToOwner_1_0= 'isVisibleToOwner'
                    {
                    lv_isVisibleToOwner_1_0=(Token)match(input,24,FOLLOW_11); 

                    					newLeafNode(lv_isVisibleToOwner_1_0, grammarAccess.getVictoryCardAccess().getIsVisibleToOwnerIsVisibleToOwnerKeyword_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getVictoryCardRule());
                    					}
                    					setWithLastConsumed(current, "isVisibleToOwner", lv_isVisibleToOwner_1_0 != null, "isVisibleToOwner");
                    				

                    }


                    }
                    break;

            }

            // InternalMyDsl.g:860:3: ( (lv_name_2_0= ruleEString ) )
            // InternalMyDsl.g:861:4: (lv_name_2_0= ruleEString )
            {
            // InternalMyDsl.g:861:4: (lv_name_2_0= ruleEString )
            // InternalMyDsl.g:862:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getVictoryCardAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_3);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVictoryCardRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"dominion_strategy_lang.MyDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_16); 

            			newLeafNode(otherlv_3, grammarAccess.getVictoryCardAccess().getLeftCurlyBracketKeyword_3());
            		
            otherlv_4=(Token)match(input,25,FOLLOW_17); 

            			newLeafNode(otherlv_4, grammarAccess.getVictoryCardAccess().getCostKeyword_4());
            		
            // InternalMyDsl.g:887:3: ( (lv_cost_5_0= ruleEInt ) )
            // InternalMyDsl.g:888:4: (lv_cost_5_0= ruleEInt )
            {
            // InternalMyDsl.g:888:4: (lv_cost_5_0= ruleEInt )
            // InternalMyDsl.g:889:5: lv_cost_5_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getVictoryCardAccess().getCostEIntParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_19);
            lv_cost_5_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVictoryCardRule());
            					}
            					set(
            						current,
            						"cost",
            						lv_cost_5_0,
            						"dominion_strategy_lang.MyDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_6=(Token)match(input,27,FOLLOW_17); 

            			newLeafNode(otherlv_6, grammarAccess.getVictoryCardAccess().getVictoryPointsKeyword_6());
            		
            // InternalMyDsl.g:910:3: ( (lv_victoryPoints_7_0= ruleEInt ) )
            // InternalMyDsl.g:911:4: (lv_victoryPoints_7_0= ruleEInt )
            {
            // InternalMyDsl.g:911:4: (lv_victoryPoints_7_0= ruleEInt )
            // InternalMyDsl.g:912:5: lv_victoryPoints_7_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getVictoryCardAccess().getVictoryPointsEIntParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_8);
            lv_victoryPoints_7_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getVictoryCardRule());
            					}
            					set(
            						current,
            						"victoryPoints",
            						lv_victoryPoints_7_0,
            						"dominion_strategy_lang.MyDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_8=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_8, grammarAccess.getVictoryCardAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVictoryCard"


    // $ANTLR start "entryRuleActionCard"
    // InternalMyDsl.g:937:1: entryRuleActionCard returns [EObject current=null] : iv_ruleActionCard= ruleActionCard EOF ;
    public final EObject entryRuleActionCard() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleActionCard = null;


        try {
            // InternalMyDsl.g:937:51: (iv_ruleActionCard= ruleActionCard EOF )
            // InternalMyDsl.g:938:2: iv_ruleActionCard= ruleActionCard EOF
            {
             newCompositeNode(grammarAccess.getActionCardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleActionCard=ruleActionCard();

            state._fsp--;

             current =iv_ruleActionCard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleActionCard"


    // $ANTLR start "ruleActionCard"
    // InternalMyDsl.g:944:1: ruleActionCard returns [EObject current=null] : ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) ) ;
    public final EObject ruleActionCard() throws RecognitionException {
        EObject current = null;

        Token lv_isPubliclyVisible_0_0=null;
        Token lv_isVisibleToOwner_1_0=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:950:2: ( ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) ) )
            // InternalMyDsl.g:951:2: ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) )
            {
            // InternalMyDsl.g:951:2: ( ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) ) )
            // InternalMyDsl.g:952:3: ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )? ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )? ( (lv_name_2_0= ruleEString ) )
            {
            // InternalMyDsl.g:952:3: ( (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' ) )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==23) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalMyDsl.g:953:4: (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' )
                    {
                    // InternalMyDsl.g:953:4: (lv_isPubliclyVisible_0_0= 'isPubliclyVisible' )
                    // InternalMyDsl.g:954:5: lv_isPubliclyVisible_0_0= 'isPubliclyVisible'
                    {
                    lv_isPubliclyVisible_0_0=(Token)match(input,23,FOLLOW_15); 

                    					newLeafNode(lv_isPubliclyVisible_0_0, grammarAccess.getActionCardAccess().getIsPubliclyVisibleIsPubliclyVisibleKeyword_0_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getActionCardRule());
                    					}
                    					setWithLastConsumed(current, "isPubliclyVisible", lv_isPubliclyVisible_0_0 != null, "isPubliclyVisible");
                    				

                    }


                    }
                    break;

            }

            // InternalMyDsl.g:966:3: ( (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==24) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalMyDsl.g:967:4: (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' )
                    {
                    // InternalMyDsl.g:967:4: (lv_isVisibleToOwner_1_0= 'isVisibleToOwner' )
                    // InternalMyDsl.g:968:5: lv_isVisibleToOwner_1_0= 'isVisibleToOwner'
                    {
                    lv_isVisibleToOwner_1_0=(Token)match(input,24,FOLLOW_11); 

                    					newLeafNode(lv_isVisibleToOwner_1_0, grammarAccess.getActionCardAccess().getIsVisibleToOwnerIsVisibleToOwnerKeyword_1_0());
                    				

                    					if (current==null) {
                    						current = createModelElement(grammarAccess.getActionCardRule());
                    					}
                    					setWithLastConsumed(current, "isVisibleToOwner", lv_isVisibleToOwner_1_0 != null, "isVisibleToOwner");
                    				

                    }


                    }
                    break;

            }

            // InternalMyDsl.g:980:3: ( (lv_name_2_0= ruleEString ) )
            // InternalMyDsl.g:981:4: (lv_name_2_0= ruleEString )
            {
            // InternalMyDsl.g:981:4: (lv_name_2_0= ruleEString )
            // InternalMyDsl.g:982:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getActionCardAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getActionCardRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"dominion_strategy_lang.MyDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleActionCard"


    // $ANTLR start "entryRulePutCardInTrash"
    // InternalMyDsl.g:1003:1: entryRulePutCardInTrash returns [EObject current=null] : iv_rulePutCardInTrash= rulePutCardInTrash EOF ;
    public final EObject entryRulePutCardInTrash() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePutCardInTrash = null;


        try {
            // InternalMyDsl.g:1003:55: (iv_rulePutCardInTrash= rulePutCardInTrash EOF )
            // InternalMyDsl.g:1004:2: iv_rulePutCardInTrash= rulePutCardInTrash EOF
            {
             newCompositeNode(grammarAccess.getPutCardInTrashRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePutCardInTrash=rulePutCardInTrash();

            state._fsp--;

             current =iv_rulePutCardInTrash; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePutCardInTrash"


    // $ANTLR start "rulePutCardInTrash"
    // InternalMyDsl.g:1010:1: rulePutCardInTrash returns [EObject current=null] : (otherlv_0= 'PutCardInTrash' otherlv_1= '{' otherlv_2= '}' ) ;
    public final EObject rulePutCardInTrash() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1016:2: ( (otherlv_0= 'PutCardInTrash' otherlv_1= '{' otherlv_2= '}' ) )
            // InternalMyDsl.g:1017:2: (otherlv_0= 'PutCardInTrash' otherlv_1= '{' otherlv_2= '}' )
            {
            // InternalMyDsl.g:1017:2: (otherlv_0= 'PutCardInTrash' otherlv_1= '{' otherlv_2= '}' )
            // InternalMyDsl.g:1018:3: otherlv_0= 'PutCardInTrash' otherlv_1= '{' otherlv_2= '}'
            {
            otherlv_0=(Token)match(input,28,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getPutCardInTrashAccess().getPutCardInTrashKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_8); 

            			newLeafNode(otherlv_1, grammarAccess.getPutCardInTrashAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_2, grammarAccess.getPutCardInTrashAccess().getRightCurlyBracketKeyword_2());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePutCardInTrash"


    // $ANTLR start "entryRuleDrawCards"
    // InternalMyDsl.g:1034:1: entryRuleDrawCards returns [EObject current=null] : iv_ruleDrawCards= ruleDrawCards EOF ;
    public final EObject entryRuleDrawCards() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDrawCards = null;


        try {
            // InternalMyDsl.g:1034:50: (iv_ruleDrawCards= ruleDrawCards EOF )
            // InternalMyDsl.g:1035:2: iv_ruleDrawCards= ruleDrawCards EOF
            {
             newCompositeNode(grammarAccess.getDrawCardsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDrawCards=ruleDrawCards();

            state._fsp--;

             current =iv_ruleDrawCards; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDrawCards"


    // $ANTLR start "ruleDrawCards"
    // InternalMyDsl.g:1041:1: ruleDrawCards returns [EObject current=null] : (otherlv_0= 'DrawCards' otherlv_1= '{' otherlv_2= 'cardNumber' ( (lv_cardNumber_3_0= ruleEInt ) ) otherlv_4= '}' ) ;
    public final EObject ruleDrawCards() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_cardNumber_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1047:2: ( (otherlv_0= 'DrawCards' otherlv_1= '{' otherlv_2= 'cardNumber' ( (lv_cardNumber_3_0= ruleEInt ) ) otherlv_4= '}' ) )
            // InternalMyDsl.g:1048:2: (otherlv_0= 'DrawCards' otherlv_1= '{' otherlv_2= 'cardNumber' ( (lv_cardNumber_3_0= ruleEInt ) ) otherlv_4= '}' )
            {
            // InternalMyDsl.g:1048:2: (otherlv_0= 'DrawCards' otherlv_1= '{' otherlv_2= 'cardNumber' ( (lv_cardNumber_3_0= ruleEInt ) ) otherlv_4= '}' )
            // InternalMyDsl.g:1049:3: otherlv_0= 'DrawCards' otherlv_1= '{' otherlv_2= 'cardNumber' ( (lv_cardNumber_3_0= ruleEInt ) ) otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,29,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getDrawCardsAccess().getDrawCardsKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_20); 

            			newLeafNode(otherlv_1, grammarAccess.getDrawCardsAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,30,FOLLOW_17); 

            			newLeafNode(otherlv_2, grammarAccess.getDrawCardsAccess().getCardNumberKeyword_2());
            		
            // InternalMyDsl.g:1061:3: ( (lv_cardNumber_3_0= ruleEInt ) )
            // InternalMyDsl.g:1062:4: (lv_cardNumber_3_0= ruleEInt )
            {
            // InternalMyDsl.g:1062:4: (lv_cardNumber_3_0= ruleEInt )
            // InternalMyDsl.g:1063:5: lv_cardNumber_3_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getDrawCardsAccess().getCardNumberEIntParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_8);
            lv_cardNumber_3_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getDrawCardsRule());
            					}
            					set(
            						current,
            						"cardNumber",
            						lv_cardNumber_3_0,
            						"dominion_strategy_lang.MyDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getDrawCardsAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDrawCards"


    // $ANTLR start "entryRulePutCardFromPileToDiscard"
    // InternalMyDsl.g:1088:1: entryRulePutCardFromPileToDiscard returns [EObject current=null] : iv_rulePutCardFromPileToDiscard= rulePutCardFromPileToDiscard EOF ;
    public final EObject entryRulePutCardFromPileToDiscard() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePutCardFromPileToDiscard = null;


        try {
            // InternalMyDsl.g:1088:65: (iv_rulePutCardFromPileToDiscard= rulePutCardFromPileToDiscard EOF )
            // InternalMyDsl.g:1089:2: iv_rulePutCardFromPileToDiscard= rulePutCardFromPileToDiscard EOF
            {
             newCompositeNode(grammarAccess.getPutCardFromPileToDiscardRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePutCardFromPileToDiscard=rulePutCardFromPileToDiscard();

            state._fsp--;

             current =iv_rulePutCardFromPileToDiscard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePutCardFromPileToDiscard"


    // $ANTLR start "rulePutCardFromPileToDiscard"
    // InternalMyDsl.g:1095:1: rulePutCardFromPileToDiscard returns [EObject current=null] : (otherlv_0= 'PutCardFromPileToDiscard' otherlv_1= '{' otherlv_2= 'discard_pile' ( ( ruleEString ) ) otherlv_4= '}' ) ;
    public final EObject rulePutCardFromPileToDiscard() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1101:2: ( (otherlv_0= 'PutCardFromPileToDiscard' otherlv_1= '{' otherlv_2= 'discard_pile' ( ( ruleEString ) ) otherlv_4= '}' ) )
            // InternalMyDsl.g:1102:2: (otherlv_0= 'PutCardFromPileToDiscard' otherlv_1= '{' otherlv_2= 'discard_pile' ( ( ruleEString ) ) otherlv_4= '}' )
            {
            // InternalMyDsl.g:1102:2: (otherlv_0= 'PutCardFromPileToDiscard' otherlv_1= '{' otherlv_2= 'discard_pile' ( ( ruleEString ) ) otherlv_4= '}' )
            // InternalMyDsl.g:1103:3: otherlv_0= 'PutCardFromPileToDiscard' otherlv_1= '{' otherlv_2= 'discard_pile' ( ( ruleEString ) ) otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,31,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getPutCardFromPileToDiscardAccess().getPutCardFromPileToDiscardKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_21); 

            			newLeafNode(otherlv_1, grammarAccess.getPutCardFromPileToDiscardAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,32,FOLLOW_11); 

            			newLeafNode(otherlv_2, grammarAccess.getPutCardFromPileToDiscardAccess().getDiscard_pileKeyword_2());
            		
            // InternalMyDsl.g:1115:3: ( ( ruleEString ) )
            // InternalMyDsl.g:1116:4: ( ruleEString )
            {
            // InternalMyDsl.g:1116:4: ( ruleEString )
            // InternalMyDsl.g:1117:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getPutCardFromPileToDiscardRule());
            					}
            				

            					newCompositeNode(grammarAccess.getPutCardFromPileToDiscardAccess().getDiscard_pileDiscardPileCrossReference_3_0());
            				
            pushFollow(FOLLOW_8);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getPutCardFromPileToDiscardAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePutCardFromPileToDiscard"


    // $ANTLR start "entryRuleExtraBuys"
    // InternalMyDsl.g:1139:1: entryRuleExtraBuys returns [EObject current=null] : iv_ruleExtraBuys= ruleExtraBuys EOF ;
    public final EObject entryRuleExtraBuys() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExtraBuys = null;


        try {
            // InternalMyDsl.g:1139:50: (iv_ruleExtraBuys= ruleExtraBuys EOF )
            // InternalMyDsl.g:1140:2: iv_ruleExtraBuys= ruleExtraBuys EOF
            {
             newCompositeNode(grammarAccess.getExtraBuysRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExtraBuys=ruleExtraBuys();

            state._fsp--;

             current =iv_ruleExtraBuys; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExtraBuys"


    // $ANTLR start "ruleExtraBuys"
    // InternalMyDsl.g:1146:1: ruleExtraBuys returns [EObject current=null] : (otherlv_0= 'ExtraBuys' otherlv_1= '{' otherlv_2= 'buyNumber' ( (lv_buyNumber_3_0= ruleEInt ) ) otherlv_4= '}' ) ;
    public final EObject ruleExtraBuys() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_buyNumber_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1152:2: ( (otherlv_0= 'ExtraBuys' otherlv_1= '{' otherlv_2= 'buyNumber' ( (lv_buyNumber_3_0= ruleEInt ) ) otherlv_4= '}' ) )
            // InternalMyDsl.g:1153:2: (otherlv_0= 'ExtraBuys' otherlv_1= '{' otherlv_2= 'buyNumber' ( (lv_buyNumber_3_0= ruleEInt ) ) otherlv_4= '}' )
            {
            // InternalMyDsl.g:1153:2: (otherlv_0= 'ExtraBuys' otherlv_1= '{' otherlv_2= 'buyNumber' ( (lv_buyNumber_3_0= ruleEInt ) ) otherlv_4= '}' )
            // InternalMyDsl.g:1154:3: otherlv_0= 'ExtraBuys' otherlv_1= '{' otherlv_2= 'buyNumber' ( (lv_buyNumber_3_0= ruleEInt ) ) otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,33,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getExtraBuysAccess().getExtraBuysKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_22); 

            			newLeafNode(otherlv_1, grammarAccess.getExtraBuysAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,34,FOLLOW_17); 

            			newLeafNode(otherlv_2, grammarAccess.getExtraBuysAccess().getBuyNumberKeyword_2());
            		
            // InternalMyDsl.g:1166:3: ( (lv_buyNumber_3_0= ruleEInt ) )
            // InternalMyDsl.g:1167:4: (lv_buyNumber_3_0= ruleEInt )
            {
            // InternalMyDsl.g:1167:4: (lv_buyNumber_3_0= ruleEInt )
            // InternalMyDsl.g:1168:5: lv_buyNumber_3_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getExtraBuysAccess().getBuyNumberEIntParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_8);
            lv_buyNumber_3_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getExtraBuysRule());
            					}
            					set(
            						current,
            						"buyNumber",
            						lv_buyNumber_3_0,
            						"dominion_strategy_lang.MyDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getExtraBuysAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExtraBuys"


    // $ANTLR start "entryRuleExtraCoins"
    // InternalMyDsl.g:1193:1: entryRuleExtraCoins returns [EObject current=null] : iv_ruleExtraCoins= ruleExtraCoins EOF ;
    public final EObject entryRuleExtraCoins() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExtraCoins = null;


        try {
            // InternalMyDsl.g:1193:51: (iv_ruleExtraCoins= ruleExtraCoins EOF )
            // InternalMyDsl.g:1194:2: iv_ruleExtraCoins= ruleExtraCoins EOF
            {
             newCompositeNode(grammarAccess.getExtraCoinsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExtraCoins=ruleExtraCoins();

            state._fsp--;

             current =iv_ruleExtraCoins; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExtraCoins"


    // $ANTLR start "ruleExtraCoins"
    // InternalMyDsl.g:1200:1: ruleExtraCoins returns [EObject current=null] : (otherlv_0= 'ExtraCoins' otherlv_1= '{' otherlv_2= 'coinNumber' ( (lv_coinNumber_3_0= ruleEInt ) ) otherlv_4= '}' ) ;
    public final EObject ruleExtraCoins() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_coinNumber_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1206:2: ( (otherlv_0= 'ExtraCoins' otherlv_1= '{' otherlv_2= 'coinNumber' ( (lv_coinNumber_3_0= ruleEInt ) ) otherlv_4= '}' ) )
            // InternalMyDsl.g:1207:2: (otherlv_0= 'ExtraCoins' otherlv_1= '{' otherlv_2= 'coinNumber' ( (lv_coinNumber_3_0= ruleEInt ) ) otherlv_4= '}' )
            {
            // InternalMyDsl.g:1207:2: (otherlv_0= 'ExtraCoins' otherlv_1= '{' otherlv_2= 'coinNumber' ( (lv_coinNumber_3_0= ruleEInt ) ) otherlv_4= '}' )
            // InternalMyDsl.g:1208:3: otherlv_0= 'ExtraCoins' otherlv_1= '{' otherlv_2= 'coinNumber' ( (lv_coinNumber_3_0= ruleEInt ) ) otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,35,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getExtraCoinsAccess().getExtraCoinsKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_23); 

            			newLeafNode(otherlv_1, grammarAccess.getExtraCoinsAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,36,FOLLOW_17); 

            			newLeafNode(otherlv_2, grammarAccess.getExtraCoinsAccess().getCoinNumberKeyword_2());
            		
            // InternalMyDsl.g:1220:3: ( (lv_coinNumber_3_0= ruleEInt ) )
            // InternalMyDsl.g:1221:4: (lv_coinNumber_3_0= ruleEInt )
            {
            // InternalMyDsl.g:1221:4: (lv_coinNumber_3_0= ruleEInt )
            // InternalMyDsl.g:1222:5: lv_coinNumber_3_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getExtraCoinsAccess().getCoinNumberEIntParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_8);
            lv_coinNumber_3_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getExtraCoinsRule());
            					}
            					set(
            						current,
            						"coinNumber",
            						lv_coinNumber_3_0,
            						"dominion_strategy_lang.MyDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getExtraCoinsAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExtraCoins"


    // $ANTLR start "entryRuleExtraActions"
    // InternalMyDsl.g:1247:1: entryRuleExtraActions returns [EObject current=null] : iv_ruleExtraActions= ruleExtraActions EOF ;
    public final EObject entryRuleExtraActions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExtraActions = null;


        try {
            // InternalMyDsl.g:1247:53: (iv_ruleExtraActions= ruleExtraActions EOF )
            // InternalMyDsl.g:1248:2: iv_ruleExtraActions= ruleExtraActions EOF
            {
             newCompositeNode(grammarAccess.getExtraActionsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleExtraActions=ruleExtraActions();

            state._fsp--;

             current =iv_ruleExtraActions; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExtraActions"


    // $ANTLR start "ruleExtraActions"
    // InternalMyDsl.g:1254:1: ruleExtraActions returns [EObject current=null] : (otherlv_0= 'ExtraActions' otherlv_1= '{' otherlv_2= 'actionNumber' ( (lv_actionNumber_3_0= ruleEInt ) ) otherlv_4= '}' ) ;
    public final EObject ruleExtraActions() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_actionNumber_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1260:2: ( (otherlv_0= 'ExtraActions' otherlv_1= '{' otherlv_2= 'actionNumber' ( (lv_actionNumber_3_0= ruleEInt ) ) otherlv_4= '}' ) )
            // InternalMyDsl.g:1261:2: (otherlv_0= 'ExtraActions' otherlv_1= '{' otherlv_2= 'actionNumber' ( (lv_actionNumber_3_0= ruleEInt ) ) otherlv_4= '}' )
            {
            // InternalMyDsl.g:1261:2: (otherlv_0= 'ExtraActions' otherlv_1= '{' otherlv_2= 'actionNumber' ( (lv_actionNumber_3_0= ruleEInt ) ) otherlv_4= '}' )
            // InternalMyDsl.g:1262:3: otherlv_0= 'ExtraActions' otherlv_1= '{' otherlv_2= 'actionNumber' ( (lv_actionNumber_3_0= ruleEInt ) ) otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,37,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getExtraActionsAccess().getExtraActionsKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_24); 

            			newLeafNode(otherlv_1, grammarAccess.getExtraActionsAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,38,FOLLOW_17); 

            			newLeafNode(otherlv_2, grammarAccess.getExtraActionsAccess().getActionNumberKeyword_2());
            		
            // InternalMyDsl.g:1274:3: ( (lv_actionNumber_3_0= ruleEInt ) )
            // InternalMyDsl.g:1275:4: (lv_actionNumber_3_0= ruleEInt )
            {
            // InternalMyDsl.g:1275:4: (lv_actionNumber_3_0= ruleEInt )
            // InternalMyDsl.g:1276:5: lv_actionNumber_3_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getExtraActionsAccess().getActionNumberEIntParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_8);
            lv_actionNumber_3_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getExtraActionsRule());
            					}
            					set(
            						current,
            						"actionNumber",
            						lv_actionNumber_3_0,
            						"dominion_strategy_lang.MyDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getExtraActionsAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExtraActions"


    // $ANTLR start "entryRulePutCardFromHandToDiscard"
    // InternalMyDsl.g:1301:1: entryRulePutCardFromHandToDiscard returns [EObject current=null] : iv_rulePutCardFromHandToDiscard= rulePutCardFromHandToDiscard EOF ;
    public final EObject entryRulePutCardFromHandToDiscard() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePutCardFromHandToDiscard = null;


        try {
            // InternalMyDsl.g:1301:65: (iv_rulePutCardFromHandToDiscard= rulePutCardFromHandToDiscard EOF )
            // InternalMyDsl.g:1302:2: iv_rulePutCardFromHandToDiscard= rulePutCardFromHandToDiscard EOF
            {
             newCompositeNode(grammarAccess.getPutCardFromHandToDiscardRule()); 
            pushFollow(FOLLOW_1);
            iv_rulePutCardFromHandToDiscard=rulePutCardFromHandToDiscard();

            state._fsp--;

             current =iv_rulePutCardFromHandToDiscard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePutCardFromHandToDiscard"


    // $ANTLR start "rulePutCardFromHandToDiscard"
    // InternalMyDsl.g:1308:1: rulePutCardFromHandToDiscard returns [EObject current=null] : ( () otherlv_1= 'PutCardFromHandToDiscard' ) ;
    public final EObject rulePutCardFromHandToDiscard() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1314:2: ( ( () otherlv_1= 'PutCardFromHandToDiscard' ) )
            // InternalMyDsl.g:1315:2: ( () otherlv_1= 'PutCardFromHandToDiscard' )
            {
            // InternalMyDsl.g:1315:2: ( () otherlv_1= 'PutCardFromHandToDiscard' )
            // InternalMyDsl.g:1316:3: () otherlv_1= 'PutCardFromHandToDiscard'
            {
            // InternalMyDsl.g:1316:3: ()
            // InternalMyDsl.g:1317:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getPutCardFromHandToDiscardAccess().getPutCardFromHandToDiscardAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,39,FOLLOW_2); 

            			newLeafNode(otherlv_1, grammarAccess.getPutCardFromHandToDiscardAccess().getPutCardFromHandToDiscardKeyword_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePutCardFromHandToDiscard"


    // $ANTLR start "entryRuleFittingCard"
    // InternalMyDsl.g:1331:1: entryRuleFittingCard returns [EObject current=null] : iv_ruleFittingCard= ruleFittingCard EOF ;
    public final EObject entryRuleFittingCard() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFittingCard = null;


        try {
            // InternalMyDsl.g:1331:52: (iv_ruleFittingCard= ruleFittingCard EOF )
            // InternalMyDsl.g:1332:2: iv_ruleFittingCard= ruleFittingCard EOF
            {
             newCompositeNode(grammarAccess.getFittingCardRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFittingCard=ruleFittingCard();

            state._fsp--;

             current =iv_ruleFittingCard; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFittingCard"


    // $ANTLR start "ruleFittingCard"
    // InternalMyDsl.g:1338:1: ruleFittingCard returns [EObject current=null] : (otherlv_0= 'you' otherlv_1= 'have' ( ( ruleEString ) ) ) ;
    public final EObject ruleFittingCard() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;


        	enterRule();

        try {
            // InternalMyDsl.g:1344:2: ( (otherlv_0= 'you' otherlv_1= 'have' ( ( ruleEString ) ) ) )
            // InternalMyDsl.g:1345:2: (otherlv_0= 'you' otherlv_1= 'have' ( ( ruleEString ) ) )
            {
            // InternalMyDsl.g:1345:2: (otherlv_0= 'you' otherlv_1= 'have' ( ( ruleEString ) ) )
            // InternalMyDsl.g:1346:3: otherlv_0= 'you' otherlv_1= 'have' ( ( ruleEString ) )
            {
            otherlv_0=(Token)match(input,40,FOLLOW_25); 

            			newLeafNode(otherlv_0, grammarAccess.getFittingCardAccess().getYouKeyword_0());
            		
            otherlv_1=(Token)match(input,41,FOLLOW_11); 

            			newLeafNode(otherlv_1, grammarAccess.getFittingCardAccess().getHaveKeyword_1());
            		
            // InternalMyDsl.g:1354:3: ( ( ruleEString ) )
            // InternalMyDsl.g:1355:4: ( ruleEString )
            {
            // InternalMyDsl.g:1355:4: ( ruleEString )
            // InternalMyDsl.g:1356:5: ruleEString
            {

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFittingCardRule());
            					}
            				

            					newCompositeNode(grammarAccess.getFittingCardAccess().getCardCardCrossReference_2_0());
            				
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;


            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFittingCard"


    // $ANTLR start "entryRuleEnoughCoins"
    // InternalMyDsl.g:1374:1: entryRuleEnoughCoins returns [EObject current=null] : iv_ruleEnoughCoins= ruleEnoughCoins EOF ;
    public final EObject entryRuleEnoughCoins() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEnoughCoins = null;


        try {
            // InternalMyDsl.g:1374:52: (iv_ruleEnoughCoins= ruleEnoughCoins EOF )
            // InternalMyDsl.g:1375:2: iv_ruleEnoughCoins= ruleEnoughCoins EOF
            {
             newCompositeNode(grammarAccess.getEnoughCoinsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEnoughCoins=ruleEnoughCoins();

            state._fsp--;

             current =iv_ruleEnoughCoins; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEnoughCoins"


    // $ANTLR start "ruleEnoughCoins"
    // InternalMyDsl.g:1381:1: ruleEnoughCoins returns [EObject current=null] : (otherlv_0= 'EnoughCoins' otherlv_1= '{' otherlv_2= 'newAttribute' ( (lv_coinNumber_3_0= ruleEInt ) ) otherlv_4= '}' ) ;
    public final EObject ruleEnoughCoins() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_coinNumber_3_0 = null;



        	enterRule();

        try {
            // InternalMyDsl.g:1387:2: ( (otherlv_0= 'EnoughCoins' otherlv_1= '{' otherlv_2= 'newAttribute' ( (lv_coinNumber_3_0= ruleEInt ) ) otherlv_4= '}' ) )
            // InternalMyDsl.g:1388:2: (otherlv_0= 'EnoughCoins' otherlv_1= '{' otherlv_2= 'newAttribute' ( (lv_coinNumber_3_0= ruleEInt ) ) otherlv_4= '}' )
            {
            // InternalMyDsl.g:1388:2: (otherlv_0= 'EnoughCoins' otherlv_1= '{' otherlv_2= 'newAttribute' ( (lv_coinNumber_3_0= ruleEInt ) ) otherlv_4= '}' )
            // InternalMyDsl.g:1389:3: otherlv_0= 'EnoughCoins' otherlv_1= '{' otherlv_2= 'newAttribute' ( (lv_coinNumber_3_0= ruleEInt ) ) otherlv_4= '}'
            {
            otherlv_0=(Token)match(input,42,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getEnoughCoinsAccess().getEnoughCoinsKeyword_0());
            		
            otherlv_1=(Token)match(input,12,FOLLOW_26); 

            			newLeafNode(otherlv_1, grammarAccess.getEnoughCoinsAccess().getLeftCurlyBracketKeyword_1());
            		
            otherlv_2=(Token)match(input,43,FOLLOW_17); 

            			newLeafNode(otherlv_2, grammarAccess.getEnoughCoinsAccess().getNewAttributeKeyword_2());
            		
            // InternalMyDsl.g:1401:3: ( (lv_coinNumber_3_0= ruleEInt ) )
            // InternalMyDsl.g:1402:4: (lv_coinNumber_3_0= ruleEInt )
            {
            // InternalMyDsl.g:1402:4: (lv_coinNumber_3_0= ruleEInt )
            // InternalMyDsl.g:1403:5: lv_coinNumber_3_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getEnoughCoinsAccess().getCoinNumberEIntParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_8);
            lv_coinNumber_3_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getEnoughCoinsRule());
            					}
            					set(
            						current,
            						"coinNumber",
            						lv_coinNumber_3_0,
            						"dominion_strategy_lang.MyDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getEnoughCoinsAccess().getRightCurlyBracketKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEnoughCoins"

    // Delegated rules


    protected DFA3 dfa3 = new DFA3(this);
    static final String dfa_1s = "\14\uffff";
    static final String dfa_2s = "\3\uffff\2\6\7\uffff";
    static final String dfa_3s = "\3\5\2\14\1\31\1\uffff\2\4\1\32\2\uffff";
    static final String dfa_4s = "\2\30\1\6\2\14\1\31\1\uffff\1\26\1\4\1\33\2\uffff";
    static final String dfa_5s = "\6\uffff\1\3\3\uffff\1\1\1\2";
    static final String dfa_6s = "\14\uffff}>";
    static final String[] dfa_7s = {
            "\1\3\1\4\20\uffff\1\1\1\2",
            "\1\3\1\4\21\uffff\1\2",
            "\1\3\1\4",
            "\1\5",
            "\1\5",
            "\1\7",
            "",
            "\1\11\21\uffff\1\10",
            "\1\11",
            "\1\12\1\13",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final short[] dfa_2 = DFA.unpackEncodedString(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final char[] dfa_4 = DFA.unpackEncodedStringToUnsignedChars(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[] dfa_6 = DFA.unpackEncodedString(dfa_6s);
    static final short[][] dfa_7 = unpackEncodedStringArray(dfa_7s);

    class DFA3 extends DFA {

        public DFA3(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 3;
            this.eot = dfa_1;
            this.eof = dfa_2;
            this.min = dfa_3;
            this.max = dfa_4;
            this.accept = dfa_5;
            this.special = dfa_6;
            this.transition = dfa_7;
        }
        public String getDescription() {
            return "211:2: (this_TreasureCard_0= ruleTreasureCard | this_VictoryCard_1= ruleVictoryCard | this_ActionCard_2= ruleActionCard )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000006000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x00000000002E4000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x00000000002E8000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x00000000002E0000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000000060L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000050000000000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000001000060L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000400010L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000080000000000L});

}