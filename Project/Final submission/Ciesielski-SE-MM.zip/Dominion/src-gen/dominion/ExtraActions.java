/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Extra Actions</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.ExtraActions#getActionNumber <em>Action Number</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getExtraActions()
 * @model
 * @generated
 */
public interface ExtraActions extends Ability {
	/**
	 * Returns the value of the '<em><b>Action Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Action Number</em>' attribute.
	 * @see #setActionNumber(int)
	 * @see dominion.DominionPackage#getExtraActions_ActionNumber()
	 * @model required="true"
	 * @generated
	 */
	int getActionNumber();

	/**
	 * Sets the value of the '{@link dominion.ExtraActions#getActionNumber <em>Action Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Action Number</em>' attribute.
	 * @see #getActionNumber()
	 * @generated
	 */
	void setActionNumber(int value);

} // ExtraActions
