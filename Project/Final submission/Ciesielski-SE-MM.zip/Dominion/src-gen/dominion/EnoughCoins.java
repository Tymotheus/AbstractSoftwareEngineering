/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Enough Coins</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.EnoughCoins#getCoinNumber <em>Coin Number</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getEnoughCoins()
 * @model
 * @generated
 */
public interface EnoughCoins extends Expression {
	/**
	 * Returns the value of the '<em><b>Coin Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Coin Number</em>' attribute.
	 * @see #setCoinNumber(int)
	 * @see dominion.DominionPackage#getEnoughCoins_CoinNumber()
	 * @model required="true"
	 * @generated
	 */
	int getCoinNumber();

	/**
	 * Sets the value of the '{@link dominion.EnoughCoins#getCoinNumber <em>Coin Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Coin Number</em>' attribute.
	 * @see #getCoinNumber()
	 * @generated
	 */
	void setCoinNumber(int value);

} // EnoughCoins
