/**
 */
package dominion;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Action Card</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.ActionCard#getAbility <em>Ability</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getActionCard()
 * @model
 * @generated
 */
public interface ActionCard extends Card {
	/**
	 * Returns the value of the '<em><b>Ability</b></em>' reference list.
	 * The list contents are of type {@link dominion.Ability}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ability</em>' reference list.
	 * @see dominion.DominionPackage#getActionCard_Ability()
	 * @model required="true"
	 * @generated
	 */
	EList<Ability> getAbility();

} // ActionCard
