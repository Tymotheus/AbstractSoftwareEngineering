/**
 */
package dominion;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see dominion.DominionFactory
 * @model kind="package"
 * @generated
 */
public interface DominionPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "dominion";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/dominion";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "dominion";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DominionPackage eINSTANCE = dominion.impl.DominionPackageImpl.init();

	/**
	 * The meta object id for the '{@link dominion.impl.PlayersDeckImpl <em>Players Deck</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.PlayersDeckImpl
	 * @see dominion.impl.DominionPackageImpl#getPlayersDeck()
	 * @generated
	 */
	int PLAYERS_DECK = 0;

	/**
	 * The feature id for the '<em><b>Cards Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_DECK__CARDS_NUMBER = 0;

	/**
	 * The feature id for the '<em><b>Cards</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_DECK__CARDS = 1;

	/**
	 * The number of structural features of the '<em>Players Deck</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_DECK_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Players Deck</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_DECK_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.CardImpl <em>Card</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.CardImpl
	 * @see dominion.impl.DominionPackageImpl#getCard()
	 * @generated
	 */
	int CARD = 1;

	/**
	 * The feature id for the '<em><b>Cost</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD__COST = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD__NAME = 1;

	/**
	 * The feature id for the '<em><b>Is Publicly Visible</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD__IS_PUBLICLY_VISIBLE = 2;

	/**
	 * The feature id for the '<em><b>Is Visible To Owner</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD__IS_VISIBLE_TO_OWNER = 3;

	/**
	 * The number of structural features of the '<em>Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.TreasureCardImpl <em>Treasure Card</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.TreasureCardImpl
	 * @see dominion.impl.DominionPackageImpl#getTreasureCard()
	 * @generated
	 */
	int TREASURE_CARD = 2;

	/**
	 * The feature id for the '<em><b>Cost</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TREASURE_CARD__COST = CARD__COST;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TREASURE_CARD__NAME = CARD__NAME;

	/**
	 * The feature id for the '<em><b>Is Publicly Visible</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TREASURE_CARD__IS_PUBLICLY_VISIBLE = CARD__IS_PUBLICLY_VISIBLE;

	/**
	 * The feature id for the '<em><b>Is Visible To Owner</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TREASURE_CARD__IS_VISIBLE_TO_OWNER = CARD__IS_VISIBLE_TO_OWNER;

	/**
	 * The feature id for the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TREASURE_CARD__VALUE = CARD_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Treasure Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TREASURE_CARD_FEATURE_COUNT = CARD_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Treasure Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TREASURE_CARD_OPERATION_COUNT = CARD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.VictoryCardImpl <em>Victory Card</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.VictoryCardImpl
	 * @see dominion.impl.DominionPackageImpl#getVictoryCard()
	 * @generated
	 */
	int VICTORY_CARD = 3;

	/**
	 * The feature id for the '<em><b>Cost</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VICTORY_CARD__COST = CARD__COST;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VICTORY_CARD__NAME = CARD__NAME;

	/**
	 * The feature id for the '<em><b>Is Publicly Visible</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VICTORY_CARD__IS_PUBLICLY_VISIBLE = CARD__IS_PUBLICLY_VISIBLE;

	/**
	 * The feature id for the '<em><b>Is Visible To Owner</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VICTORY_CARD__IS_VISIBLE_TO_OWNER = CARD__IS_VISIBLE_TO_OWNER;

	/**
	 * The feature id for the '<em><b>Victory Points</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VICTORY_CARD__VICTORY_POINTS = CARD_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Victory Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VICTORY_CARD_FEATURE_COUNT = CARD_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Victory Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VICTORY_CARD_OPERATION_COUNT = CARD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.PlayersHandImpl <em>Players Hand</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.PlayersHandImpl
	 * @see dominion.impl.DominionPackageImpl#getPlayersHand()
	 * @generated
	 */
	int PLAYERS_HAND = 4;

	/**
	 * The feature id for the '<em><b>Cards Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_HAND__CARDS_NUMBER = 0;

	/**
	 * The feature id for the '<em><b>Cards</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_HAND__CARDS = 1;

	/**
	 * The number of structural features of the '<em>Players Hand</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_HAND_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Players Hand</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_HAND_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.CardLibraryImpl <em>Card Library</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.CardLibraryImpl
	 * @see dominion.impl.DominionPackageImpl#getCardLibrary()
	 * @generated
	 */
	int CARD_LIBRARY = 5;

	/**
	 * The feature id for the '<em><b>Card</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD_LIBRARY__CARD = 0;

	/**
	 * The feature id for the '<em><b>Abilities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD_LIBRARY__ABILITIES = 1;

	/**
	 * The number of structural features of the '<em>Card Library</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD_LIBRARY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Card Library</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARD_LIBRARY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.PlayersPlayAreaImpl <em>Players Play Area</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.PlayersPlayAreaImpl
	 * @see dominion.impl.DominionPackageImpl#getPlayersPlayArea()
	 * @generated
	 */
	int PLAYERS_PLAY_AREA = 6;

	/**
	 * The feature id for the '<em><b>Cards played this turn</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_PLAY_AREA__CARDS_PLAYED_THIS_TURN = 0;

	/**
	 * The feature id for the '<em><b>Players deck</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_PLAY_AREA__PLAYERS_DECK = 1;

	/**
	 * The feature id for the '<em><b>Players hand</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_PLAY_AREA__PLAYERS_HAND = 2;

	/**
	 * The feature id for the '<em><b>Discard pile</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_PLAY_AREA__DISCARD_PILE = 3;

	/**
	 * The feature id for the '<em><b>Players Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_PLAY_AREA__PLAYERS_NAME = 4;

	/**
	 * The feature id for the '<em><b>Actions Left</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_PLAY_AREA__ACTIONS_LEFT = 5;

	/**
	 * The feature id for the '<em><b>Buys Left</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_PLAY_AREA__BUYS_LEFT = 6;

	/**
	 * The number of structural features of the '<em>Players Play Area</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_PLAY_AREA_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>Players Play Area</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_PLAY_AREA_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.CardsPlayedThisTurnImpl <em>Cards Played This Turn</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.CardsPlayedThisTurnImpl
	 * @see dominion.impl.DominionPackageImpl#getCardsPlayedThisTurn()
	 * @generated
	 */
	int CARDS_PLAYED_THIS_TURN = 7;

	/**
	 * The feature id for the '<em><b>Cards</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARDS_PLAYED_THIS_TURN__CARDS = 0;

	/**
	 * The feature id for the '<em><b>Cards Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARDS_PLAYED_THIS_TURN__CARDS_NUMBER = 1;

	/**
	 * The number of structural features of the '<em>Cards Played This Turn</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARDS_PLAYED_THIS_TURN_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Cards Played This Turn</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARDS_PLAYED_THIS_TURN_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.DiscardPileImpl <em>Discard Pile</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.DiscardPileImpl
	 * @see dominion.impl.DominionPackageImpl#getDiscardPile()
	 * @generated
	 */
	int DISCARD_PILE = 8;

	/**
	 * The feature id for the '<em><b>Cards</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCARD_PILE__CARDS = 0;

	/**
	 * The feature id for the '<em><b>Cards Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCARD_PILE__CARDS_NUMBER = 1;

	/**
	 * The number of structural features of the '<em>Discard Pile</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCARD_PILE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Discard Pile</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DISCARD_PILE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.AbilityImpl <em>Ability</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.AbilityImpl
	 * @see dominion.impl.DominionPackageImpl#getAbility()
	 * @generated
	 */
	int ABILITY = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABILITY__NAME = 0;

	/**
	 * The number of structural features of the '<em>Ability</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABILITY_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Ability</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABILITY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.PutCardInTrashImpl <em>Put Card In Trash</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.PutCardInTrashImpl
	 * @see dominion.impl.DominionPackageImpl#getPutCardInTrash()
	 * @generated
	 */
	int PUT_CARD_IN_TRASH = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUT_CARD_IN_TRASH__NAME = ABILITY__NAME;

	/**
	 * The number of structural features of the '<em>Put Card In Trash</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUT_CARD_IN_TRASH_FEATURE_COUNT = ABILITY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Put Card In Trash</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUT_CARD_IN_TRASH_OPERATION_COUNT = ABILITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.DrawCardsImpl <em>Draw Cards</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.DrawCardsImpl
	 * @see dominion.impl.DominionPackageImpl#getDrawCards()
	 * @generated
	 */
	int DRAW_CARDS = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRAW_CARDS__NAME = ABILITY__NAME;

	/**
	 * The feature id for the '<em><b>Card Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRAW_CARDS__CARD_NUMBER = ABILITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Draw Cards</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRAW_CARDS_FEATURE_COUNT = ABILITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Draw Cards</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DRAW_CARDS_OPERATION_COUNT = ABILITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.ActionPhaseImpl <em>Action Phase</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.ActionPhaseImpl
	 * @see dominion.impl.DominionPackageImpl#getActionPhase()
	 * @generated
	 */
	int ACTION_PHASE = 12;

	/**
	 * The feature id for the '<em><b>Playersactions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_PHASE__PLAYERSACTIONS = 0;

	/**
	 * The number of structural features of the '<em>Action Phase</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_PHASE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Action Phase</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_PHASE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.BuyPhaseImpl <em>Buy Phase</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.BuyPhaseImpl
	 * @see dominion.impl.DominionPackageImpl#getBuyPhase()
	 * @generated
	 */
	int BUY_PHASE = 13;

	/**
	 * The feature id for the '<em><b>Playersactions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUY_PHASE__PLAYERSACTIONS = 0;

	/**
	 * The number of structural features of the '<em>Buy Phase</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUY_PHASE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Buy Phase</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUY_PHASE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.CleanupPhaseImpl <em>Cleanup Phase</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.CleanupPhaseImpl
	 * @see dominion.impl.DominionPackageImpl#getCleanupPhase()
	 * @generated
	 */
	int CLEANUP_PHASE = 14;

	/**
	 * The feature id for the '<em><b>Put cards from hand to discard</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLEANUP_PHASE__PUT_CARDS_FROM_HAND_TO_DISCARD = 0;

	/**
	 * The number of structural features of the '<em>Cleanup Phase</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLEANUP_PHASE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Cleanup Phase</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CLEANUP_PHASE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.PlayersTurnImpl <em>Players Turn</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.PlayersTurnImpl
	 * @see dominion.impl.DominionPackageImpl#getPlayersTurn()
	 * @generated
	 */
	int PLAYERS_TURN = 15;

	/**
	 * The feature id for the '<em><b>Turn Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_TURN__TURN_NUMBER = 0;

	/**
	 * The feature id for the '<em><b>Player</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_TURN__PLAYER = 1;

	/**
	 * The feature id for the '<em><b>Players hand</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_TURN__PLAYERS_HAND = 2;

	/**
	 * The feature id for the '<em><b>Action phase</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_TURN__ACTION_PHASE = 3;

	/**
	 * The feature id for the '<em><b>Buyphase</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_TURN__BUYPHASE = 4;

	/**
	 * The feature id for the '<em><b>Cleanupphase</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_TURN__CLEANUPPHASE = 5;

	/**
	 * The number of structural features of the '<em>Players Turn</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_TURN_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Players Turn</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_TURN_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.PlayersActionImpl <em>Players Action</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.PlayersActionImpl
	 * @see dominion.impl.DominionPackageImpl#getPlayersAction()
	 * @generated
	 */
	int PLAYERS_ACTION = 24;

	/**
	 * The number of structural features of the '<em>Players Action</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_ACTION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Players Action</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAYERS_ACTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.BuyCardImpl <em>Buy Card</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.BuyCardImpl
	 * @see dominion.impl.DominionPackageImpl#getBuyCard()
	 * @generated
	 */
	int BUY_CARD = 16;

	/**
	 * The feature id for the '<em><b>Card</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUY_CARD__CARD = PLAYERS_ACTION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Buy Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUY_CARD_FEATURE_COUNT = PLAYERS_ACTION_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Buy Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BUY_CARD_OPERATION_COUNT = PLAYERS_ACTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.PutCardFromPileToDiscardImpl <em>Put Card From Pile To Discard</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.PutCardFromPileToDiscardImpl
	 * @see dominion.impl.DominionPackageImpl#getPutCardFromPileToDiscard()
	 * @generated
	 */
	int PUT_CARD_FROM_PILE_TO_DISCARD = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUT_CARD_FROM_PILE_TO_DISCARD__NAME = ABILITY__NAME;

	/**
	 * The feature id for the '<em><b>Discard pile</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUT_CARD_FROM_PILE_TO_DISCARD__DISCARD_PILE = ABILITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Put Card From Pile To Discard</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUT_CARD_FROM_PILE_TO_DISCARD_FEATURE_COUNT = ABILITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Put Card From Pile To Discard</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUT_CARD_FROM_PILE_TO_DISCARD_OPERATION_COUNT = ABILITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.ExtraBuysImpl <em>Extra Buys</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.ExtraBuysImpl
	 * @see dominion.impl.DominionPackageImpl#getExtraBuys()
	 * @generated
	 */
	int EXTRA_BUYS = 18;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTRA_BUYS__NAME = ABILITY__NAME;

	/**
	 * The feature id for the '<em><b>Buy Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTRA_BUYS__BUY_NUMBER = ABILITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Extra Buys</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTRA_BUYS_FEATURE_COUNT = ABILITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Extra Buys</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTRA_BUYS_OPERATION_COUNT = ABILITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.ExtraCoinsImpl <em>Extra Coins</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.ExtraCoinsImpl
	 * @see dominion.impl.DominionPackageImpl#getExtraCoins()
	 * @generated
	 */
	int EXTRA_COINS = 19;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTRA_COINS__NAME = ABILITY__NAME;

	/**
	 * The feature id for the '<em><b>Coin Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTRA_COINS__COIN_NUMBER = ABILITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Extra Coins</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTRA_COINS_FEATURE_COUNT = ABILITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Extra Coins</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTRA_COINS_OPERATION_COUNT = ABILITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.ExtraActionsImpl <em>Extra Actions</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.ExtraActionsImpl
	 * @see dominion.impl.DominionPackageImpl#getExtraActions()
	 * @generated
	 */
	int EXTRA_ACTIONS = 20;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTRA_ACTIONS__NAME = ABILITY__NAME;

	/**
	 * The feature id for the '<em><b>Action Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTRA_ACTIONS__ACTION_NUMBER = ABILITY_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Extra Actions</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTRA_ACTIONS_FEATURE_COUNT = ABILITY_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Extra Actions</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXTRA_ACTIONS_OPERATION_COUNT = ABILITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.DominionGameImpl <em>Game</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.DominionGameImpl
	 * @see dominion.impl.DominionPackageImpl#getDominionGame()
	 * @generated
	 */
	int DOMINION_GAME = 21;

	/**
	 * The feature id for the '<em><b>Playersplayarea</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMINION_GAME__PLAYERSPLAYAREA = 0;

	/**
	 * The feature id for the '<em><b>Players turns</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMINION_GAME__PLAYERS_TURNS = 1;

	/**
	 * The feature id for the '<em><b>Avaialble abilities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMINION_GAME__AVAIALBLE_ABILITIES = 2;

	/**
	 * The feature id for the '<em><b>Trashpile</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMINION_GAME__TRASHPILE = 3;

	/**
	 * The feature id for the '<em><b>Supply piles</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMINION_GAME__SUPPLY_PILES = 4;

	/**
	 * The number of structural features of the '<em>Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMINION_GAME_FEATURE_COUNT = 5;

	/**
	 * The operation id for the '<em>Print</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMINION_GAME___PRINT = 0;

	/**
	 * The number of operations of the '<em>Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMINION_GAME_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link dominion.impl.PutCardFromHandToDiscardImpl <em>Put Card From Hand To Discard</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.PutCardFromHandToDiscardImpl
	 * @see dominion.impl.DominionPackageImpl#getPutCardFromHandToDiscard()
	 * @generated
	 */
	int PUT_CARD_FROM_HAND_TO_DISCARD = 22;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUT_CARD_FROM_HAND_TO_DISCARD__NAME = ABILITY__NAME;

	/**
	 * The number of structural features of the '<em>Put Card From Hand To Discard</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUT_CARD_FROM_HAND_TO_DISCARD_FEATURE_COUNT = ABILITY_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Put Card From Hand To Discard</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PUT_CARD_FROM_HAND_TO_DISCARD_OPERATION_COUNT = ABILITY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.StrategyImpl <em>Strategy</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.StrategyImpl
	 * @see dominion.impl.DominionPackageImpl#getStrategy()
	 * @generated
	 */
	int STRATEGY = 23;

	/**
	 * The feature id for the '<em><b>Actionphase</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRATEGY__ACTIONPHASE = 0;

	/**
	 * The feature id for the '<em><b>Buyphase</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRATEGY__BUYPHASE = 1;

	/**
	 * The number of structural features of the '<em>Strategy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRATEGY_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Strategy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STRATEGY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.PlayActionImpl <em>Play Action</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.PlayActionImpl
	 * @see dominion.impl.DominionPackageImpl#getPlayAction()
	 * @generated
	 */
	int PLAY_ACTION = 25;

	/**
	 * The feature id for the '<em><b>Action card</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAY_ACTION__ACTION_CARD = PLAYERS_ACTION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Play Action</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAY_ACTION_FEATURE_COUNT = PLAYERS_ACTION_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Play Action</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLAY_ACTION_OPERATION_COUNT = PLAYERS_ACTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.IfActionImpl <em>If Action</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.IfActionImpl
	 * @see dominion.impl.DominionPackageImpl#getIfAction()
	 * @generated
	 */
	int IF_ACTION = 26;

	/**
	 * The feature id for the '<em><b>Condition</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IF_ACTION__CONDITION = PLAYERS_ACTION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Consequent action</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IF_ACTION__CONSEQUENT_ACTION = PLAYERS_ACTION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>If Action</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IF_ACTION_FEATURE_COUNT = PLAYERS_ACTION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>If Action</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IF_ACTION_OPERATION_COUNT = PLAYERS_ACTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.ExpressionImpl <em>Expression</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.ExpressionImpl
	 * @see dominion.impl.DominionPackageImpl#getExpression()
	 * @generated
	 */
	int EXPRESSION = 27;

	/**
	 * The number of structural features of the '<em>Expression</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXPRESSION_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Expression</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EXPRESSION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.FittingCardImpl <em>Fitting Card</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.FittingCardImpl
	 * @see dominion.impl.DominionPackageImpl#getFittingCard()
	 * @generated
	 */
	int FITTING_CARD = 28;

	/**
	 * The feature id for the '<em><b>Card</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FITTING_CARD__CARD = EXPRESSION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Fitting Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FITTING_CARD_FEATURE_COUNT = EXPRESSION_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Fitting Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FITTING_CARD_OPERATION_COUNT = EXPRESSION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.EnoughCoinsImpl <em>Enough Coins</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.EnoughCoinsImpl
	 * @see dominion.impl.DominionPackageImpl#getEnoughCoins()
	 * @generated
	 */
	int ENOUGH_COINS = 29;

	/**
	 * The feature id for the '<em><b>Coin Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENOUGH_COINS__COIN_NUMBER = EXPRESSION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Enough Coins</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENOUGH_COINS_FEATURE_COUNT = EXPRESSION_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Enough Coins</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENOUGH_COINS_OPERATION_COUNT = EXPRESSION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.WhileActionImpl <em>While Action</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.WhileActionImpl
	 * @see dominion.impl.DominionPackageImpl#getWhileAction()
	 * @generated
	 */
	int WHILE_ACTION = 30;

	/**
	 * The feature id for the '<em><b>Condition</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WHILE_ACTION__CONDITION = PLAYERS_ACTION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Playersaction</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WHILE_ACTION__PLAYERSACTION = PLAYERS_ACTION_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>While Action</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WHILE_ACTION_FEATURE_COUNT = PLAYERS_ACTION_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>While Action</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int WHILE_ACTION_OPERATION_COUNT = PLAYERS_ACTION_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.ActionCardImpl <em>Action Card</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.ActionCardImpl
	 * @see dominion.impl.DominionPackageImpl#getActionCard()
	 * @generated
	 */
	int ACTION_CARD = 31;

	/**
	 * The feature id for the '<em><b>Cost</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_CARD__COST = CARD__COST;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_CARD__NAME = CARD__NAME;

	/**
	 * The feature id for the '<em><b>Is Publicly Visible</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_CARD__IS_PUBLICLY_VISIBLE = CARD__IS_PUBLICLY_VISIBLE;

	/**
	 * The feature id for the '<em><b>Is Visible To Owner</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_CARD__IS_VISIBLE_TO_OWNER = CARD__IS_VISIBLE_TO_OWNER;

	/**
	 * The feature id for the '<em><b>Ability</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_CARD__ABILITY = CARD_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Action Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_CARD_FEATURE_COUNT = CARD_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Action Card</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_CARD_OPERATION_COUNT = CARD_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link dominion.impl.SupplyPileImpl <em>Supply Pile</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.SupplyPileImpl
	 * @see dominion.impl.DominionPackageImpl#getSupplyPile()
	 * @generated
	 */
	int SUPPLY_PILE = 32;

	/**
	 * The feature id for the '<em><b>Cards Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPLY_PILE__CARDS_NUMBER = 0;

	/**
	 * The feature id for the '<em><b>Cards</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPLY_PILE__CARDS = 1;

	/**
	 * The number of structural features of the '<em>Supply Pile</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPLY_PILE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Supply Pile</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SUPPLY_PILE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.TrashPileImpl <em>Trash Pile</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.TrashPileImpl
	 * @see dominion.impl.DominionPackageImpl#getTrashPile()
	 * @generated
	 */
	int TRASH_PILE = 33;

	/**
	 * The feature id for the '<em><b>Cards</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRASH_PILE__CARDS = 0;

	/**
	 * The number of structural features of the '<em>Trash Pile</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRASH_PILE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Trash Pile</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRASH_PILE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link dominion.impl.DominionProgramImpl <em>Program</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see dominion.impl.DominionProgramImpl
	 * @see dominion.impl.DominionPackageImpl#getDominionProgram()
	 * @generated
	 */
	int DOMINION_PROGRAM = 34;

	/**
	 * The feature id for the '<em><b>Dominiongame</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMINION_PROGRAM__DOMINIONGAME = 0;

	/**
	 * The feature id for the '<em><b>Card libraries</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMINION_PROGRAM__CARD_LIBRARIES = 1;

	/**
	 * The feature id for the '<em><b>Strategies</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMINION_PROGRAM__STRATEGIES = 2;

	/**
	 * The number of structural features of the '<em>Program</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMINION_PROGRAM_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Program</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DOMINION_PROGRAM_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link dominion.PlayersDeck <em>Players Deck</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Players Deck</em>'.
	 * @see dominion.PlayersDeck
	 * @generated
	 */
	EClass getPlayersDeck();

	/**
	 * Returns the meta object for the attribute '{@link dominion.PlayersDeck#getCardsNumber <em>Cards Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cards Number</em>'.
	 * @see dominion.PlayersDeck#getCardsNumber()
	 * @see #getPlayersDeck()
	 * @generated
	 */
	EAttribute getPlayersDeck_CardsNumber();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.PlayersDeck#getCards <em>Cards</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cards</em>'.
	 * @see dominion.PlayersDeck#getCards()
	 * @see #getPlayersDeck()
	 * @generated
	 */
	EReference getPlayersDeck_Cards();

	/**
	 * Returns the meta object for class '{@link dominion.Card <em>Card</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Card</em>'.
	 * @see dominion.Card
	 * @generated
	 */
	EClass getCard();

	/**
	 * Returns the meta object for the attribute '{@link dominion.Card#getCost <em>Cost</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cost</em>'.
	 * @see dominion.Card#getCost()
	 * @see #getCard()
	 * @generated
	 */
	EAttribute getCard_Cost();

	/**
	 * Returns the meta object for the attribute '{@link dominion.Card#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see dominion.Card#getName()
	 * @see #getCard()
	 * @generated
	 */
	EAttribute getCard_Name();

	/**
	 * Returns the meta object for the attribute '{@link dominion.Card#isIsPubliclyVisible <em>Is Publicly Visible</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Publicly Visible</em>'.
	 * @see dominion.Card#isIsPubliclyVisible()
	 * @see #getCard()
	 * @generated
	 */
	EAttribute getCard_IsPubliclyVisible();

	/**
	 * Returns the meta object for the attribute '{@link dominion.Card#isIsVisibleToOwner <em>Is Visible To Owner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Visible To Owner</em>'.
	 * @see dominion.Card#isIsVisibleToOwner()
	 * @see #getCard()
	 * @generated
	 */
	EAttribute getCard_IsVisibleToOwner();

	/**
	 * Returns the meta object for class '{@link dominion.TreasureCard <em>Treasure Card</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Treasure Card</em>'.
	 * @see dominion.TreasureCard
	 * @generated
	 */
	EClass getTreasureCard();

	/**
	 * Returns the meta object for the attribute '{@link dominion.TreasureCard#getValue <em>Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Value</em>'.
	 * @see dominion.TreasureCard#getValue()
	 * @see #getTreasureCard()
	 * @generated
	 */
	EAttribute getTreasureCard_Value();

	/**
	 * Returns the meta object for class '{@link dominion.VictoryCard <em>Victory Card</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Victory Card</em>'.
	 * @see dominion.VictoryCard
	 * @generated
	 */
	EClass getVictoryCard();

	/**
	 * Returns the meta object for the attribute '{@link dominion.VictoryCard#getVictoryPoints <em>Victory Points</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Victory Points</em>'.
	 * @see dominion.VictoryCard#getVictoryPoints()
	 * @see #getVictoryCard()
	 * @generated
	 */
	EAttribute getVictoryCard_VictoryPoints();

	/**
	 * Returns the meta object for class '{@link dominion.PlayersHand <em>Players Hand</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Players Hand</em>'.
	 * @see dominion.PlayersHand
	 * @generated
	 */
	EClass getPlayersHand();

	/**
	 * Returns the meta object for the attribute '{@link dominion.PlayersHand#getCardsNumber <em>Cards Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cards Number</em>'.
	 * @see dominion.PlayersHand#getCardsNumber()
	 * @see #getPlayersHand()
	 * @generated
	 */
	EAttribute getPlayersHand_CardsNumber();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.PlayersHand#getCards <em>Cards</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cards</em>'.
	 * @see dominion.PlayersHand#getCards()
	 * @see #getPlayersHand()
	 * @generated
	 */
	EReference getPlayersHand_Cards();

	/**
	 * Returns the meta object for class '{@link dominion.CardLibrary <em>Card Library</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Card Library</em>'.
	 * @see dominion.CardLibrary
	 * @generated
	 */
	EClass getCardLibrary();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.CardLibrary#getCard <em>Card</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Card</em>'.
	 * @see dominion.CardLibrary#getCard()
	 * @see #getCardLibrary()
	 * @generated
	 */
	EReference getCardLibrary_Card();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.CardLibrary#getAbilities <em>Abilities</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Abilities</em>'.
	 * @see dominion.CardLibrary#getAbilities()
	 * @see #getCardLibrary()
	 * @generated
	 */
	EReference getCardLibrary_Abilities();

	/**
	 * Returns the meta object for class '{@link dominion.PlayersPlayArea <em>Players Play Area</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Players Play Area</em>'.
	 * @see dominion.PlayersPlayArea
	 * @generated
	 */
	EClass getPlayersPlayArea();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.PlayersPlayArea#getCards_played_this_turn <em>Cards played this turn</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Cards played this turn</em>'.
	 * @see dominion.PlayersPlayArea#getCards_played_this_turn()
	 * @see #getPlayersPlayArea()
	 * @generated
	 */
	EReference getPlayersPlayArea_Cards_played_this_turn();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.PlayersPlayArea#getPlayers_deck <em>Players deck</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Players deck</em>'.
	 * @see dominion.PlayersPlayArea#getPlayers_deck()
	 * @see #getPlayersPlayArea()
	 * @generated
	 */
	EReference getPlayersPlayArea_Players_deck();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.PlayersPlayArea#getPlayers_hand <em>Players hand</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Players hand</em>'.
	 * @see dominion.PlayersPlayArea#getPlayers_hand()
	 * @see #getPlayersPlayArea()
	 * @generated
	 */
	EReference getPlayersPlayArea_Players_hand();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.PlayersPlayArea#getDiscard_pile <em>Discard pile</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Discard pile</em>'.
	 * @see dominion.PlayersPlayArea#getDiscard_pile()
	 * @see #getPlayersPlayArea()
	 * @generated
	 */
	EReference getPlayersPlayArea_Discard_pile();

	/**
	 * Returns the meta object for the attribute '{@link dominion.PlayersPlayArea#getPlayersName <em>Players Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Players Name</em>'.
	 * @see dominion.PlayersPlayArea#getPlayersName()
	 * @see #getPlayersPlayArea()
	 * @generated
	 */
	EAttribute getPlayersPlayArea_PlayersName();

	/**
	 * Returns the meta object for the attribute '{@link dominion.PlayersPlayArea#getActionsLeft <em>Actions Left</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Actions Left</em>'.
	 * @see dominion.PlayersPlayArea#getActionsLeft()
	 * @see #getPlayersPlayArea()
	 * @generated
	 */
	EAttribute getPlayersPlayArea_ActionsLeft();

	/**
	 * Returns the meta object for the attribute '{@link dominion.PlayersPlayArea#getBuysLeft <em>Buys Left</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Buys Left</em>'.
	 * @see dominion.PlayersPlayArea#getBuysLeft()
	 * @see #getPlayersPlayArea()
	 * @generated
	 */
	EAttribute getPlayersPlayArea_BuysLeft();

	/**
	 * Returns the meta object for class '{@link dominion.CardsPlayedThisTurn <em>Cards Played This Turn</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cards Played This Turn</em>'.
	 * @see dominion.CardsPlayedThisTurn
	 * @generated
	 */
	EClass getCardsPlayedThisTurn();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.CardsPlayedThisTurn#getCards <em>Cards</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cards</em>'.
	 * @see dominion.CardsPlayedThisTurn#getCards()
	 * @see #getCardsPlayedThisTurn()
	 * @generated
	 */
	EReference getCardsPlayedThisTurn_Cards();

	/**
	 * Returns the meta object for the attribute '{@link dominion.CardsPlayedThisTurn#getCardsNumber <em>Cards Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cards Number</em>'.
	 * @see dominion.CardsPlayedThisTurn#getCardsNumber()
	 * @see #getCardsPlayedThisTurn()
	 * @generated
	 */
	EAttribute getCardsPlayedThisTurn_CardsNumber();

	/**
	 * Returns the meta object for class '{@link dominion.DiscardPile <em>Discard Pile</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Discard Pile</em>'.
	 * @see dominion.DiscardPile
	 * @generated
	 */
	EClass getDiscardPile();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.DiscardPile#getCards <em>Cards</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cards</em>'.
	 * @see dominion.DiscardPile#getCards()
	 * @see #getDiscardPile()
	 * @generated
	 */
	EReference getDiscardPile_Cards();

	/**
	 * Returns the meta object for the attribute '{@link dominion.DiscardPile#getCardsNumber <em>Cards Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cards Number</em>'.
	 * @see dominion.DiscardPile#getCardsNumber()
	 * @see #getDiscardPile()
	 * @generated
	 */
	EAttribute getDiscardPile_CardsNumber();

	/**
	 * Returns the meta object for class '{@link dominion.Ability <em>Ability</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ability</em>'.
	 * @see dominion.Ability
	 * @generated
	 */
	EClass getAbility();

	/**
	 * Returns the meta object for the attribute '{@link dominion.Ability#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see dominion.Ability#getName()
	 * @see #getAbility()
	 * @generated
	 */
	EAttribute getAbility_Name();

	/**
	 * Returns the meta object for class '{@link dominion.PutCardInTrash <em>Put Card In Trash</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Put Card In Trash</em>'.
	 * @see dominion.PutCardInTrash
	 * @generated
	 */
	EClass getPutCardInTrash();

	/**
	 * Returns the meta object for class '{@link dominion.DrawCards <em>Draw Cards</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Draw Cards</em>'.
	 * @see dominion.DrawCards
	 * @generated
	 */
	EClass getDrawCards();

	/**
	 * Returns the meta object for the attribute '{@link dominion.DrawCards#getCardNumber <em>Card Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Card Number</em>'.
	 * @see dominion.DrawCards#getCardNumber()
	 * @see #getDrawCards()
	 * @generated
	 */
	EAttribute getDrawCards_CardNumber();

	/**
	 * Returns the meta object for class '{@link dominion.ActionPhase <em>Action Phase</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Action Phase</em>'.
	 * @see dominion.ActionPhase
	 * @generated
	 */
	EClass getActionPhase();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.ActionPhase#getPlayersactions <em>Playersactions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Playersactions</em>'.
	 * @see dominion.ActionPhase#getPlayersactions()
	 * @see #getActionPhase()
	 * @generated
	 */
	EReference getActionPhase_Playersactions();

	/**
	 * Returns the meta object for class '{@link dominion.BuyPhase <em>Buy Phase</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Buy Phase</em>'.
	 * @see dominion.BuyPhase
	 * @generated
	 */
	EClass getBuyPhase();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.BuyPhase#getPlayersactions <em>Playersactions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Playersactions</em>'.
	 * @see dominion.BuyPhase#getPlayersactions()
	 * @see #getBuyPhase()
	 * @generated
	 */
	EReference getBuyPhase_Playersactions();

	/**
	 * Returns the meta object for class '{@link dominion.CleanupPhase <em>Cleanup Phase</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cleanup Phase</em>'.
	 * @see dominion.CleanupPhase
	 * @generated
	 */
	EClass getCleanupPhase();

	/**
	 * Returns the meta object for the reference list '{@link dominion.CleanupPhase#getPut_cards_from_hand_to_discard <em>Put cards from hand to discard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Put cards from hand to discard</em>'.
	 * @see dominion.CleanupPhase#getPut_cards_from_hand_to_discard()
	 * @see #getCleanupPhase()
	 * @generated
	 */
	EReference getCleanupPhase_Put_cards_from_hand_to_discard();

	/**
	 * Returns the meta object for class '{@link dominion.PlayersTurn <em>Players Turn</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Players Turn</em>'.
	 * @see dominion.PlayersTurn
	 * @generated
	 */
	EClass getPlayersTurn();

	/**
	 * Returns the meta object for the attribute '{@link dominion.PlayersTurn#getTurnNumber <em>Turn Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Turn Number</em>'.
	 * @see dominion.PlayersTurn#getTurnNumber()
	 * @see #getPlayersTurn()
	 * @generated
	 */
	EAttribute getPlayersTurn_TurnNumber();

	/**
	 * Returns the meta object for the reference '{@link dominion.PlayersTurn#getPlayer <em>Player</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Player</em>'.
	 * @see dominion.PlayersTurn#getPlayer()
	 * @see #getPlayersTurn()
	 * @generated
	 */
	EReference getPlayersTurn_Player();

	/**
	 * Returns the meta object for the reference '{@link dominion.PlayersTurn#getPlayers_hand <em>Players hand</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Players hand</em>'.
	 * @see dominion.PlayersTurn#getPlayers_hand()
	 * @see #getPlayersTurn()
	 * @generated
	 */
	EReference getPlayersTurn_Players_hand();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.PlayersTurn#getAction_phase <em>Action phase</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Action phase</em>'.
	 * @see dominion.PlayersTurn#getAction_phase()
	 * @see #getPlayersTurn()
	 * @generated
	 */
	EReference getPlayersTurn_Action_phase();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.PlayersTurn#getBuyphase <em>Buyphase</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Buyphase</em>'.
	 * @see dominion.PlayersTurn#getBuyphase()
	 * @see #getPlayersTurn()
	 * @generated
	 */
	EReference getPlayersTurn_Buyphase();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.PlayersTurn#getCleanupphase <em>Cleanupphase</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Cleanupphase</em>'.
	 * @see dominion.PlayersTurn#getCleanupphase()
	 * @see #getPlayersTurn()
	 * @generated
	 */
	EReference getPlayersTurn_Cleanupphase();

	/**
	 * Returns the meta object for class '{@link dominion.BuyCard <em>Buy Card</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Buy Card</em>'.
	 * @see dominion.BuyCard
	 * @generated
	 */
	EClass getBuyCard();

	/**
	 * Returns the meta object for the reference '{@link dominion.BuyCard#getCard <em>Card</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Card</em>'.
	 * @see dominion.BuyCard#getCard()
	 * @see #getBuyCard()
	 * @generated
	 */
	EReference getBuyCard_Card();

	/**
	 * Returns the meta object for class '{@link dominion.PutCardFromPileToDiscard <em>Put Card From Pile To Discard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Put Card From Pile To Discard</em>'.
	 * @see dominion.PutCardFromPileToDiscard
	 * @generated
	 */
	EClass getPutCardFromPileToDiscard();

	/**
	 * Returns the meta object for the reference '{@link dominion.PutCardFromPileToDiscard#getDiscard_pile <em>Discard pile</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Discard pile</em>'.
	 * @see dominion.PutCardFromPileToDiscard#getDiscard_pile()
	 * @see #getPutCardFromPileToDiscard()
	 * @generated
	 */
	EReference getPutCardFromPileToDiscard_Discard_pile();

	/**
	 * Returns the meta object for class '{@link dominion.ExtraBuys <em>Extra Buys</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Extra Buys</em>'.
	 * @see dominion.ExtraBuys
	 * @generated
	 */
	EClass getExtraBuys();

	/**
	 * Returns the meta object for the attribute '{@link dominion.ExtraBuys#getBuyNumber <em>Buy Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Buy Number</em>'.
	 * @see dominion.ExtraBuys#getBuyNumber()
	 * @see #getExtraBuys()
	 * @generated
	 */
	EAttribute getExtraBuys_BuyNumber();

	/**
	 * Returns the meta object for class '{@link dominion.ExtraCoins <em>Extra Coins</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Extra Coins</em>'.
	 * @see dominion.ExtraCoins
	 * @generated
	 */
	EClass getExtraCoins();

	/**
	 * Returns the meta object for the attribute '{@link dominion.ExtraCoins#getCoinNumber <em>Coin Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Coin Number</em>'.
	 * @see dominion.ExtraCoins#getCoinNumber()
	 * @see #getExtraCoins()
	 * @generated
	 */
	EAttribute getExtraCoins_CoinNumber();

	/**
	 * Returns the meta object for class '{@link dominion.ExtraActions <em>Extra Actions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Extra Actions</em>'.
	 * @see dominion.ExtraActions
	 * @generated
	 */
	EClass getExtraActions();

	/**
	 * Returns the meta object for the attribute '{@link dominion.ExtraActions#getActionNumber <em>Action Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Action Number</em>'.
	 * @see dominion.ExtraActions#getActionNumber()
	 * @see #getExtraActions()
	 * @generated
	 */
	EAttribute getExtraActions_ActionNumber();

	/**
	 * Returns the meta object for class '{@link dominion.DominionGame <em>Game</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Game</em>'.
	 * @see dominion.DominionGame
	 * @generated
	 */
	EClass getDominionGame();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.DominionGame#getPlayersplayarea <em>Playersplayarea</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Playersplayarea</em>'.
	 * @see dominion.DominionGame#getPlayersplayarea()
	 * @see #getDominionGame()
	 * @generated
	 */
	EReference getDominionGame_Playersplayarea();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.DominionGame#getPlayers_turns <em>Players turns</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Players turns</em>'.
	 * @see dominion.DominionGame#getPlayers_turns()
	 * @see #getDominionGame()
	 * @generated
	 */
	EReference getDominionGame_Players_turns();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.DominionGame#getAvaialble_abilities <em>Avaialble abilities</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Avaialble abilities</em>'.
	 * @see dominion.DominionGame#getAvaialble_abilities()
	 * @see #getDominionGame()
	 * @generated
	 */
	EReference getDominionGame_Avaialble_abilities();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.DominionGame#getTrashpile <em>Trashpile</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Trashpile</em>'.
	 * @see dominion.DominionGame#getTrashpile()
	 * @see #getDominionGame()
	 * @generated
	 */
	EReference getDominionGame_Trashpile();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.DominionGame#getSupply_piles <em>Supply piles</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Supply piles</em>'.
	 * @see dominion.DominionGame#getSupply_piles()
	 * @see #getDominionGame()
	 * @generated
	 */
	EReference getDominionGame_Supply_piles();

	/**
	 * Returns the meta object for the '{@link dominion.DominionGame#print() <em>Print</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Print</em>' operation.
	 * @see dominion.DominionGame#print()
	 * @generated
	 */
	EOperation getDominionGame__Print();

	/**
	 * Returns the meta object for class '{@link dominion.PutCardFromHandToDiscard <em>Put Card From Hand To Discard</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Put Card From Hand To Discard</em>'.
	 * @see dominion.PutCardFromHandToDiscard
	 * @generated
	 */
	EClass getPutCardFromHandToDiscard();

	/**
	 * Returns the meta object for class '{@link dominion.Strategy <em>Strategy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Strategy</em>'.
	 * @see dominion.Strategy
	 * @generated
	 */
	EClass getStrategy();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.Strategy#getActionphase <em>Actionphase</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Actionphase</em>'.
	 * @see dominion.Strategy#getActionphase()
	 * @see #getStrategy()
	 * @generated
	 */
	EReference getStrategy_Actionphase();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.Strategy#getBuyphase <em>Buyphase</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Buyphase</em>'.
	 * @see dominion.Strategy#getBuyphase()
	 * @see #getStrategy()
	 * @generated
	 */
	EReference getStrategy_Buyphase();

	/**
	 * Returns the meta object for class '{@link dominion.PlayersAction <em>Players Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Players Action</em>'.
	 * @see dominion.PlayersAction
	 * @generated
	 */
	EClass getPlayersAction();

	/**
	 * Returns the meta object for class '{@link dominion.PlayAction <em>Play Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Play Action</em>'.
	 * @see dominion.PlayAction
	 * @generated
	 */
	EClass getPlayAction();

	/**
	 * Returns the meta object for the reference '{@link dominion.PlayAction#getAction_card <em>Action card</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Action card</em>'.
	 * @see dominion.PlayAction#getAction_card()
	 * @see #getPlayAction()
	 * @generated
	 */
	EReference getPlayAction_Action_card();

	/**
	 * Returns the meta object for class '{@link dominion.IfAction <em>If Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>If Action</em>'.
	 * @see dominion.IfAction
	 * @generated
	 */
	EClass getIfAction();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.IfAction#getCondition <em>Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Condition</em>'.
	 * @see dominion.IfAction#getCondition()
	 * @see #getIfAction()
	 * @generated
	 */
	EReference getIfAction_Condition();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.IfAction#getConsequent_action <em>Consequent action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Consequent action</em>'.
	 * @see dominion.IfAction#getConsequent_action()
	 * @see #getIfAction()
	 * @generated
	 */
	EReference getIfAction_Consequent_action();

	/**
	 * Returns the meta object for class '{@link dominion.Expression <em>Expression</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Expression</em>'.
	 * @see dominion.Expression
	 * @generated
	 */
	EClass getExpression();

	/**
	 * Returns the meta object for class '{@link dominion.FittingCard <em>Fitting Card</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fitting Card</em>'.
	 * @see dominion.FittingCard
	 * @generated
	 */
	EClass getFittingCard();

	/**
	 * Returns the meta object for the reference '{@link dominion.FittingCard#getCard <em>Card</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Card</em>'.
	 * @see dominion.FittingCard#getCard()
	 * @see #getFittingCard()
	 * @generated
	 */
	EReference getFittingCard_Card();

	/**
	 * Returns the meta object for class '{@link dominion.EnoughCoins <em>Enough Coins</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Enough Coins</em>'.
	 * @see dominion.EnoughCoins
	 * @generated
	 */
	EClass getEnoughCoins();

	/**
	 * Returns the meta object for the attribute '{@link dominion.EnoughCoins#getCoinNumber <em>Coin Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Coin Number</em>'.
	 * @see dominion.EnoughCoins#getCoinNumber()
	 * @see #getEnoughCoins()
	 * @generated
	 */
	EAttribute getEnoughCoins_CoinNumber();

	/**
	 * Returns the meta object for class '{@link dominion.WhileAction <em>While Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>While Action</em>'.
	 * @see dominion.WhileAction
	 * @generated
	 */
	EClass getWhileAction();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.WhileAction#getCondition <em>Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Condition</em>'.
	 * @see dominion.WhileAction#getCondition()
	 * @see #getWhileAction()
	 * @generated
	 */
	EReference getWhileAction_Condition();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.WhileAction#getPlayersaction <em>Playersaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Playersaction</em>'.
	 * @see dominion.WhileAction#getPlayersaction()
	 * @see #getWhileAction()
	 * @generated
	 */
	EReference getWhileAction_Playersaction();

	/**
	 * Returns the meta object for class '{@link dominion.ActionCard <em>Action Card</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Action Card</em>'.
	 * @see dominion.ActionCard
	 * @generated
	 */
	EClass getActionCard();

	/**
	 * Returns the meta object for the reference list '{@link dominion.ActionCard#getAbility <em>Ability</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Ability</em>'.
	 * @see dominion.ActionCard#getAbility()
	 * @see #getActionCard()
	 * @generated
	 */
	EReference getActionCard_Ability();

	/**
	 * Returns the meta object for class '{@link dominion.SupplyPile <em>Supply Pile</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Supply Pile</em>'.
	 * @see dominion.SupplyPile
	 * @generated
	 */
	EClass getSupplyPile();

	/**
	 * Returns the meta object for the attribute '{@link dominion.SupplyPile#getCardsNumber <em>Cards Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cards Number</em>'.
	 * @see dominion.SupplyPile#getCardsNumber()
	 * @see #getSupplyPile()
	 * @generated
	 */
	EAttribute getSupplyPile_CardsNumber();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.SupplyPile#getCards <em>Cards</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cards</em>'.
	 * @see dominion.SupplyPile#getCards()
	 * @see #getSupplyPile()
	 * @generated
	 */
	EReference getSupplyPile_Cards();

	/**
	 * Returns the meta object for class '{@link dominion.TrashPile <em>Trash Pile</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Trash Pile</em>'.
	 * @see dominion.TrashPile
	 * @generated
	 */
	EClass getTrashPile();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.TrashPile#getCards <em>Cards</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cards</em>'.
	 * @see dominion.TrashPile#getCards()
	 * @see #getTrashPile()
	 * @generated
	 */
	EReference getTrashPile_Cards();

	/**
	 * Returns the meta object for class '{@link dominion.DominionProgram <em>Program</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Program</em>'.
	 * @see dominion.DominionProgram
	 * @generated
	 */
	EClass getDominionProgram();

	/**
	 * Returns the meta object for the containment reference '{@link dominion.DominionProgram#getDominiongame <em>Dominiongame</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Dominiongame</em>'.
	 * @see dominion.DominionProgram#getDominiongame()
	 * @see #getDominionProgram()
	 * @generated
	 */
	EReference getDominionProgram_Dominiongame();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.DominionProgram#getCard_libraries <em>Card libraries</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Card libraries</em>'.
	 * @see dominion.DominionProgram#getCard_libraries()
	 * @see #getDominionProgram()
	 * @generated
	 */
	EReference getDominionProgram_Card_libraries();

	/**
	 * Returns the meta object for the containment reference list '{@link dominion.DominionProgram#getStrategies <em>Strategies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Strategies</em>'.
	 * @see dominion.DominionProgram#getStrategies()
	 * @see #getDominionProgram()
	 * @generated
	 */
	EReference getDominionProgram_Strategies();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	DominionFactory getDominionFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link dominion.impl.PlayersDeckImpl <em>Players Deck</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.PlayersDeckImpl
		 * @see dominion.impl.DominionPackageImpl#getPlayersDeck()
		 * @generated
		 */
		EClass PLAYERS_DECK = eINSTANCE.getPlayersDeck();

		/**
		 * The meta object literal for the '<em><b>Cards Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PLAYERS_DECK__CARDS_NUMBER = eINSTANCE.getPlayersDeck_CardsNumber();

		/**
		 * The meta object literal for the '<em><b>Cards</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLAYERS_DECK__CARDS = eINSTANCE.getPlayersDeck_Cards();

		/**
		 * The meta object literal for the '{@link dominion.impl.CardImpl <em>Card</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.CardImpl
		 * @see dominion.impl.DominionPackageImpl#getCard()
		 * @generated
		 */
		EClass CARD = eINSTANCE.getCard();

		/**
		 * The meta object literal for the '<em><b>Cost</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CARD__COST = eINSTANCE.getCard_Cost();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CARD__NAME = eINSTANCE.getCard_Name();

		/**
		 * The meta object literal for the '<em><b>Is Publicly Visible</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CARD__IS_PUBLICLY_VISIBLE = eINSTANCE.getCard_IsPubliclyVisible();

		/**
		 * The meta object literal for the '<em><b>Is Visible To Owner</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CARD__IS_VISIBLE_TO_OWNER = eINSTANCE.getCard_IsVisibleToOwner();

		/**
		 * The meta object literal for the '{@link dominion.impl.TreasureCardImpl <em>Treasure Card</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.TreasureCardImpl
		 * @see dominion.impl.DominionPackageImpl#getTreasureCard()
		 * @generated
		 */
		EClass TREASURE_CARD = eINSTANCE.getTreasureCard();

		/**
		 * The meta object literal for the '<em><b>Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TREASURE_CARD__VALUE = eINSTANCE.getTreasureCard_Value();

		/**
		 * The meta object literal for the '{@link dominion.impl.VictoryCardImpl <em>Victory Card</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.VictoryCardImpl
		 * @see dominion.impl.DominionPackageImpl#getVictoryCard()
		 * @generated
		 */
		EClass VICTORY_CARD = eINSTANCE.getVictoryCard();

		/**
		 * The meta object literal for the '<em><b>Victory Points</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VICTORY_CARD__VICTORY_POINTS = eINSTANCE.getVictoryCard_VictoryPoints();

		/**
		 * The meta object literal for the '{@link dominion.impl.PlayersHandImpl <em>Players Hand</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.PlayersHandImpl
		 * @see dominion.impl.DominionPackageImpl#getPlayersHand()
		 * @generated
		 */
		EClass PLAYERS_HAND = eINSTANCE.getPlayersHand();

		/**
		 * The meta object literal for the '<em><b>Cards Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PLAYERS_HAND__CARDS_NUMBER = eINSTANCE.getPlayersHand_CardsNumber();

		/**
		 * The meta object literal for the '<em><b>Cards</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLAYERS_HAND__CARDS = eINSTANCE.getPlayersHand_Cards();

		/**
		 * The meta object literal for the '{@link dominion.impl.CardLibraryImpl <em>Card Library</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.CardLibraryImpl
		 * @see dominion.impl.DominionPackageImpl#getCardLibrary()
		 * @generated
		 */
		EClass CARD_LIBRARY = eINSTANCE.getCardLibrary();

		/**
		 * The meta object literal for the '<em><b>Card</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CARD_LIBRARY__CARD = eINSTANCE.getCardLibrary_Card();

		/**
		 * The meta object literal for the '<em><b>Abilities</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CARD_LIBRARY__ABILITIES = eINSTANCE.getCardLibrary_Abilities();

		/**
		 * The meta object literal for the '{@link dominion.impl.PlayersPlayAreaImpl <em>Players Play Area</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.PlayersPlayAreaImpl
		 * @see dominion.impl.DominionPackageImpl#getPlayersPlayArea()
		 * @generated
		 */
		EClass PLAYERS_PLAY_AREA = eINSTANCE.getPlayersPlayArea();

		/**
		 * The meta object literal for the '<em><b>Cards played this turn</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLAYERS_PLAY_AREA__CARDS_PLAYED_THIS_TURN = eINSTANCE.getPlayersPlayArea_Cards_played_this_turn();

		/**
		 * The meta object literal for the '<em><b>Players deck</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLAYERS_PLAY_AREA__PLAYERS_DECK = eINSTANCE.getPlayersPlayArea_Players_deck();

		/**
		 * The meta object literal for the '<em><b>Players hand</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLAYERS_PLAY_AREA__PLAYERS_HAND = eINSTANCE.getPlayersPlayArea_Players_hand();

		/**
		 * The meta object literal for the '<em><b>Discard pile</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLAYERS_PLAY_AREA__DISCARD_PILE = eINSTANCE.getPlayersPlayArea_Discard_pile();

		/**
		 * The meta object literal for the '<em><b>Players Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PLAYERS_PLAY_AREA__PLAYERS_NAME = eINSTANCE.getPlayersPlayArea_PlayersName();

		/**
		 * The meta object literal for the '<em><b>Actions Left</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PLAYERS_PLAY_AREA__ACTIONS_LEFT = eINSTANCE.getPlayersPlayArea_ActionsLeft();

		/**
		 * The meta object literal for the '<em><b>Buys Left</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PLAYERS_PLAY_AREA__BUYS_LEFT = eINSTANCE.getPlayersPlayArea_BuysLeft();

		/**
		 * The meta object literal for the '{@link dominion.impl.CardsPlayedThisTurnImpl <em>Cards Played This Turn</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.CardsPlayedThisTurnImpl
		 * @see dominion.impl.DominionPackageImpl#getCardsPlayedThisTurn()
		 * @generated
		 */
		EClass CARDS_PLAYED_THIS_TURN = eINSTANCE.getCardsPlayedThisTurn();

		/**
		 * The meta object literal for the '<em><b>Cards</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CARDS_PLAYED_THIS_TURN__CARDS = eINSTANCE.getCardsPlayedThisTurn_Cards();

		/**
		 * The meta object literal for the '<em><b>Cards Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CARDS_PLAYED_THIS_TURN__CARDS_NUMBER = eINSTANCE.getCardsPlayedThisTurn_CardsNumber();

		/**
		 * The meta object literal for the '{@link dominion.impl.DiscardPileImpl <em>Discard Pile</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.DiscardPileImpl
		 * @see dominion.impl.DominionPackageImpl#getDiscardPile()
		 * @generated
		 */
		EClass DISCARD_PILE = eINSTANCE.getDiscardPile();

		/**
		 * The meta object literal for the '<em><b>Cards</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DISCARD_PILE__CARDS = eINSTANCE.getDiscardPile_Cards();

		/**
		 * The meta object literal for the '<em><b>Cards Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DISCARD_PILE__CARDS_NUMBER = eINSTANCE.getDiscardPile_CardsNumber();

		/**
		 * The meta object literal for the '{@link dominion.impl.AbilityImpl <em>Ability</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.AbilityImpl
		 * @see dominion.impl.DominionPackageImpl#getAbility()
		 * @generated
		 */
		EClass ABILITY = eINSTANCE.getAbility();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABILITY__NAME = eINSTANCE.getAbility_Name();

		/**
		 * The meta object literal for the '{@link dominion.impl.PutCardInTrashImpl <em>Put Card In Trash</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.PutCardInTrashImpl
		 * @see dominion.impl.DominionPackageImpl#getPutCardInTrash()
		 * @generated
		 */
		EClass PUT_CARD_IN_TRASH = eINSTANCE.getPutCardInTrash();

		/**
		 * The meta object literal for the '{@link dominion.impl.DrawCardsImpl <em>Draw Cards</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.DrawCardsImpl
		 * @see dominion.impl.DominionPackageImpl#getDrawCards()
		 * @generated
		 */
		EClass DRAW_CARDS = eINSTANCE.getDrawCards();

		/**
		 * The meta object literal for the '<em><b>Card Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DRAW_CARDS__CARD_NUMBER = eINSTANCE.getDrawCards_CardNumber();

		/**
		 * The meta object literal for the '{@link dominion.impl.ActionPhaseImpl <em>Action Phase</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.ActionPhaseImpl
		 * @see dominion.impl.DominionPackageImpl#getActionPhase()
		 * @generated
		 */
		EClass ACTION_PHASE = eINSTANCE.getActionPhase();

		/**
		 * The meta object literal for the '<em><b>Playersactions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTION_PHASE__PLAYERSACTIONS = eINSTANCE.getActionPhase_Playersactions();

		/**
		 * The meta object literal for the '{@link dominion.impl.BuyPhaseImpl <em>Buy Phase</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.BuyPhaseImpl
		 * @see dominion.impl.DominionPackageImpl#getBuyPhase()
		 * @generated
		 */
		EClass BUY_PHASE = eINSTANCE.getBuyPhase();

		/**
		 * The meta object literal for the '<em><b>Playersactions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUY_PHASE__PLAYERSACTIONS = eINSTANCE.getBuyPhase_Playersactions();

		/**
		 * The meta object literal for the '{@link dominion.impl.CleanupPhaseImpl <em>Cleanup Phase</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.CleanupPhaseImpl
		 * @see dominion.impl.DominionPackageImpl#getCleanupPhase()
		 * @generated
		 */
		EClass CLEANUP_PHASE = eINSTANCE.getCleanupPhase();

		/**
		 * The meta object literal for the '<em><b>Put cards from hand to discard</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CLEANUP_PHASE__PUT_CARDS_FROM_HAND_TO_DISCARD = eINSTANCE
				.getCleanupPhase_Put_cards_from_hand_to_discard();

		/**
		 * The meta object literal for the '{@link dominion.impl.PlayersTurnImpl <em>Players Turn</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.PlayersTurnImpl
		 * @see dominion.impl.DominionPackageImpl#getPlayersTurn()
		 * @generated
		 */
		EClass PLAYERS_TURN = eINSTANCE.getPlayersTurn();

		/**
		 * The meta object literal for the '<em><b>Turn Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PLAYERS_TURN__TURN_NUMBER = eINSTANCE.getPlayersTurn_TurnNumber();

		/**
		 * The meta object literal for the '<em><b>Player</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLAYERS_TURN__PLAYER = eINSTANCE.getPlayersTurn_Player();

		/**
		 * The meta object literal for the '<em><b>Players hand</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLAYERS_TURN__PLAYERS_HAND = eINSTANCE.getPlayersTurn_Players_hand();

		/**
		 * The meta object literal for the '<em><b>Action phase</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLAYERS_TURN__ACTION_PHASE = eINSTANCE.getPlayersTurn_Action_phase();

		/**
		 * The meta object literal for the '<em><b>Buyphase</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLAYERS_TURN__BUYPHASE = eINSTANCE.getPlayersTurn_Buyphase();

		/**
		 * The meta object literal for the '<em><b>Cleanupphase</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLAYERS_TURN__CLEANUPPHASE = eINSTANCE.getPlayersTurn_Cleanupphase();

		/**
		 * The meta object literal for the '{@link dominion.impl.BuyCardImpl <em>Buy Card</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.BuyCardImpl
		 * @see dominion.impl.DominionPackageImpl#getBuyCard()
		 * @generated
		 */
		EClass BUY_CARD = eINSTANCE.getBuyCard();

		/**
		 * The meta object literal for the '<em><b>Card</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BUY_CARD__CARD = eINSTANCE.getBuyCard_Card();

		/**
		 * The meta object literal for the '{@link dominion.impl.PutCardFromPileToDiscardImpl <em>Put Card From Pile To Discard</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.PutCardFromPileToDiscardImpl
		 * @see dominion.impl.DominionPackageImpl#getPutCardFromPileToDiscard()
		 * @generated
		 */
		EClass PUT_CARD_FROM_PILE_TO_DISCARD = eINSTANCE.getPutCardFromPileToDiscard();

		/**
		 * The meta object literal for the '<em><b>Discard pile</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PUT_CARD_FROM_PILE_TO_DISCARD__DISCARD_PILE = eINSTANCE.getPutCardFromPileToDiscard_Discard_pile();

		/**
		 * The meta object literal for the '{@link dominion.impl.ExtraBuysImpl <em>Extra Buys</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.ExtraBuysImpl
		 * @see dominion.impl.DominionPackageImpl#getExtraBuys()
		 * @generated
		 */
		EClass EXTRA_BUYS = eINSTANCE.getExtraBuys();

		/**
		 * The meta object literal for the '<em><b>Buy Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXTRA_BUYS__BUY_NUMBER = eINSTANCE.getExtraBuys_BuyNumber();

		/**
		 * The meta object literal for the '{@link dominion.impl.ExtraCoinsImpl <em>Extra Coins</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.ExtraCoinsImpl
		 * @see dominion.impl.DominionPackageImpl#getExtraCoins()
		 * @generated
		 */
		EClass EXTRA_COINS = eINSTANCE.getExtraCoins();

		/**
		 * The meta object literal for the '<em><b>Coin Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXTRA_COINS__COIN_NUMBER = eINSTANCE.getExtraCoins_CoinNumber();

		/**
		 * The meta object literal for the '{@link dominion.impl.ExtraActionsImpl <em>Extra Actions</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.ExtraActionsImpl
		 * @see dominion.impl.DominionPackageImpl#getExtraActions()
		 * @generated
		 */
		EClass EXTRA_ACTIONS = eINSTANCE.getExtraActions();

		/**
		 * The meta object literal for the '<em><b>Action Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EXTRA_ACTIONS__ACTION_NUMBER = eINSTANCE.getExtraActions_ActionNumber();

		/**
		 * The meta object literal for the '{@link dominion.impl.DominionGameImpl <em>Game</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.DominionGameImpl
		 * @see dominion.impl.DominionPackageImpl#getDominionGame()
		 * @generated
		 */
		EClass DOMINION_GAME = eINSTANCE.getDominionGame();

		/**
		 * The meta object literal for the '<em><b>Playersplayarea</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMINION_GAME__PLAYERSPLAYAREA = eINSTANCE.getDominionGame_Playersplayarea();

		/**
		 * The meta object literal for the '<em><b>Players turns</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMINION_GAME__PLAYERS_TURNS = eINSTANCE.getDominionGame_Players_turns();

		/**
		 * The meta object literal for the '<em><b>Avaialble abilities</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMINION_GAME__AVAIALBLE_ABILITIES = eINSTANCE.getDominionGame_Avaialble_abilities();

		/**
		 * The meta object literal for the '<em><b>Trashpile</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMINION_GAME__TRASHPILE = eINSTANCE.getDominionGame_Trashpile();

		/**
		 * The meta object literal for the '<em><b>Supply piles</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMINION_GAME__SUPPLY_PILES = eINSTANCE.getDominionGame_Supply_piles();

		/**
		 * The meta object literal for the '<em><b>Print</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation DOMINION_GAME___PRINT = eINSTANCE.getDominionGame__Print();

		/**
		 * The meta object literal for the '{@link dominion.impl.PutCardFromHandToDiscardImpl <em>Put Card From Hand To Discard</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.PutCardFromHandToDiscardImpl
		 * @see dominion.impl.DominionPackageImpl#getPutCardFromHandToDiscard()
		 * @generated
		 */
		EClass PUT_CARD_FROM_HAND_TO_DISCARD = eINSTANCE.getPutCardFromHandToDiscard();

		/**
		 * The meta object literal for the '{@link dominion.impl.StrategyImpl <em>Strategy</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.StrategyImpl
		 * @see dominion.impl.DominionPackageImpl#getStrategy()
		 * @generated
		 */
		EClass STRATEGY = eINSTANCE.getStrategy();

		/**
		 * The meta object literal for the '<em><b>Actionphase</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STRATEGY__ACTIONPHASE = eINSTANCE.getStrategy_Actionphase();

		/**
		 * The meta object literal for the '<em><b>Buyphase</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STRATEGY__BUYPHASE = eINSTANCE.getStrategy_Buyphase();

		/**
		 * The meta object literal for the '{@link dominion.impl.PlayersActionImpl <em>Players Action</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.PlayersActionImpl
		 * @see dominion.impl.DominionPackageImpl#getPlayersAction()
		 * @generated
		 */
		EClass PLAYERS_ACTION = eINSTANCE.getPlayersAction();

		/**
		 * The meta object literal for the '{@link dominion.impl.PlayActionImpl <em>Play Action</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.PlayActionImpl
		 * @see dominion.impl.DominionPackageImpl#getPlayAction()
		 * @generated
		 */
		EClass PLAY_ACTION = eINSTANCE.getPlayAction();

		/**
		 * The meta object literal for the '<em><b>Action card</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLAY_ACTION__ACTION_CARD = eINSTANCE.getPlayAction_Action_card();

		/**
		 * The meta object literal for the '{@link dominion.impl.IfActionImpl <em>If Action</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.IfActionImpl
		 * @see dominion.impl.DominionPackageImpl#getIfAction()
		 * @generated
		 */
		EClass IF_ACTION = eINSTANCE.getIfAction();

		/**
		 * The meta object literal for the '<em><b>Condition</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IF_ACTION__CONDITION = eINSTANCE.getIfAction_Condition();

		/**
		 * The meta object literal for the '<em><b>Consequent action</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IF_ACTION__CONSEQUENT_ACTION = eINSTANCE.getIfAction_Consequent_action();

		/**
		 * The meta object literal for the '{@link dominion.impl.ExpressionImpl <em>Expression</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.ExpressionImpl
		 * @see dominion.impl.DominionPackageImpl#getExpression()
		 * @generated
		 */
		EClass EXPRESSION = eINSTANCE.getExpression();

		/**
		 * The meta object literal for the '{@link dominion.impl.FittingCardImpl <em>Fitting Card</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.FittingCardImpl
		 * @see dominion.impl.DominionPackageImpl#getFittingCard()
		 * @generated
		 */
		EClass FITTING_CARD = eINSTANCE.getFittingCard();

		/**
		 * The meta object literal for the '<em><b>Card</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FITTING_CARD__CARD = eINSTANCE.getFittingCard_Card();

		/**
		 * The meta object literal for the '{@link dominion.impl.EnoughCoinsImpl <em>Enough Coins</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.EnoughCoinsImpl
		 * @see dominion.impl.DominionPackageImpl#getEnoughCoins()
		 * @generated
		 */
		EClass ENOUGH_COINS = eINSTANCE.getEnoughCoins();

		/**
		 * The meta object literal for the '<em><b>Coin Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENOUGH_COINS__COIN_NUMBER = eINSTANCE.getEnoughCoins_CoinNumber();

		/**
		 * The meta object literal for the '{@link dominion.impl.WhileActionImpl <em>While Action</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.WhileActionImpl
		 * @see dominion.impl.DominionPackageImpl#getWhileAction()
		 * @generated
		 */
		EClass WHILE_ACTION = eINSTANCE.getWhileAction();

		/**
		 * The meta object literal for the '<em><b>Condition</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WHILE_ACTION__CONDITION = eINSTANCE.getWhileAction_Condition();

		/**
		 * The meta object literal for the '<em><b>Playersaction</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference WHILE_ACTION__PLAYERSACTION = eINSTANCE.getWhileAction_Playersaction();

		/**
		 * The meta object literal for the '{@link dominion.impl.ActionCardImpl <em>Action Card</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.ActionCardImpl
		 * @see dominion.impl.DominionPackageImpl#getActionCard()
		 * @generated
		 */
		EClass ACTION_CARD = eINSTANCE.getActionCard();

		/**
		 * The meta object literal for the '<em><b>Ability</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ACTION_CARD__ABILITY = eINSTANCE.getActionCard_Ability();

		/**
		 * The meta object literal for the '{@link dominion.impl.SupplyPileImpl <em>Supply Pile</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.SupplyPileImpl
		 * @see dominion.impl.DominionPackageImpl#getSupplyPile()
		 * @generated
		 */
		EClass SUPPLY_PILE = eINSTANCE.getSupplyPile();

		/**
		 * The meta object literal for the '<em><b>Cards Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SUPPLY_PILE__CARDS_NUMBER = eINSTANCE.getSupplyPile_CardsNumber();

		/**
		 * The meta object literal for the '<em><b>Cards</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SUPPLY_PILE__CARDS = eINSTANCE.getSupplyPile_Cards();

		/**
		 * The meta object literal for the '{@link dominion.impl.TrashPileImpl <em>Trash Pile</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.TrashPileImpl
		 * @see dominion.impl.DominionPackageImpl#getTrashPile()
		 * @generated
		 */
		EClass TRASH_PILE = eINSTANCE.getTrashPile();

		/**
		 * The meta object literal for the '<em><b>Cards</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRASH_PILE__CARDS = eINSTANCE.getTrashPile_Cards();

		/**
		 * The meta object literal for the '{@link dominion.impl.DominionProgramImpl <em>Program</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see dominion.impl.DominionProgramImpl
		 * @see dominion.impl.DominionPackageImpl#getDominionProgram()
		 * @generated
		 */
		EClass DOMINION_PROGRAM = eINSTANCE.getDominionProgram();

		/**
		 * The meta object literal for the '<em><b>Dominiongame</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMINION_PROGRAM__DOMINIONGAME = eINSTANCE.getDominionProgram_Dominiongame();

		/**
		 * The meta object literal for the '<em><b>Card libraries</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMINION_PROGRAM__CARD_LIBRARIES = eINSTANCE.getDominionProgram_Card_libraries();

		/**
		 * The meta object literal for the '<em><b>Strategies</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DOMINION_PROGRAM__STRATEGIES = eINSTANCE.getDominionProgram_Strategies();

	}

} //DominionPackage
