/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Victory Card</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.VictoryCard#getVictoryPoints <em>Victory Points</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getVictoryCard()
 * @model
 * @generated
 */
public interface VictoryCard extends Card {
	/**
	 * Returns the value of the '<em><b>Victory Points</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Victory Points</em>' attribute.
	 * @see #setVictoryPoints(int)
	 * @see dominion.DominionPackage#getVictoryCard_VictoryPoints()
	 * @model required="true"
	 * @generated
	 */
	int getVictoryPoints();

	/**
	 * Sets the value of the '{@link dominion.VictoryCard#getVictoryPoints <em>Victory Points</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Victory Points</em>' attribute.
	 * @see #getVictoryPoints()
	 * @generated
	 */
	void setVictoryPoints(int value);

} // VictoryCard
