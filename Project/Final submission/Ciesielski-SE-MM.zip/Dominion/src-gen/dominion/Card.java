/**
 */
package dominion;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Card</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.Card#getCost <em>Cost</em>}</li>
 *   <li>{@link dominion.Card#getName <em>Name</em>}</li>
 *   <li>{@link dominion.Card#isIsPubliclyVisible <em>Is Publicly Visible</em>}</li>
 *   <li>{@link dominion.Card#isIsVisibleToOwner <em>Is Visible To Owner</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getCard()
 * @model abstract="true"
 * @generated
 */
public interface Card extends EObject {
	/**
	 * Returns the value of the '<em><b>Cost</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cost</em>' attribute.
	 * @see #setCost(int)
	 * @see dominion.DominionPackage#getCard_Cost()
	 * @model required="true"
	 * @generated
	 */
	int getCost();

	/**
	 * Sets the value of the '{@link dominion.Card#getCost <em>Cost</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cost</em>' attribute.
	 * @see #getCost()
	 * @generated
	 */
	void setCost(int value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see dominion.DominionPackage#getCard_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link dominion.Card#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Is Publicly Visible</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Publicly Visible</em>' attribute.
	 * @see #setIsPubliclyVisible(boolean)
	 * @see dominion.DominionPackage#getCard_IsPubliclyVisible()
	 * @model
	 * @generated
	 */
	boolean isIsPubliclyVisible();

	/**
	 * Sets the value of the '{@link dominion.Card#isIsPubliclyVisible <em>Is Publicly Visible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Publicly Visible</em>' attribute.
	 * @see #isIsPubliclyVisible()
	 * @generated
	 */
	void setIsPubliclyVisible(boolean value);

	/**
	 * Returns the value of the '<em><b>Is Visible To Owner</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Visible To Owner</em>' attribute.
	 * @see #setIsVisibleToOwner(boolean)
	 * @see dominion.DominionPackage#getCard_IsVisibleToOwner()
	 * @model
	 * @generated
	 */
	boolean isIsVisibleToOwner();

	/**
	 * Sets the value of the '{@link dominion.Card#isIsVisibleToOwner <em>Is Visible To Owner</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Visible To Owner</em>' attribute.
	 * @see #isIsVisibleToOwner()
	 * @generated
	 */
	void setIsVisibleToOwner(boolean value);

} // Card
