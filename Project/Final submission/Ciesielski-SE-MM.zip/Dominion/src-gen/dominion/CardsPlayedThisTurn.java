/**
 */
package dominion;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cards Played This Turn</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.CardsPlayedThisTurn#getCards <em>Cards</em>}</li>
 *   <li>{@link dominion.CardsPlayedThisTurn#getCardsNumber <em>Cards Number</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getCardsPlayedThisTurn()
 * @model
 * @generated
 */
public interface CardsPlayedThisTurn extends EObject {
	/**
	 * Returns the value of the '<em><b>Cards</b></em>' containment reference list.
	 * The list contents are of type {@link dominion.Card}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cards</em>' containment reference list.
	 * @see dominion.DominionPackage#getCardsPlayedThisTurn_Cards()
	 * @model containment="true"
	 * @generated
	 */
	EList<Card> getCards();

	/**
	 * Returns the value of the '<em><b>Cards Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cards Number</em>' attribute.
	 * @see #setCardsNumber(int)
	 * @see dominion.DominionPackage#getCardsPlayedThisTurn_CardsNumber()
	 * @model required="true"
	 * @generated
	 */
	int getCardsNumber();

	/**
	 * Sets the value of the '{@link dominion.CardsPlayedThisTurn#getCardsNumber <em>Cards Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cards Number</em>' attribute.
	 * @see #getCardsNumber()
	 * @generated
	 */
	void setCardsNumber(int value);

} // CardsPlayedThisTurn
