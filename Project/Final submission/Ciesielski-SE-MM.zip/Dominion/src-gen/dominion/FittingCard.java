/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fitting Card</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.FittingCard#getCard <em>Card</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getFittingCard()
 * @model
 * @generated
 */
public interface FittingCard extends Expression {
	/**
	 * Returns the value of the '<em><b>Card</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Card</em>' reference.
	 * @see #setCard(Card)
	 * @see dominion.DominionPackage#getFittingCard_Card()
	 * @model required="true"
	 * @generated
	 */
	Card getCard();

	/**
	 * Sets the value of the '{@link dominion.FittingCard#getCard <em>Card</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Card</em>' reference.
	 * @see #getCard()
	 * @generated
	 */
	void setCard(Card value);

} // FittingCard
