/**
 */
package dominion;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Action Phase</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.ActionPhase#getPlayersactions <em>Playersactions</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getActionPhase()
 * @model
 * @generated
 */
public interface ActionPhase extends EObject {
	/**
	 * Returns the value of the '<em><b>Playersactions</b></em>' containment reference list.
	 * The list contents are of type {@link dominion.PlayersAction}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Playersactions</em>' containment reference list.
	 * @see dominion.DominionPackage#getActionPhase_Playersactions()
	 * @model containment="true"
	 * @generated
	 */
	EList<PlayersAction> getPlayersactions();

} // ActionPhase
