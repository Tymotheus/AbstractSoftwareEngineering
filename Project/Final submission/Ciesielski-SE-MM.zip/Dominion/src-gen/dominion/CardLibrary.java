/**
 */
package dominion;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Card Library</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.CardLibrary#getCard <em>Card</em>}</li>
 *   <li>{@link dominion.CardLibrary#getAbilities <em>Abilities</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getCardLibrary()
 * @model
 * @generated
 */
public interface CardLibrary extends EObject {
	/**
	 * Returns the value of the '<em><b>Card</b></em>' containment reference list.
	 * The list contents are of type {@link dominion.Card}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Card</em>' containment reference list.
	 * @see dominion.DominionPackage#getCardLibrary_Card()
	 * @model containment="true"
	 * @generated
	 */
	EList<Card> getCard();

	/**
	 * Returns the value of the '<em><b>Abilities</b></em>' containment reference list.
	 * The list contents are of type {@link dominion.Ability}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Abilities</em>' containment reference list.
	 * @see dominion.DominionPackage#getCardLibrary_Abilities()
	 * @model containment="true"
	 * @generated
	 */
	EList<Ability> getAbilities();

} // CardLibrary
