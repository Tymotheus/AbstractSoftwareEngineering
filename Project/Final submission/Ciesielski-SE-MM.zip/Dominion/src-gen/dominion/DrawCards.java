/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Draw Cards</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.DrawCards#getCardNumber <em>Card Number</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getDrawCards()
 * @model
 * @generated
 */
public interface DrawCards extends Ability {
	/**
	 * Returns the value of the '<em><b>Card Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Card Number</em>' attribute.
	 * @see #setCardNumber(int)
	 * @see dominion.DominionPackage#getDrawCards_CardNumber()
	 * @model required="true"
	 * @generated
	 */
	int getCardNumber();

	/**
	 * Sets the value of the '{@link dominion.DrawCards#getCardNumber <em>Card Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Card Number</em>' attribute.
	 * @see #getCardNumber()
	 * @generated
	 */
	void setCardNumber(int value);

} // DrawCards
