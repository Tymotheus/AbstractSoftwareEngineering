/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Play Action</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.PlayAction#getAction_card <em>Action card</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getPlayAction()
 * @model
 * @generated
 */
public interface PlayAction extends PlayersAction {
	/**
	 * Returns the value of the '<em><b>Action card</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Action card</em>' reference.
	 * @see #setAction_card(Card)
	 * @see dominion.DominionPackage#getPlayAction_Action_card()
	 * @model required="true"
	 * @generated
	 */
	Card getAction_card();

	/**
	 * Sets the value of the '{@link dominion.PlayAction#getAction_card <em>Action card</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Action card</em>' reference.
	 * @see #getAction_card()
	 * @generated
	 */
	void setAction_card(Card value);

} // PlayAction
