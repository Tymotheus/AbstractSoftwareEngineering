/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Extra Coins</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.ExtraCoins#getCoinNumber <em>Coin Number</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getExtraCoins()
 * @model
 * @generated
 */
public interface ExtraCoins extends Ability {
	/**
	 * Returns the value of the '<em><b>Coin Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Coin Number</em>' attribute.
	 * @see #setCoinNumber(int)
	 * @see dominion.DominionPackage#getExtraCoins_CoinNumber()
	 * @model required="true"
	 * @generated
	 */
	int getCoinNumber();

	/**
	 * Sets the value of the '{@link dominion.ExtraCoins#getCoinNumber <em>Coin Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Coin Number</em>' attribute.
	 * @see #getCoinNumber()
	 * @generated
	 */
	void setCoinNumber(int value);

} // ExtraCoins
