/**
 */
package dominion;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Program</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.DominionProgram#getDominiongame <em>Dominiongame</em>}</li>
 *   <li>{@link dominion.DominionProgram#getCard_libraries <em>Card libraries</em>}</li>
 *   <li>{@link dominion.DominionProgram#getStrategies <em>Strategies</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getDominionProgram()
 * @model
 * @generated
 */
public interface DominionProgram extends EObject {
	/**
	 * Returns the value of the '<em><b>Dominiongame</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dominiongame</em>' containment reference.
	 * @see #setDominiongame(DominionGame)
	 * @see dominion.DominionPackage#getDominionProgram_Dominiongame()
	 * @model containment="true"
	 * @generated
	 */
	DominionGame getDominiongame();

	/**
	 * Sets the value of the '{@link dominion.DominionProgram#getDominiongame <em>Dominiongame</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dominiongame</em>' containment reference.
	 * @see #getDominiongame()
	 * @generated
	 */
	void setDominiongame(DominionGame value);

	/**
	 * Returns the value of the '<em><b>Card libraries</b></em>' containment reference list.
	 * The list contents are of type {@link dominion.CardLibrary}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Card libraries</em>' containment reference list.
	 * @see dominion.DominionPackage#getDominionProgram_Card_libraries()
	 * @model containment="true"
	 * @generated
	 */
	EList<CardLibrary> getCard_libraries();

	/**
	 * Returns the value of the '<em><b>Strategies</b></em>' containment reference list.
	 * The list contents are of type {@link dominion.Strategy}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Strategies</em>' containment reference list.
	 * @see dominion.DominionPackage#getDominionProgram_Strategies()
	 * @model containment="true"
	 * @generated
	 */
	EList<Strategy> getStrategies();

} // DominionProgram
