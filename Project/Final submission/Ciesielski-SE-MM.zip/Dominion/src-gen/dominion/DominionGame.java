/**
 */
package dominion;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Game</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.DominionGame#getPlayersplayarea <em>Playersplayarea</em>}</li>
 *   <li>{@link dominion.DominionGame#getPlayers_turns <em>Players turns</em>}</li>
 *   <li>{@link dominion.DominionGame#getAvaialble_abilities <em>Avaialble abilities</em>}</li>
 *   <li>{@link dominion.DominionGame#getTrashpile <em>Trashpile</em>}</li>
 *   <li>{@link dominion.DominionGame#getSupply_piles <em>Supply piles</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getDominionGame()
 * @model
 * @generated
 */
public interface DominionGame extends EObject {
	/**
	 * Returns the value of the '<em><b>Playersplayarea</b></em>' containment reference list.
	 * The list contents are of type {@link dominion.PlayersPlayArea}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Playersplayarea</em>' containment reference list.
	 * @see dominion.DominionPackage#getDominionGame_Playersplayarea()
	 * @model containment="true" upper="4"
	 * @generated
	 */
	EList<PlayersPlayArea> getPlayersplayarea();

	/**
	 * Returns the value of the '<em><b>Players turns</b></em>' containment reference list.
	 * The list contents are of type {@link dominion.PlayersTurn}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Players turns</em>' containment reference list.
	 * @see dominion.DominionPackage#getDominionGame_Players_turns()
	 * @model containment="true"
	 * @generated
	 */
	EList<PlayersTurn> getPlayers_turns();

	/**
	 * Returns the value of the '<em><b>Avaialble abilities</b></em>' containment reference list.
	 * The list contents are of type {@link dominion.Ability}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Avaialble abilities</em>' containment reference list.
	 * @see dominion.DominionPackage#getDominionGame_Avaialble_abilities()
	 * @model containment="true"
	 * @generated
	 */
	EList<Ability> getAvaialble_abilities();

	/**
	 * Returns the value of the '<em><b>Trashpile</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trashpile</em>' containment reference.
	 * @see #setTrashpile(TrashPile)
	 * @see dominion.DominionPackage#getDominionGame_Trashpile()
	 * @model containment="true"
	 * @generated
	 */
	TrashPile getTrashpile();

	/**
	 * Sets the value of the '{@link dominion.DominionGame#getTrashpile <em>Trashpile</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trashpile</em>' containment reference.
	 * @see #getTrashpile()
	 * @generated
	 */
	void setTrashpile(TrashPile value);

	/**
	 * Returns the value of the '<em><b>Supply piles</b></em>' containment reference list.
	 * The list contents are of type {@link dominion.SupplyPile}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Supply piles</em>' containment reference list.
	 * @see dominion.DominionPackage#getDominionGame_Supply_piles()
	 * @model containment="true"
	 * @generated
	 */
	EList<SupplyPile> getSupply_piles();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void print();

} // DominionGame
