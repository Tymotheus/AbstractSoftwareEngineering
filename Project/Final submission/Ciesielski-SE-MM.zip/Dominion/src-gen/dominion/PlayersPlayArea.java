/**
 */
package dominion;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Players Play Area</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.PlayersPlayArea#getCards_played_this_turn <em>Cards played this turn</em>}</li>
 *   <li>{@link dominion.PlayersPlayArea#getPlayers_deck <em>Players deck</em>}</li>
 *   <li>{@link dominion.PlayersPlayArea#getPlayers_hand <em>Players hand</em>}</li>
 *   <li>{@link dominion.PlayersPlayArea#getDiscard_pile <em>Discard pile</em>}</li>
 *   <li>{@link dominion.PlayersPlayArea#getPlayersName <em>Players Name</em>}</li>
 *   <li>{@link dominion.PlayersPlayArea#getActionsLeft <em>Actions Left</em>}</li>
 *   <li>{@link dominion.PlayersPlayArea#getBuysLeft <em>Buys Left</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getPlayersPlayArea()
 * @model
 * @generated
 */
public interface PlayersPlayArea extends EObject {
	/**
	 * Returns the value of the '<em><b>Cards played this turn</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cards played this turn</em>' containment reference.
	 * @see #setCards_played_this_turn(CardsPlayedThisTurn)
	 * @see dominion.DominionPackage#getPlayersPlayArea_Cards_played_this_turn()
	 * @model containment="true" required="true"
	 * @generated
	 */
	CardsPlayedThisTurn getCards_played_this_turn();

	/**
	 * Sets the value of the '{@link dominion.PlayersPlayArea#getCards_played_this_turn <em>Cards played this turn</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cards played this turn</em>' containment reference.
	 * @see #getCards_played_this_turn()
	 * @generated
	 */
	void setCards_played_this_turn(CardsPlayedThisTurn value);

	/**
	 * Returns the value of the '<em><b>Players deck</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Players deck</em>' containment reference.
	 * @see #setPlayers_deck(PlayersDeck)
	 * @see dominion.DominionPackage#getPlayersPlayArea_Players_deck()
	 * @model containment="true" required="true"
	 * @generated
	 */
	PlayersDeck getPlayers_deck();

	/**
	 * Sets the value of the '{@link dominion.PlayersPlayArea#getPlayers_deck <em>Players deck</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Players deck</em>' containment reference.
	 * @see #getPlayers_deck()
	 * @generated
	 */
	void setPlayers_deck(PlayersDeck value);

	/**
	 * Returns the value of the '<em><b>Players hand</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Players hand</em>' containment reference.
	 * @see #setPlayers_hand(PlayersHand)
	 * @see dominion.DominionPackage#getPlayersPlayArea_Players_hand()
	 * @model containment="true" required="true"
	 * @generated
	 */
	PlayersHand getPlayers_hand();

	/**
	 * Sets the value of the '{@link dominion.PlayersPlayArea#getPlayers_hand <em>Players hand</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Players hand</em>' containment reference.
	 * @see #getPlayers_hand()
	 * @generated
	 */
	void setPlayers_hand(PlayersHand value);

	/**
	 * Returns the value of the '<em><b>Discard pile</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Discard pile</em>' containment reference.
	 * @see #setDiscard_pile(DiscardPile)
	 * @see dominion.DominionPackage#getPlayersPlayArea_Discard_pile()
	 * @model containment="true" required="true"
	 * @generated
	 */
	DiscardPile getDiscard_pile();

	/**
	 * Sets the value of the '{@link dominion.PlayersPlayArea#getDiscard_pile <em>Discard pile</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Discard pile</em>' containment reference.
	 * @see #getDiscard_pile()
	 * @generated
	 */
	void setDiscard_pile(DiscardPile value);

	/**
	 * Returns the value of the '<em><b>Players Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Players Name</em>' attribute.
	 * @see #setPlayersName(String)
	 * @see dominion.DominionPackage#getPlayersPlayArea_PlayersName()
	 * @model
	 * @generated
	 */
	String getPlayersName();

	/**
	 * Sets the value of the '{@link dominion.PlayersPlayArea#getPlayersName <em>Players Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Players Name</em>' attribute.
	 * @see #getPlayersName()
	 * @generated
	 */
	void setPlayersName(String value);

	/**
	 * Returns the value of the '<em><b>Actions Left</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Actions Left</em>' attribute.
	 * @see #setActionsLeft(int)
	 * @see dominion.DominionPackage#getPlayersPlayArea_ActionsLeft()
	 * @model
	 * @generated
	 */
	int getActionsLeft();

	/**
	 * Sets the value of the '{@link dominion.PlayersPlayArea#getActionsLeft <em>Actions Left</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Actions Left</em>' attribute.
	 * @see #getActionsLeft()
	 * @generated
	 */
	void setActionsLeft(int value);

	/**
	 * Returns the value of the '<em><b>Buys Left</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Buys Left</em>' attribute.
	 * @see #setBuysLeft(int)
	 * @see dominion.DominionPackage#getPlayersPlayArea_BuysLeft()
	 * @model
	 * @generated
	 */
	int getBuysLeft();

	/**
	 * Sets the value of the '{@link dominion.PlayersPlayArea#getBuysLeft <em>Buys Left</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Buys Left</em>' attribute.
	 * @see #getBuysLeft()
	 * @generated
	 */
	void setBuysLeft(int value);

} // PlayersPlayArea
