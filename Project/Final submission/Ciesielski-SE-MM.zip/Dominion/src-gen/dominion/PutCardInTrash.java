/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Put Card In Trash</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dominion.DominionPackage#getPutCardInTrash()
 * @model
 * @generated
 */
public interface PutCardInTrash extends Ability {
} // PutCardInTrash
