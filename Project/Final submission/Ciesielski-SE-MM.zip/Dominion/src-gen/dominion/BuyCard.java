/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Buy Card</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.BuyCard#getCard <em>Card</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getBuyCard()
 * @model
 * @generated
 */
public interface BuyCard extends PlayersAction {
	/**
	 * Returns the value of the '<em><b>Card</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Card</em>' reference.
	 * @see #setCard(Card)
	 * @see dominion.DominionPackage#getBuyCard_Card()
	 * @model required="true"
	 * @generated
	 */
	Card getCard();

	/**
	 * Sets the value of the '{@link dominion.BuyCard#getCard <em>Card</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Card</em>' reference.
	 * @see #getCard()
	 * @generated
	 */
	void setCard(Card value);

} // BuyCard
