/**
 */
package dominion;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Strategy</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.Strategy#getActionphase <em>Actionphase</em>}</li>
 *   <li>{@link dominion.Strategy#getBuyphase <em>Buyphase</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getStrategy()
 * @model
 * @generated
 */
public interface Strategy extends EObject {
	/**
	 * Returns the value of the '<em><b>Actionphase</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Actionphase</em>' containment reference.
	 * @see #setActionphase(ActionPhase)
	 * @see dominion.DominionPackage#getStrategy_Actionphase()
	 * @model containment="true"
	 * @generated
	 */
	ActionPhase getActionphase();

	/**
	 * Sets the value of the '{@link dominion.Strategy#getActionphase <em>Actionphase</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Actionphase</em>' containment reference.
	 * @see #getActionphase()
	 * @generated
	 */
	void setActionphase(ActionPhase value);

	/**
	 * Returns the value of the '<em><b>Buyphase</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Buyphase</em>' containment reference.
	 * @see #setBuyphase(BuyPhase)
	 * @see dominion.DominionPackage#getStrategy_Buyphase()
	 * @model containment="true" required="true"
	 * @generated
	 */
	BuyPhase getBuyphase();

	/**
	 * Sets the value of the '{@link dominion.Strategy#getBuyphase <em>Buyphase</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Buyphase</em>' containment reference.
	 * @see #getBuyphase()
	 * @generated
	 */
	void setBuyphase(BuyPhase value);

} // Strategy
