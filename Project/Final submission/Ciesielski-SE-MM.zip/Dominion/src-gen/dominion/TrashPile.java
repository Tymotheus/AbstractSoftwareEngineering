/**
 */
package dominion;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Trash Pile</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.TrashPile#getCards <em>Cards</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getTrashPile()
 * @model
 * @generated
 */
public interface TrashPile extends EObject {
	/**
	 * Returns the value of the '<em><b>Cards</b></em>' containment reference list.
	 * The list contents are of type {@link dominion.Card}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cards</em>' containment reference list.
	 * @see dominion.DominionPackage#getTrashPile_Cards()
	 * @model containment="true"
	 * @generated
	 */
	EList<Card> getCards();

} // TrashPile
