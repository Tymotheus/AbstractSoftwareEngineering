/**
 */
package dominion.impl;

import dominion.Ability;
import dominion.ActionCard;
import dominion.ActionPhase;
import dominion.BuyCard;
import dominion.BuyPhase;
import dominion.Card;
import dominion.CardLibrary;
import dominion.CardsPlayedThisTurn;
import dominion.CleanupPhase;
import dominion.DiscardPile;
import dominion.DominionFactory;
import dominion.DominionGame;
import dominion.DominionPackage;
import dominion.DominionProgram;
import dominion.DrawCards;
import dominion.EnoughCoins;
import dominion.Expression;
import dominion.ExtraActions;
import dominion.ExtraBuys;
import dominion.ExtraCoins;
import dominion.FittingCard;
import dominion.IfAction;
import dominion.PlayAction;
import dominion.PlayersAction;
import dominion.PlayersDeck;
import dominion.PlayersHand;
import dominion.PlayersPlayArea;
import dominion.PlayersTurn;
import dominion.PutCardFromHandToDiscard;
import dominion.PutCardFromPileToDiscard;
import dominion.PutCardInTrash;
import dominion.Strategy;
import dominion.SupplyPile;
import dominion.TrashPile;
import dominion.TreasureCard;
import dominion.VictoryCard;
import dominion.WhileAction;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DominionPackageImpl extends EPackageImpl implements DominionPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass playersDeckEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cardEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass treasureCardEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass victoryCardEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass playersHandEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cardLibraryEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass playersPlayAreaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cardsPlayedThisTurnEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass discardPileEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abilityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass putCardInTrashEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass drawCardsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass actionPhaseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass buyPhaseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cleanupPhaseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass playersTurnEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass buyCardEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass putCardFromPileToDiscardEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass extraBuysEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass extraCoinsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass extraActionsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dominionGameEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass putCardFromHandToDiscardEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass strategyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass playersActionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass playActionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ifActionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass expressionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass fittingCardEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass enoughCoinsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass whileActionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass actionCardEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass supplyPileEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass trashPileEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dominionProgramEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see dominion.DominionPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private DominionPackageImpl() {
		super(eNS_URI, DominionFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link DominionPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static DominionPackage init() {
		if (isInited)
			return (DominionPackage) EPackage.Registry.INSTANCE.getEPackage(DominionPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredDominionPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		DominionPackageImpl theDominionPackage = registeredDominionPackage instanceof DominionPackageImpl
				? (DominionPackageImpl) registeredDominionPackage
				: new DominionPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theDominionPackage.createPackageContents();

		// Initialize created meta-data
		theDominionPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theDominionPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(DominionPackage.eNS_URI, theDominionPackage);
		return theDominionPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPlayersDeck() {
		return playersDeckEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPlayersDeck_CardsNumber() {
		return (EAttribute) playersDeckEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlayersDeck_Cards() {
		return (EReference) playersDeckEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCard() {
		return cardEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCard_Cost() {
		return (EAttribute) cardEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCard_Name() {
		return (EAttribute) cardEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCard_IsPubliclyVisible() {
		return (EAttribute) cardEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCard_IsVisibleToOwner() {
		return (EAttribute) cardEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTreasureCard() {
		return treasureCardEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTreasureCard_Value() {
		return (EAttribute) treasureCardEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVictoryCard() {
		return victoryCardEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVictoryCard_VictoryPoints() {
		return (EAttribute) victoryCardEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPlayersHand() {
		return playersHandEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPlayersHand_CardsNumber() {
		return (EAttribute) playersHandEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlayersHand_Cards() {
		return (EReference) playersHandEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCardLibrary() {
		return cardLibraryEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCardLibrary_Card() {
		return (EReference) cardLibraryEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCardLibrary_Abilities() {
		return (EReference) cardLibraryEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPlayersPlayArea() {
		return playersPlayAreaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlayersPlayArea_Cards_played_this_turn() {
		return (EReference) playersPlayAreaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlayersPlayArea_Players_deck() {
		return (EReference) playersPlayAreaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlayersPlayArea_Players_hand() {
		return (EReference) playersPlayAreaEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlayersPlayArea_Discard_pile() {
		return (EReference) playersPlayAreaEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPlayersPlayArea_PlayersName() {
		return (EAttribute) playersPlayAreaEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPlayersPlayArea_ActionsLeft() {
		return (EAttribute) playersPlayAreaEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPlayersPlayArea_BuysLeft() {
		return (EAttribute) playersPlayAreaEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCardsPlayedThisTurn() {
		return cardsPlayedThisTurnEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCardsPlayedThisTurn_Cards() {
		return (EReference) cardsPlayedThisTurnEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCardsPlayedThisTurn_CardsNumber() {
		return (EAttribute) cardsPlayedThisTurnEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDiscardPile() {
		return discardPileEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDiscardPile_Cards() {
		return (EReference) discardPileEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDiscardPile_CardsNumber() {
		return (EAttribute) discardPileEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAbility() {
		return abilityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbility_Name() {
		return (EAttribute) abilityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPutCardInTrash() {
		return putCardInTrashEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDrawCards() {
		return drawCardsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getDrawCards_CardNumber() {
		return (EAttribute) drawCardsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getActionPhase() {
		return actionPhaseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getActionPhase_Playersactions() {
		return (EReference) actionPhaseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBuyPhase() {
		return buyPhaseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBuyPhase_Playersactions() {
		return (EReference) buyPhaseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCleanupPhase() {
		return cleanupPhaseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getCleanupPhase_Put_cards_from_hand_to_discard() {
		return (EReference) cleanupPhaseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPlayersTurn() {
		return playersTurnEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPlayersTurn_TurnNumber() {
		return (EAttribute) playersTurnEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlayersTurn_Player() {
		return (EReference) playersTurnEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlayersTurn_Players_hand() {
		return (EReference) playersTurnEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlayersTurn_Action_phase() {
		return (EReference) playersTurnEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlayersTurn_Buyphase() {
		return (EReference) playersTurnEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlayersTurn_Cleanupphase() {
		return (EReference) playersTurnEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBuyCard() {
		return buyCardEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBuyCard_Card() {
		return (EReference) buyCardEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPutCardFromPileToDiscard() {
		return putCardFromPileToDiscardEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPutCardFromPileToDiscard_Discard_pile() {
		return (EReference) putCardFromPileToDiscardEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getExtraBuys() {
		return extraBuysEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getExtraBuys_BuyNumber() {
		return (EAttribute) extraBuysEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getExtraCoins() {
		return extraCoinsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getExtraCoins_CoinNumber() {
		return (EAttribute) extraCoinsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getExtraActions() {
		return extraActionsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getExtraActions_ActionNumber() {
		return (EAttribute) extraActionsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDominionGame() {
		return dominionGameEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDominionGame_Playersplayarea() {
		return (EReference) dominionGameEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDominionGame_Players_turns() {
		return (EReference) dominionGameEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDominionGame_Avaialble_abilities() {
		return (EReference) dominionGameEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDominionGame_Trashpile() {
		return (EReference) dominionGameEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDominionGame_Supply_piles() {
		return (EReference) dominionGameEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getDominionGame__Print() {
		return dominionGameEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPutCardFromHandToDiscard() {
		return putCardFromHandToDiscardEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStrategy() {
		return strategyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStrategy_Actionphase() {
		return (EReference) strategyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStrategy_Buyphase() {
		return (EReference) strategyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPlayersAction() {
		return playersActionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPlayAction() {
		return playActionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPlayAction_Action_card() {
		return (EReference) playActionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getIfAction() {
		return ifActionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIfAction_Condition() {
		return (EReference) ifActionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getIfAction_Consequent_action() {
		return (EReference) ifActionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getExpression() {
		return expressionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFittingCard() {
		return fittingCardEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFittingCard_Card() {
		return (EReference) fittingCardEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEnoughCoins() {
		return enoughCoinsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEnoughCoins_CoinNumber() {
		return (EAttribute) enoughCoinsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getWhileAction() {
		return whileActionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWhileAction_Condition() {
		return (EReference) whileActionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getWhileAction_Playersaction() {
		return (EReference) whileActionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getActionCard() {
		return actionCardEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getActionCard_Ability() {
		return (EReference) actionCardEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSupplyPile() {
		return supplyPileEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSupplyPile_CardsNumber() {
		return (EAttribute) supplyPileEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getSupplyPile_Cards() {
		return (EReference) supplyPileEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTrashPile() {
		return trashPileEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTrashPile_Cards() {
		return (EReference) trashPileEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDominionProgram() {
		return dominionProgramEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDominionProgram_Dominiongame() {
		return (EReference) dominionProgramEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDominionProgram_Card_libraries() {
		return (EReference) dominionProgramEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDominionProgram_Strategies() {
		return (EReference) dominionProgramEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DominionFactory getDominionFactory() {
		return (DominionFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		playersDeckEClass = createEClass(PLAYERS_DECK);
		createEAttribute(playersDeckEClass, PLAYERS_DECK__CARDS_NUMBER);
		createEReference(playersDeckEClass, PLAYERS_DECK__CARDS);

		cardEClass = createEClass(CARD);
		createEAttribute(cardEClass, CARD__COST);
		createEAttribute(cardEClass, CARD__NAME);
		createEAttribute(cardEClass, CARD__IS_PUBLICLY_VISIBLE);
		createEAttribute(cardEClass, CARD__IS_VISIBLE_TO_OWNER);

		treasureCardEClass = createEClass(TREASURE_CARD);
		createEAttribute(treasureCardEClass, TREASURE_CARD__VALUE);

		victoryCardEClass = createEClass(VICTORY_CARD);
		createEAttribute(victoryCardEClass, VICTORY_CARD__VICTORY_POINTS);

		playersHandEClass = createEClass(PLAYERS_HAND);
		createEAttribute(playersHandEClass, PLAYERS_HAND__CARDS_NUMBER);
		createEReference(playersHandEClass, PLAYERS_HAND__CARDS);

		cardLibraryEClass = createEClass(CARD_LIBRARY);
		createEReference(cardLibraryEClass, CARD_LIBRARY__CARD);
		createEReference(cardLibraryEClass, CARD_LIBRARY__ABILITIES);

		playersPlayAreaEClass = createEClass(PLAYERS_PLAY_AREA);
		createEReference(playersPlayAreaEClass, PLAYERS_PLAY_AREA__CARDS_PLAYED_THIS_TURN);
		createEReference(playersPlayAreaEClass, PLAYERS_PLAY_AREA__PLAYERS_DECK);
		createEReference(playersPlayAreaEClass, PLAYERS_PLAY_AREA__PLAYERS_HAND);
		createEReference(playersPlayAreaEClass, PLAYERS_PLAY_AREA__DISCARD_PILE);
		createEAttribute(playersPlayAreaEClass, PLAYERS_PLAY_AREA__PLAYERS_NAME);
		createEAttribute(playersPlayAreaEClass, PLAYERS_PLAY_AREA__ACTIONS_LEFT);
		createEAttribute(playersPlayAreaEClass, PLAYERS_PLAY_AREA__BUYS_LEFT);

		cardsPlayedThisTurnEClass = createEClass(CARDS_PLAYED_THIS_TURN);
		createEReference(cardsPlayedThisTurnEClass, CARDS_PLAYED_THIS_TURN__CARDS);
		createEAttribute(cardsPlayedThisTurnEClass, CARDS_PLAYED_THIS_TURN__CARDS_NUMBER);

		discardPileEClass = createEClass(DISCARD_PILE);
		createEReference(discardPileEClass, DISCARD_PILE__CARDS);
		createEAttribute(discardPileEClass, DISCARD_PILE__CARDS_NUMBER);

		abilityEClass = createEClass(ABILITY);
		createEAttribute(abilityEClass, ABILITY__NAME);

		putCardInTrashEClass = createEClass(PUT_CARD_IN_TRASH);

		drawCardsEClass = createEClass(DRAW_CARDS);
		createEAttribute(drawCardsEClass, DRAW_CARDS__CARD_NUMBER);

		actionPhaseEClass = createEClass(ACTION_PHASE);
		createEReference(actionPhaseEClass, ACTION_PHASE__PLAYERSACTIONS);

		buyPhaseEClass = createEClass(BUY_PHASE);
		createEReference(buyPhaseEClass, BUY_PHASE__PLAYERSACTIONS);

		cleanupPhaseEClass = createEClass(CLEANUP_PHASE);
		createEReference(cleanupPhaseEClass, CLEANUP_PHASE__PUT_CARDS_FROM_HAND_TO_DISCARD);

		playersTurnEClass = createEClass(PLAYERS_TURN);
		createEAttribute(playersTurnEClass, PLAYERS_TURN__TURN_NUMBER);
		createEReference(playersTurnEClass, PLAYERS_TURN__PLAYER);
		createEReference(playersTurnEClass, PLAYERS_TURN__PLAYERS_HAND);
		createEReference(playersTurnEClass, PLAYERS_TURN__ACTION_PHASE);
		createEReference(playersTurnEClass, PLAYERS_TURN__BUYPHASE);
		createEReference(playersTurnEClass, PLAYERS_TURN__CLEANUPPHASE);

		buyCardEClass = createEClass(BUY_CARD);
		createEReference(buyCardEClass, BUY_CARD__CARD);

		putCardFromPileToDiscardEClass = createEClass(PUT_CARD_FROM_PILE_TO_DISCARD);
		createEReference(putCardFromPileToDiscardEClass, PUT_CARD_FROM_PILE_TO_DISCARD__DISCARD_PILE);

		extraBuysEClass = createEClass(EXTRA_BUYS);
		createEAttribute(extraBuysEClass, EXTRA_BUYS__BUY_NUMBER);

		extraCoinsEClass = createEClass(EXTRA_COINS);
		createEAttribute(extraCoinsEClass, EXTRA_COINS__COIN_NUMBER);

		extraActionsEClass = createEClass(EXTRA_ACTIONS);
		createEAttribute(extraActionsEClass, EXTRA_ACTIONS__ACTION_NUMBER);

		dominionGameEClass = createEClass(DOMINION_GAME);
		createEReference(dominionGameEClass, DOMINION_GAME__PLAYERSPLAYAREA);
		createEReference(dominionGameEClass, DOMINION_GAME__PLAYERS_TURNS);
		createEReference(dominionGameEClass, DOMINION_GAME__AVAIALBLE_ABILITIES);
		createEReference(dominionGameEClass, DOMINION_GAME__TRASHPILE);
		createEReference(dominionGameEClass, DOMINION_GAME__SUPPLY_PILES);
		createEOperation(dominionGameEClass, DOMINION_GAME___PRINT);

		putCardFromHandToDiscardEClass = createEClass(PUT_CARD_FROM_HAND_TO_DISCARD);

		strategyEClass = createEClass(STRATEGY);
		createEReference(strategyEClass, STRATEGY__ACTIONPHASE);
		createEReference(strategyEClass, STRATEGY__BUYPHASE);

		playersActionEClass = createEClass(PLAYERS_ACTION);

		playActionEClass = createEClass(PLAY_ACTION);
		createEReference(playActionEClass, PLAY_ACTION__ACTION_CARD);

		ifActionEClass = createEClass(IF_ACTION);
		createEReference(ifActionEClass, IF_ACTION__CONDITION);
		createEReference(ifActionEClass, IF_ACTION__CONSEQUENT_ACTION);

		expressionEClass = createEClass(EXPRESSION);

		fittingCardEClass = createEClass(FITTING_CARD);
		createEReference(fittingCardEClass, FITTING_CARD__CARD);

		enoughCoinsEClass = createEClass(ENOUGH_COINS);
		createEAttribute(enoughCoinsEClass, ENOUGH_COINS__COIN_NUMBER);

		whileActionEClass = createEClass(WHILE_ACTION);
		createEReference(whileActionEClass, WHILE_ACTION__CONDITION);
		createEReference(whileActionEClass, WHILE_ACTION__PLAYERSACTION);

		actionCardEClass = createEClass(ACTION_CARD);
		createEReference(actionCardEClass, ACTION_CARD__ABILITY);

		supplyPileEClass = createEClass(SUPPLY_PILE);
		createEAttribute(supplyPileEClass, SUPPLY_PILE__CARDS_NUMBER);
		createEReference(supplyPileEClass, SUPPLY_PILE__CARDS);

		trashPileEClass = createEClass(TRASH_PILE);
		createEReference(trashPileEClass, TRASH_PILE__CARDS);

		dominionProgramEClass = createEClass(DOMINION_PROGRAM);
		createEReference(dominionProgramEClass, DOMINION_PROGRAM__DOMINIONGAME);
		createEReference(dominionProgramEClass, DOMINION_PROGRAM__CARD_LIBRARIES);
		createEReference(dominionProgramEClass, DOMINION_PROGRAM__STRATEGIES);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		treasureCardEClass.getESuperTypes().add(this.getCard());
		victoryCardEClass.getESuperTypes().add(this.getCard());
		putCardInTrashEClass.getESuperTypes().add(this.getAbility());
		drawCardsEClass.getESuperTypes().add(this.getAbility());
		buyCardEClass.getESuperTypes().add(this.getPlayersAction());
		putCardFromPileToDiscardEClass.getESuperTypes().add(this.getAbility());
		extraBuysEClass.getESuperTypes().add(this.getAbility());
		extraCoinsEClass.getESuperTypes().add(this.getAbility());
		extraActionsEClass.getESuperTypes().add(this.getAbility());
		putCardFromHandToDiscardEClass.getESuperTypes().add(this.getAbility());
		playActionEClass.getESuperTypes().add(this.getPlayersAction());
		ifActionEClass.getESuperTypes().add(this.getPlayersAction());
		fittingCardEClass.getESuperTypes().add(this.getExpression());
		enoughCoinsEClass.getESuperTypes().add(this.getExpression());
		whileActionEClass.getESuperTypes().add(this.getPlayersAction());
		actionCardEClass.getESuperTypes().add(this.getCard());

		// Initialize classes, features, and operations; add parameters
		initEClass(playersDeckEClass, PlayersDeck.class, "PlayersDeck", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPlayersDeck_CardsNumber(), ecorePackage.getEInt(), "cardsNumber", null, 1, 1,
				PlayersDeck.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getPlayersDeck_Cards(), this.getCard(), null, "cards", null, 0, -1, PlayersDeck.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cardEClass, Card.class, "Card", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCard_Cost(), ecorePackage.getEInt(), "cost", null, 1, 1, Card.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCard_Name(), ecorePackage.getEString(), "name", null, 1, 1, Card.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCard_IsPubliclyVisible(), ecorePackage.getEBoolean(), "isPubliclyVisible", null, 0, 1,
				Card.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEAttribute(getCard_IsVisibleToOwner(), ecorePackage.getEBoolean(), "isVisibleToOwner", null, 0, 1,
				Card.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(treasureCardEClass, TreasureCard.class, "TreasureCard", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTreasureCard_Value(), ecorePackage.getEInt(), "value", null, 1, 1, TreasureCard.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(victoryCardEClass, VictoryCard.class, "VictoryCard", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVictoryCard_VictoryPoints(), ecorePackage.getEInt(), "victoryPoints", null, 1, 1,
				VictoryCard.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(playersHandEClass, PlayersHand.class, "PlayersHand", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPlayersHand_CardsNumber(), ecorePackage.getEInt(), "cardsNumber", null, 1, 1,
				PlayersHand.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getPlayersHand_Cards(), this.getCard(), null, "cards", null, 0, -1, PlayersHand.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cardLibraryEClass, CardLibrary.class, "CardLibrary", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCardLibrary_Card(), this.getCard(), null, "card", null, 0, -1, CardLibrary.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCardLibrary_Abilities(), this.getAbility(), null, "abilities", null, 0, -1, CardLibrary.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(playersPlayAreaEClass, PlayersPlayArea.class, "PlayersPlayArea", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPlayersPlayArea_Cards_played_this_turn(), this.getCardsPlayedThisTurn(), null,
				"cards_played_this_turn", null, 1, 1, PlayersPlayArea.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPlayersPlayArea_Players_deck(), this.getPlayersDeck(), null, "players_deck", null, 1, 1,
				PlayersPlayArea.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPlayersPlayArea_Players_hand(), this.getPlayersHand(), null, "players_hand", null, 1, 1,
				PlayersPlayArea.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPlayersPlayArea_Discard_pile(), this.getDiscardPile(), null, "discard_pile", null, 1, 1,
				PlayersPlayArea.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPlayersPlayArea_PlayersName(), ecorePackage.getEString(), "playersName", null, 0, 1,
				PlayersPlayArea.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPlayersPlayArea_ActionsLeft(), ecorePackage.getEInt(), "actionsLeft", null, 0, 1,
				PlayersPlayArea.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getPlayersPlayArea_BuysLeft(), ecorePackage.getEInt(), "buysLeft", null, 0, 1,
				PlayersPlayArea.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(cardsPlayedThisTurnEClass, CardsPlayedThisTurn.class, "CardsPlayedThisTurn", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCardsPlayedThisTurn_Cards(), this.getCard(), null, "cards", null, 0, -1,
				CardsPlayedThisTurn.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCardsPlayedThisTurn_CardsNumber(), ecorePackage.getEInt(), "cardsNumber", null, 1, 1,
				CardsPlayedThisTurn.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(discardPileEClass, DiscardPile.class, "DiscardPile", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDiscardPile_Cards(), this.getCard(), null, "cards", null, 0, -1, DiscardPile.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getDiscardPile_CardsNumber(), ecorePackage.getEInt(), "cardsNumber", null, 1, 1,
				DiscardPile.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(abilityEClass, Ability.class, "Ability", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAbility_Name(), ecorePackage.getEString(), "name", null, 0, 1, Ability.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(putCardInTrashEClass, PutCardInTrash.class, "PutCardInTrash", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(drawCardsEClass, DrawCards.class, "DrawCards", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDrawCards_CardNumber(), ecorePackage.getEInt(), "cardNumber", null, 1, 1, DrawCards.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(actionPhaseEClass, ActionPhase.class, "ActionPhase", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getActionPhase_Playersactions(), this.getPlayersAction(), null, "playersactions", null, 0, -1,
				ActionPhase.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(buyPhaseEClass, BuyPhase.class, "BuyPhase", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBuyPhase_Playersactions(), this.getPlayersAction(), null, "playersactions", null, 0, -1,
				BuyPhase.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cleanupPhaseEClass, CleanupPhase.class, "CleanupPhase", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCleanupPhase_Put_cards_from_hand_to_discard(), this.getPutCardFromHandToDiscard(), null,
				"put_cards_from_hand_to_discard", null, 0, -1, CleanupPhase.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(playersTurnEClass, PlayersTurn.class, "PlayersTurn", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPlayersTurn_TurnNumber(), ecorePackage.getEInt(), "turnNumber", null, 0, 1, PlayersTurn.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPlayersTurn_Player(), this.getPlayersPlayArea(), null, "player", null, 1, 1,
				PlayersTurn.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPlayersTurn_Players_hand(), this.getPlayersHand(), null, "players_hand", null, 1, 1,
				PlayersTurn.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPlayersTurn_Action_phase(), this.getActionPhase(), null, "action_phase", null, 1, 1,
				PlayersTurn.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPlayersTurn_Buyphase(), this.getBuyPhase(), null, "buyphase", null, 1, 1, PlayersTurn.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPlayersTurn_Cleanupphase(), this.getCleanupPhase(), null, "cleanupphase", null, 1, 1,
				PlayersTurn.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(buyCardEClass, BuyCard.class, "BuyCard", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBuyCard_Card(), this.getCard(), null, "card", null, 1, 1, BuyCard.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(putCardFromPileToDiscardEClass, PutCardFromPileToDiscard.class, "PutCardFromPileToDiscard",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPutCardFromPileToDiscard_Discard_pile(), this.getDiscardPile(), null, "discard_pile", null, 1,
				1, PutCardFromPileToDiscard.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(extraBuysEClass, ExtraBuys.class, "ExtraBuys", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getExtraBuys_BuyNumber(), ecorePackage.getEInt(), "buyNumber", null, 1, 1, ExtraBuys.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(extraCoinsEClass, ExtraCoins.class, "ExtraCoins", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getExtraCoins_CoinNumber(), ecorePackage.getEInt(), "coinNumber", null, 1, 1, ExtraCoins.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(extraActionsEClass, ExtraActions.class, "ExtraActions", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getExtraActions_ActionNumber(), ecorePackage.getEInt(), "actionNumber", null, 1, 1,
				ExtraActions.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(dominionGameEClass, DominionGame.class, "DominionGame", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDominionGame_Playersplayarea(), this.getPlayersPlayArea(), null, "playersplayarea", null, 0,
				4, DominionGame.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDominionGame_Players_turns(), this.getPlayersTurn(), null, "players_turns", null, 0, -1,
				DominionGame.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDominionGame_Avaialble_abilities(), this.getAbility(), null, "avaialble_abilities", null, 0,
				-1, DominionGame.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDominionGame_Trashpile(), this.getTrashPile(), null, "trashpile", null, 0, 1,
				DominionGame.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDominionGame_Supply_piles(), this.getSupplyPile(), null, "supply_piles", null, 0, -1,
				DominionGame.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getDominionGame__Print(), null, "print", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(putCardFromHandToDiscardEClass, PutCardFromHandToDiscard.class, "PutCardFromHandToDiscard",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(strategyEClass, Strategy.class, "Strategy", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getStrategy_Actionphase(), this.getActionPhase(), null, "actionphase", null, 0, 1,
				Strategy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getStrategy_Buyphase(), this.getBuyPhase(), null, "buyphase", null, 1, 1, Strategy.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(playersActionEClass, PlayersAction.class, "PlayersAction", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(playActionEClass, PlayAction.class, "PlayAction", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPlayAction_Action_card(), this.getCard(), null, "action_card", null, 1, 1, PlayAction.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ifActionEClass, IfAction.class, "IfAction", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getIfAction_Condition(), this.getExpression(), null, "condition", null, 1, 1, IfAction.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getIfAction_Consequent_action(), this.getPlayersAction(), null, "consequent_action", null, 1, 1,
				IfAction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(expressionEClass, Expression.class, "Expression", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(fittingCardEClass, FittingCard.class, "FittingCard", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFittingCard_Card(), this.getCard(), null, "card", null, 1, 1, FittingCard.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(enoughCoinsEClass, EnoughCoins.class, "EnoughCoins", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getEnoughCoins_CoinNumber(), ecorePackage.getEInt(), "coinNumber", null, 1, 1, EnoughCoins.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(whileActionEClass, WhileAction.class, "WhileAction", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getWhileAction_Condition(), this.getExpression(), null, "condition", null, 1, 1,
				WhileAction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getWhileAction_Playersaction(), this.getPlayersAction(), null, "playersaction", null, 1, 1,
				WhileAction.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(actionCardEClass, ActionCard.class, "ActionCard", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getActionCard_Ability(), this.getAbility(), null, "ability", null, 1, -1, ActionCard.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(supplyPileEClass, SupplyPile.class, "SupplyPile", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSupplyPile_CardsNumber(), ecorePackage.getEInt(), "cardsNumber", null, 1, 1, SupplyPile.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getSupplyPile_Cards(), this.getCard(), null, "cards", null, 0, -1, SupplyPile.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(trashPileEClass, TrashPile.class, "TrashPile", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTrashPile_Cards(), this.getCard(), null, "cards", null, 0, -1, TrashPile.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(dominionProgramEClass, DominionProgram.class, "DominionProgram", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDominionProgram_Dominiongame(), this.getDominionGame(), null, "dominiongame", null, 0, 1,
				DominionProgram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDominionProgram_Card_libraries(), this.getCardLibrary(), null, "card_libraries", null, 0, -1,
				DominionProgram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDominionProgram_Strategies(), this.getStrategy(), null, "strategies", null, 0, -1,
				DominionProgram.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //DominionPackageImpl
