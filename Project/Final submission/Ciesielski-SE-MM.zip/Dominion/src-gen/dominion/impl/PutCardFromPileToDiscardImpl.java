/**
 */
package dominion.impl;

import dominion.DiscardPile;
import dominion.DominionPackage;
import dominion.PutCardFromPileToDiscard;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Put Card From Pile To Discard</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.PutCardFromPileToDiscardImpl#getDiscard_pile <em>Discard pile</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PutCardFromPileToDiscardImpl extends AbilityImpl implements PutCardFromPileToDiscard {
	/**
	 * The cached value of the '{@link #getDiscard_pile() <em>Discard pile</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDiscard_pile()
	 * @generated
	 * @ordered
	 */
	protected DiscardPile discard_pile;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PutCardFromPileToDiscardImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.PUT_CARD_FROM_PILE_TO_DISCARD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiscardPile getDiscard_pile() {
		if (discard_pile != null && discard_pile.eIsProxy()) {
			InternalEObject oldDiscard_pile = (InternalEObject) discard_pile;
			discard_pile = (DiscardPile) eResolveProxy(oldDiscard_pile);
			if (discard_pile != oldDiscard_pile) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							DominionPackage.PUT_CARD_FROM_PILE_TO_DISCARD__DISCARD_PILE, oldDiscard_pile,
							discard_pile));
			}
		}
		return discard_pile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiscardPile basicGetDiscard_pile() {
		return discard_pile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDiscard_pile(DiscardPile newDiscard_pile) {
		DiscardPile oldDiscard_pile = discard_pile;
		discard_pile = newDiscard_pile;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					DominionPackage.PUT_CARD_FROM_PILE_TO_DISCARD__DISCARD_PILE, oldDiscard_pile, discard_pile));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.PUT_CARD_FROM_PILE_TO_DISCARD__DISCARD_PILE:
			if (resolve)
				return getDiscard_pile();
			return basicGetDiscard_pile();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.PUT_CARD_FROM_PILE_TO_DISCARD__DISCARD_PILE:
			setDiscard_pile((DiscardPile) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.PUT_CARD_FROM_PILE_TO_DISCARD__DISCARD_PILE:
			setDiscard_pile((DiscardPile) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.PUT_CARD_FROM_PILE_TO_DISCARD__DISCARD_PILE:
			return discard_pile != null;
		}
		return super.eIsSet(featureID);
	}

} //PutCardFromPileToDiscardImpl
