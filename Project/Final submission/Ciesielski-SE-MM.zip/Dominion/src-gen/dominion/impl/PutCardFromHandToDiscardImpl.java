/**
 */
package dominion.impl;

import dominion.DominionPackage;
import dominion.PutCardFromHandToDiscard;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Put Card From Hand To Discard</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PutCardFromHandToDiscardImpl extends AbilityImpl implements PutCardFromHandToDiscard {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PutCardFromHandToDiscardImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.PUT_CARD_FROM_HAND_TO_DISCARD;
	}

} //PutCardFromHandToDiscardImpl
