/**
 */
package dominion.impl;

import dominion.DominionPackage;
import dominion.Expression;
import dominion.PlayersAction;
import dominion.WhileAction;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>While Action</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.WhileActionImpl#getCondition <em>Condition</em>}</li>
 *   <li>{@link dominion.impl.WhileActionImpl#getPlayersaction <em>Playersaction</em>}</li>
 * </ul>
 *
 * @generated
 */
public class WhileActionImpl extends PlayersActionImpl implements WhileAction {
	/**
	 * The cached value of the '{@link #getCondition() <em>Condition</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCondition()
	 * @generated
	 * @ordered
	 */
	protected Expression condition;

	/**
	 * The cached value of the '{@link #getPlayersaction() <em>Playersaction</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlayersaction()
	 * @generated
	 * @ordered
	 */
	protected PlayersAction playersaction;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected WhileActionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.WHILE_ACTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Expression getCondition() {
		return condition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCondition(Expression newCondition, NotificationChain msgs) {
		Expression oldCondition = condition;
		condition = newCondition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.WHILE_ACTION__CONDITION, oldCondition, newCondition);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCondition(Expression newCondition) {
		if (newCondition != condition) {
			NotificationChain msgs = null;
			if (condition != null)
				msgs = ((InternalEObject) condition).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.WHILE_ACTION__CONDITION, null, msgs);
			if (newCondition != null)
				msgs = ((InternalEObject) newCondition).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.WHILE_ACTION__CONDITION, null, msgs);
			msgs = basicSetCondition(newCondition, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.WHILE_ACTION__CONDITION, newCondition,
					newCondition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlayersAction getPlayersaction() {
		return playersaction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPlayersaction(PlayersAction newPlayersaction, NotificationChain msgs) {
		PlayersAction oldPlayersaction = playersaction;
		playersaction = newPlayersaction;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.WHILE_ACTION__PLAYERSACTION, oldPlayersaction, newPlayersaction);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlayersaction(PlayersAction newPlayersaction) {
		if (newPlayersaction != playersaction) {
			NotificationChain msgs = null;
			if (playersaction != null)
				msgs = ((InternalEObject) playersaction).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.WHILE_ACTION__PLAYERSACTION, null, msgs);
			if (newPlayersaction != null)
				msgs = ((InternalEObject) newPlayersaction).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.WHILE_ACTION__PLAYERSACTION, null, msgs);
			msgs = basicSetPlayersaction(newPlayersaction, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.WHILE_ACTION__PLAYERSACTION,
					newPlayersaction, newPlayersaction));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DominionPackage.WHILE_ACTION__CONDITION:
			return basicSetCondition(null, msgs);
		case DominionPackage.WHILE_ACTION__PLAYERSACTION:
			return basicSetPlayersaction(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.WHILE_ACTION__CONDITION:
			return getCondition();
		case DominionPackage.WHILE_ACTION__PLAYERSACTION:
			return getPlayersaction();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.WHILE_ACTION__CONDITION:
			setCondition((Expression) newValue);
			return;
		case DominionPackage.WHILE_ACTION__PLAYERSACTION:
			setPlayersaction((PlayersAction) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.WHILE_ACTION__CONDITION:
			setCondition((Expression) null);
			return;
		case DominionPackage.WHILE_ACTION__PLAYERSACTION:
			setPlayersaction((PlayersAction) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.WHILE_ACTION__CONDITION:
			return condition != null;
		case DominionPackage.WHILE_ACTION__PLAYERSACTION:
			return playersaction != null;
		}
		return super.eIsSet(featureID);
	}

} //WhileActionImpl
