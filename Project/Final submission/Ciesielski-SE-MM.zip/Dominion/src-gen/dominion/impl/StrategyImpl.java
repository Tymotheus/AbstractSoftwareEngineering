/**
 */
package dominion.impl;

import dominion.ActionPhase;
import dominion.BuyPhase;
import dominion.DominionPackage;
import dominion.Strategy;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Strategy</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.StrategyImpl#getActionphase <em>Actionphase</em>}</li>
 *   <li>{@link dominion.impl.StrategyImpl#getBuyphase <em>Buyphase</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StrategyImpl extends MinimalEObjectImpl.Container implements Strategy {
	/**
	 * The cached value of the '{@link #getActionphase() <em>Actionphase</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActionphase()
	 * @generated
	 * @ordered
	 */
	protected ActionPhase actionphase;

	/**
	 * The cached value of the '{@link #getBuyphase() <em>Buyphase</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuyphase()
	 * @generated
	 * @ordered
	 */
	protected BuyPhase buyphase;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StrategyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.STRATEGY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ActionPhase getActionphase() {
		return actionphase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetActionphase(ActionPhase newActionphase, NotificationChain msgs) {
		ActionPhase oldActionphase = actionphase;
		actionphase = newActionphase;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.STRATEGY__ACTIONPHASE, oldActionphase, newActionphase);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setActionphase(ActionPhase newActionphase) {
		if (newActionphase != actionphase) {
			NotificationChain msgs = null;
			if (actionphase != null)
				msgs = ((InternalEObject) actionphase).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.STRATEGY__ACTIONPHASE, null, msgs);
			if (newActionphase != null)
				msgs = ((InternalEObject) newActionphase).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.STRATEGY__ACTIONPHASE, null, msgs);
			msgs = basicSetActionphase(newActionphase, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.STRATEGY__ACTIONPHASE, newActionphase,
					newActionphase));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BuyPhase getBuyphase() {
		return buyphase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetBuyphase(BuyPhase newBuyphase, NotificationChain msgs) {
		BuyPhase oldBuyphase = buyphase;
		buyphase = newBuyphase;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.STRATEGY__BUYPHASE, oldBuyphase, newBuyphase);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBuyphase(BuyPhase newBuyphase) {
		if (newBuyphase != buyphase) {
			NotificationChain msgs = null;
			if (buyphase != null)
				msgs = ((InternalEObject) buyphase).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.STRATEGY__BUYPHASE, null, msgs);
			if (newBuyphase != null)
				msgs = ((InternalEObject) newBuyphase).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.STRATEGY__BUYPHASE, null, msgs);
			msgs = basicSetBuyphase(newBuyphase, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.STRATEGY__BUYPHASE, newBuyphase,
					newBuyphase));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DominionPackage.STRATEGY__ACTIONPHASE:
			return basicSetActionphase(null, msgs);
		case DominionPackage.STRATEGY__BUYPHASE:
			return basicSetBuyphase(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.STRATEGY__ACTIONPHASE:
			return getActionphase();
		case DominionPackage.STRATEGY__BUYPHASE:
			return getBuyphase();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.STRATEGY__ACTIONPHASE:
			setActionphase((ActionPhase) newValue);
			return;
		case DominionPackage.STRATEGY__BUYPHASE:
			setBuyphase((BuyPhase) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.STRATEGY__ACTIONPHASE:
			setActionphase((ActionPhase) null);
			return;
		case DominionPackage.STRATEGY__BUYPHASE:
			setBuyphase((BuyPhase) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.STRATEGY__ACTIONPHASE:
			return actionphase != null;
		case DominionPackage.STRATEGY__BUYPHASE:
			return buyphase != null;
		}
		return super.eIsSet(featureID);
	}

} //StrategyImpl
