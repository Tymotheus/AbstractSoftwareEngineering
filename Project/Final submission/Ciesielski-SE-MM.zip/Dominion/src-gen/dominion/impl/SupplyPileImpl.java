/**
 */
package dominion.impl;

import dominion.Card;
import dominion.DominionPackage;
import dominion.SupplyPile;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Supply Pile</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.SupplyPileImpl#getCardsNumber <em>Cards Number</em>}</li>
 *   <li>{@link dominion.impl.SupplyPileImpl#getCards <em>Cards</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SupplyPileImpl extends MinimalEObjectImpl.Container implements SupplyPile {
	/**
	 * The default value of the '{@link #getCardsNumber() <em>Cards Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCardsNumber()
	 * @generated
	 * @ordered
	 */
	protected static final int CARDS_NUMBER_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCardsNumber() <em>Cards Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCardsNumber()
	 * @generated
	 * @ordered
	 */
	protected int cardsNumber = CARDS_NUMBER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCards() <em>Cards</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCards()
	 * @generated
	 * @ordered
	 */
	protected EList<Card> cards;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SupplyPileImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.SUPPLY_PILE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getCardsNumber() {
		return cardsNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCardsNumber(int newCardsNumber) {
		int oldCardsNumber = cardsNumber;
		cardsNumber = newCardsNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.SUPPLY_PILE__CARDS_NUMBER,
					oldCardsNumber, cardsNumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Card> getCards() {
		if (cards == null) {
			cards = new EObjectContainmentEList<Card>(Card.class, this, DominionPackage.SUPPLY_PILE__CARDS);
		}
		return cards;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DominionPackage.SUPPLY_PILE__CARDS:
			return ((InternalEList<?>) getCards()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.SUPPLY_PILE__CARDS_NUMBER:
			return getCardsNumber();
		case DominionPackage.SUPPLY_PILE__CARDS:
			return getCards();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.SUPPLY_PILE__CARDS_NUMBER:
			setCardsNumber((Integer) newValue);
			return;
		case DominionPackage.SUPPLY_PILE__CARDS:
			getCards().clear();
			getCards().addAll((Collection<? extends Card>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.SUPPLY_PILE__CARDS_NUMBER:
			setCardsNumber(CARDS_NUMBER_EDEFAULT);
			return;
		case DominionPackage.SUPPLY_PILE__CARDS:
			getCards().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.SUPPLY_PILE__CARDS_NUMBER:
			return cardsNumber != CARDS_NUMBER_EDEFAULT;
		case DominionPackage.SUPPLY_PILE__CARDS:
			return cards != null && !cards.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (cardsNumber: ");
		result.append(cardsNumber);
		result.append(')');
		return result.toString();
	}

} //SupplyPileImpl
