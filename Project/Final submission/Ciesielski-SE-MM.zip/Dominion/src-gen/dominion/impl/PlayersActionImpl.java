/**
 */
package dominion.impl;

import dominion.DominionPackage;
import dominion.PlayersAction;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Players Action</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class PlayersActionImpl extends MinimalEObjectImpl.Container implements PlayersAction {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PlayersActionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.PLAYERS_ACTION;
	}

} //PlayersActionImpl
