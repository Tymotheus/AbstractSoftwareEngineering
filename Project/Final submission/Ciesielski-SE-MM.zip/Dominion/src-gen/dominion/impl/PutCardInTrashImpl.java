/**
 */
package dominion.impl;

import dominion.DominionPackage;
import dominion.PutCardInTrash;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Put Card In Trash</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PutCardInTrashImpl extends AbilityImpl implements PutCardInTrash {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PutCardInTrashImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.PUT_CARD_IN_TRASH;
	}

} //PutCardInTrashImpl
