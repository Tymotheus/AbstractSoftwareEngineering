/**
 */
package dominion.impl;

import dominion.Card;
import dominion.DominionPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Card</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.CardImpl#getCost <em>Cost</em>}</li>
 *   <li>{@link dominion.impl.CardImpl#getName <em>Name</em>}</li>
 *   <li>{@link dominion.impl.CardImpl#isIsPubliclyVisible <em>Is Publicly Visible</em>}</li>
 *   <li>{@link dominion.impl.CardImpl#isIsVisibleToOwner <em>Is Visible To Owner</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class CardImpl extends MinimalEObjectImpl.Container implements Card {
	/**
	 * The default value of the '{@link #getCost() <em>Cost</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCost()
	 * @generated
	 * @ordered
	 */
	protected static final int COST_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getCost() <em>Cost</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCost()
	 * @generated
	 * @ordered
	 */
	protected int cost = COST_EDEFAULT;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsPubliclyVisible() <em>Is Publicly Visible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsPubliclyVisible()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_PUBLICLY_VISIBLE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsPubliclyVisible() <em>Is Publicly Visible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsPubliclyVisible()
	 * @generated
	 * @ordered
	 */
	protected boolean isPubliclyVisible = IS_PUBLICLY_VISIBLE_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsVisibleToOwner() <em>Is Visible To Owner</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsVisibleToOwner()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_VISIBLE_TO_OWNER_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsVisibleToOwner() <em>Is Visible To Owner</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsVisibleToOwner()
	 * @generated
	 * @ordered
	 */
	protected boolean isVisibleToOwner = IS_VISIBLE_TO_OWNER_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CardImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.CARD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getCost() {
		return cost;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCost(int newCost) {
		int oldCost = cost;
		cost = newCost;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.CARD__COST, oldCost, cost));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.CARD__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIsPubliclyVisible() {
		return isPubliclyVisible;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsPubliclyVisible(boolean newIsPubliclyVisible) {
		boolean oldIsPubliclyVisible = isPubliclyVisible;
		isPubliclyVisible = newIsPubliclyVisible;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.CARD__IS_PUBLICLY_VISIBLE,
					oldIsPubliclyVisible, isPubliclyVisible));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isIsVisibleToOwner() {
		return isVisibleToOwner;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIsVisibleToOwner(boolean newIsVisibleToOwner) {
		boolean oldIsVisibleToOwner = isVisibleToOwner;
		isVisibleToOwner = newIsVisibleToOwner;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.CARD__IS_VISIBLE_TO_OWNER,
					oldIsVisibleToOwner, isVisibleToOwner));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.CARD__COST:
			return getCost();
		case DominionPackage.CARD__NAME:
			return getName();
		case DominionPackage.CARD__IS_PUBLICLY_VISIBLE:
			return isIsPubliclyVisible();
		case DominionPackage.CARD__IS_VISIBLE_TO_OWNER:
			return isIsVisibleToOwner();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.CARD__COST:
			setCost((Integer) newValue);
			return;
		case DominionPackage.CARD__NAME:
			setName((String) newValue);
			return;
		case DominionPackage.CARD__IS_PUBLICLY_VISIBLE:
			setIsPubliclyVisible((Boolean) newValue);
			return;
		case DominionPackage.CARD__IS_VISIBLE_TO_OWNER:
			setIsVisibleToOwner((Boolean) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.CARD__COST:
			setCost(COST_EDEFAULT);
			return;
		case DominionPackage.CARD__NAME:
			setName(NAME_EDEFAULT);
			return;
		case DominionPackage.CARD__IS_PUBLICLY_VISIBLE:
			setIsPubliclyVisible(IS_PUBLICLY_VISIBLE_EDEFAULT);
			return;
		case DominionPackage.CARD__IS_VISIBLE_TO_OWNER:
			setIsVisibleToOwner(IS_VISIBLE_TO_OWNER_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.CARD__COST:
			return cost != COST_EDEFAULT;
		case DominionPackage.CARD__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case DominionPackage.CARD__IS_PUBLICLY_VISIBLE:
			return isPubliclyVisible != IS_PUBLICLY_VISIBLE_EDEFAULT;
		case DominionPackage.CARD__IS_VISIBLE_TO_OWNER:
			return isVisibleToOwner != IS_VISIBLE_TO_OWNER_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (cost: ");
		result.append(cost);
		result.append(", name: ");
		result.append(name);
		result.append(", isPubliclyVisible: ");
		result.append(isPubliclyVisible);
		result.append(", isVisibleToOwner: ");
		result.append(isVisibleToOwner);
		result.append(')');
		return result.toString();
	}

} //CardImpl
