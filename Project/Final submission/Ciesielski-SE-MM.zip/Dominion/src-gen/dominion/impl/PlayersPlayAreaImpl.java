/**
 */
package dominion.impl;

import dominion.CardsPlayedThisTurn;
import dominion.DiscardPile;
import dominion.DominionPackage;
import dominion.PlayersDeck;
import dominion.PlayersHand;
import dominion.PlayersPlayArea;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Players Play Area</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.PlayersPlayAreaImpl#getCards_played_this_turn <em>Cards played this turn</em>}</li>
 *   <li>{@link dominion.impl.PlayersPlayAreaImpl#getPlayers_deck <em>Players deck</em>}</li>
 *   <li>{@link dominion.impl.PlayersPlayAreaImpl#getPlayers_hand <em>Players hand</em>}</li>
 *   <li>{@link dominion.impl.PlayersPlayAreaImpl#getDiscard_pile <em>Discard pile</em>}</li>
 *   <li>{@link dominion.impl.PlayersPlayAreaImpl#getPlayersName <em>Players Name</em>}</li>
 *   <li>{@link dominion.impl.PlayersPlayAreaImpl#getActionsLeft <em>Actions Left</em>}</li>
 *   <li>{@link dominion.impl.PlayersPlayAreaImpl#getBuysLeft <em>Buys Left</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PlayersPlayAreaImpl extends MinimalEObjectImpl.Container implements PlayersPlayArea {
	/**
	 * The cached value of the '{@link #getCards_played_this_turn() <em>Cards played this turn</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCards_played_this_turn()
	 * @generated
	 * @ordered
	 */
	protected CardsPlayedThisTurn cards_played_this_turn;

	/**
	 * The cached value of the '{@link #getPlayers_deck() <em>Players deck</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlayers_deck()
	 * @generated
	 * @ordered
	 */
	protected PlayersDeck players_deck;

	/**
	 * The cached value of the '{@link #getPlayers_hand() <em>Players hand</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlayers_hand()
	 * @generated
	 * @ordered
	 */
	protected PlayersHand players_hand;

	/**
	 * The cached value of the '{@link #getDiscard_pile() <em>Discard pile</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDiscard_pile()
	 * @generated
	 * @ordered
	 */
	protected DiscardPile discard_pile;

	/**
	 * The default value of the '{@link #getPlayersName() <em>Players Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlayersName()
	 * @generated
	 * @ordered
	 */
	protected static final String PLAYERS_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPlayersName() <em>Players Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlayersName()
	 * @generated
	 * @ordered
	 */
	protected String playersName = PLAYERS_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getActionsLeft() <em>Actions Left</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActionsLeft()
	 * @generated
	 * @ordered
	 */
	protected static final int ACTIONS_LEFT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getActionsLeft() <em>Actions Left</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActionsLeft()
	 * @generated
	 * @ordered
	 */
	protected int actionsLeft = ACTIONS_LEFT_EDEFAULT;

	/**
	 * The default value of the '{@link #getBuysLeft() <em>Buys Left</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuysLeft()
	 * @generated
	 * @ordered
	 */
	protected static final int BUYS_LEFT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getBuysLeft() <em>Buys Left</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuysLeft()
	 * @generated
	 * @ordered
	 */
	protected int buysLeft = BUYS_LEFT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PlayersPlayAreaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.PLAYERS_PLAY_AREA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CardsPlayedThisTurn getCards_played_this_turn() {
		return cards_played_this_turn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCards_played_this_turn(CardsPlayedThisTurn newCards_played_this_turn,
			NotificationChain msgs) {
		CardsPlayedThisTurn oldCards_played_this_turn = cards_played_this_turn;
		cards_played_this_turn = newCards_played_this_turn;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.PLAYERS_PLAY_AREA__CARDS_PLAYED_THIS_TURN, oldCards_played_this_turn,
					newCards_played_this_turn);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCards_played_this_turn(CardsPlayedThisTurn newCards_played_this_turn) {
		if (newCards_played_this_turn != cards_played_this_turn) {
			NotificationChain msgs = null;
			if (cards_played_this_turn != null)
				msgs = ((InternalEObject) cards_played_this_turn).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_PLAY_AREA__CARDS_PLAYED_THIS_TURN, null, msgs);
			if (newCards_played_this_turn != null)
				msgs = ((InternalEObject) newCards_played_this_turn).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_PLAY_AREA__CARDS_PLAYED_THIS_TURN, null, msgs);
			msgs = basicSetCards_played_this_turn(newCards_played_this_turn, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					DominionPackage.PLAYERS_PLAY_AREA__CARDS_PLAYED_THIS_TURN, newCards_played_this_turn,
					newCards_played_this_turn));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlayersDeck getPlayers_deck() {
		return players_deck;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPlayers_deck(PlayersDeck newPlayers_deck, NotificationChain msgs) {
		PlayersDeck oldPlayers_deck = players_deck;
		players_deck = newPlayers_deck;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_DECK, oldPlayers_deck, newPlayers_deck);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlayers_deck(PlayersDeck newPlayers_deck) {
		if (newPlayers_deck != players_deck) {
			NotificationChain msgs = null;
			if (players_deck != null)
				msgs = ((InternalEObject) players_deck).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_DECK, null, msgs);
			if (newPlayers_deck != null)
				msgs = ((InternalEObject) newPlayers_deck).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_DECK, null, msgs);
			msgs = basicSetPlayers_deck(newPlayers_deck, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_DECK,
					newPlayers_deck, newPlayers_deck));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlayersHand getPlayers_hand() {
		return players_hand;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetPlayers_hand(PlayersHand newPlayers_hand, NotificationChain msgs) {
		PlayersHand oldPlayers_hand = players_hand;
		players_hand = newPlayers_hand;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_HAND, oldPlayers_hand, newPlayers_hand);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlayers_hand(PlayersHand newPlayers_hand) {
		if (newPlayers_hand != players_hand) {
			NotificationChain msgs = null;
			if (players_hand != null)
				msgs = ((InternalEObject) players_hand).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_HAND, null, msgs);
			if (newPlayers_hand != null)
				msgs = ((InternalEObject) newPlayers_hand).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_HAND, null, msgs);
			msgs = basicSetPlayers_hand(newPlayers_hand, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_HAND,
					newPlayers_hand, newPlayers_hand));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiscardPile getDiscard_pile() {
		return discard_pile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDiscard_pile(DiscardPile newDiscard_pile, NotificationChain msgs) {
		DiscardPile oldDiscard_pile = discard_pile;
		discard_pile = newDiscard_pile;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.PLAYERS_PLAY_AREA__DISCARD_PILE, oldDiscard_pile, newDiscard_pile);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDiscard_pile(DiscardPile newDiscard_pile) {
		if (newDiscard_pile != discard_pile) {
			NotificationChain msgs = null;
			if (discard_pile != null)
				msgs = ((InternalEObject) discard_pile).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_PLAY_AREA__DISCARD_PILE, null, msgs);
			if (newDiscard_pile != null)
				msgs = ((InternalEObject) newDiscard_pile).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_PLAY_AREA__DISCARD_PILE, null, msgs);
			msgs = basicSetDiscard_pile(newDiscard_pile, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.PLAYERS_PLAY_AREA__DISCARD_PILE,
					newDiscard_pile, newDiscard_pile));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPlayersName() {
		return playersName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlayersName(String newPlayersName) {
		String oldPlayersName = playersName;
		playersName = newPlayersName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_NAME,
					oldPlayersName, playersName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getActionsLeft() {
		return actionsLeft;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setActionsLeft(int newActionsLeft) {
		int oldActionsLeft = actionsLeft;
		actionsLeft = newActionsLeft;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.PLAYERS_PLAY_AREA__ACTIONS_LEFT,
					oldActionsLeft, actionsLeft));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getBuysLeft() {
		return buysLeft;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBuysLeft(int newBuysLeft) {
		int oldBuysLeft = buysLeft;
		buysLeft = newBuysLeft;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.PLAYERS_PLAY_AREA__BUYS_LEFT,
					oldBuysLeft, buysLeft));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DominionPackage.PLAYERS_PLAY_AREA__CARDS_PLAYED_THIS_TURN:
			return basicSetCards_played_this_turn(null, msgs);
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_DECK:
			return basicSetPlayers_deck(null, msgs);
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_HAND:
			return basicSetPlayers_hand(null, msgs);
		case DominionPackage.PLAYERS_PLAY_AREA__DISCARD_PILE:
			return basicSetDiscard_pile(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.PLAYERS_PLAY_AREA__CARDS_PLAYED_THIS_TURN:
			return getCards_played_this_turn();
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_DECK:
			return getPlayers_deck();
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_HAND:
			return getPlayers_hand();
		case DominionPackage.PLAYERS_PLAY_AREA__DISCARD_PILE:
			return getDiscard_pile();
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_NAME:
			return getPlayersName();
		case DominionPackage.PLAYERS_PLAY_AREA__ACTIONS_LEFT:
			return getActionsLeft();
		case DominionPackage.PLAYERS_PLAY_AREA__BUYS_LEFT:
			return getBuysLeft();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.PLAYERS_PLAY_AREA__CARDS_PLAYED_THIS_TURN:
			setCards_played_this_turn((CardsPlayedThisTurn) newValue);
			return;
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_DECK:
			setPlayers_deck((PlayersDeck) newValue);
			return;
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_HAND:
			setPlayers_hand((PlayersHand) newValue);
			return;
		case DominionPackage.PLAYERS_PLAY_AREA__DISCARD_PILE:
			setDiscard_pile((DiscardPile) newValue);
			return;
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_NAME:
			setPlayersName((String) newValue);
			return;
		case DominionPackage.PLAYERS_PLAY_AREA__ACTIONS_LEFT:
			setActionsLeft((Integer) newValue);
			return;
		case DominionPackage.PLAYERS_PLAY_AREA__BUYS_LEFT:
			setBuysLeft((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.PLAYERS_PLAY_AREA__CARDS_PLAYED_THIS_TURN:
			setCards_played_this_turn((CardsPlayedThisTurn) null);
			return;
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_DECK:
			setPlayers_deck((PlayersDeck) null);
			return;
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_HAND:
			setPlayers_hand((PlayersHand) null);
			return;
		case DominionPackage.PLAYERS_PLAY_AREA__DISCARD_PILE:
			setDiscard_pile((DiscardPile) null);
			return;
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_NAME:
			setPlayersName(PLAYERS_NAME_EDEFAULT);
			return;
		case DominionPackage.PLAYERS_PLAY_AREA__ACTIONS_LEFT:
			setActionsLeft(ACTIONS_LEFT_EDEFAULT);
			return;
		case DominionPackage.PLAYERS_PLAY_AREA__BUYS_LEFT:
			setBuysLeft(BUYS_LEFT_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.PLAYERS_PLAY_AREA__CARDS_PLAYED_THIS_TURN:
			return cards_played_this_turn != null;
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_DECK:
			return players_deck != null;
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_HAND:
			return players_hand != null;
		case DominionPackage.PLAYERS_PLAY_AREA__DISCARD_PILE:
			return discard_pile != null;
		case DominionPackage.PLAYERS_PLAY_AREA__PLAYERS_NAME:
			return PLAYERS_NAME_EDEFAULT == null ? playersName != null : !PLAYERS_NAME_EDEFAULT.equals(playersName);
		case DominionPackage.PLAYERS_PLAY_AREA__ACTIONS_LEFT:
			return actionsLeft != ACTIONS_LEFT_EDEFAULT;
		case DominionPackage.PLAYERS_PLAY_AREA__BUYS_LEFT:
			return buysLeft != BUYS_LEFT_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (playersName: ");
		result.append(playersName);
		result.append(", actionsLeft: ");
		result.append(actionsLeft);
		result.append(", buysLeft: ");
		result.append(buysLeft);
		result.append(')');
		return result.toString();
	}

} //PlayersPlayAreaImpl
