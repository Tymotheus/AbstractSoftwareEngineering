/**
 */
package dominion.impl;

import dominion.DominionPackage;
import dominion.Expression;
import dominion.IfAction;
import dominion.PlayersAction;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>If Action</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.IfActionImpl#getCondition <em>Condition</em>}</li>
 *   <li>{@link dominion.impl.IfActionImpl#getConsequent_action <em>Consequent action</em>}</li>
 * </ul>
 *
 * @generated
 */
public class IfActionImpl extends PlayersActionImpl implements IfAction {
	/**
	 * The cached value of the '{@link #getCondition() <em>Condition</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCondition()
	 * @generated
	 * @ordered
	 */
	protected Expression condition;

	/**
	 * The cached value of the '{@link #getConsequent_action() <em>Consequent action</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getConsequent_action()
	 * @generated
	 * @ordered
	 */
	protected PlayersAction consequent_action;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected IfActionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.IF_ACTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Expression getCondition() {
		return condition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCondition(Expression newCondition, NotificationChain msgs) {
		Expression oldCondition = condition;
		condition = newCondition;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.IF_ACTION__CONDITION, oldCondition, newCondition);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCondition(Expression newCondition) {
		if (newCondition != condition) {
			NotificationChain msgs = null;
			if (condition != null)
				msgs = ((InternalEObject) condition).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.IF_ACTION__CONDITION, null, msgs);
			if (newCondition != null)
				msgs = ((InternalEObject) newCondition).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.IF_ACTION__CONDITION, null, msgs);
			msgs = basicSetCondition(newCondition, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.IF_ACTION__CONDITION, newCondition,
					newCondition));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlayersAction getConsequent_action() {
		return consequent_action;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetConsequent_action(PlayersAction newConsequent_action, NotificationChain msgs) {
		PlayersAction oldConsequent_action = consequent_action;
		consequent_action = newConsequent_action;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.IF_ACTION__CONSEQUENT_ACTION, oldConsequent_action, newConsequent_action);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setConsequent_action(PlayersAction newConsequent_action) {
		if (newConsequent_action != consequent_action) {
			NotificationChain msgs = null;
			if (consequent_action != null)
				msgs = ((InternalEObject) consequent_action).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.IF_ACTION__CONSEQUENT_ACTION, null, msgs);
			if (newConsequent_action != null)
				msgs = ((InternalEObject) newConsequent_action).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.IF_ACTION__CONSEQUENT_ACTION, null, msgs);
			msgs = basicSetConsequent_action(newConsequent_action, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.IF_ACTION__CONSEQUENT_ACTION,
					newConsequent_action, newConsequent_action));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DominionPackage.IF_ACTION__CONDITION:
			return basicSetCondition(null, msgs);
		case DominionPackage.IF_ACTION__CONSEQUENT_ACTION:
			return basicSetConsequent_action(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.IF_ACTION__CONDITION:
			return getCondition();
		case DominionPackage.IF_ACTION__CONSEQUENT_ACTION:
			return getConsequent_action();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.IF_ACTION__CONDITION:
			setCondition((Expression) newValue);
			return;
		case DominionPackage.IF_ACTION__CONSEQUENT_ACTION:
			setConsequent_action((PlayersAction) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.IF_ACTION__CONDITION:
			setCondition((Expression) null);
			return;
		case DominionPackage.IF_ACTION__CONSEQUENT_ACTION:
			setConsequent_action((PlayersAction) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.IF_ACTION__CONDITION:
			return condition != null;
		case DominionPackage.IF_ACTION__CONSEQUENT_ACTION:
			return consequent_action != null;
		}
		return super.eIsSet(featureID);
	}

} //IfActionImpl
