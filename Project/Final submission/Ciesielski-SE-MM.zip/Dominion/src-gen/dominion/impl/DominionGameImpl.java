/**
 */
package dominion.impl;

import dominion.Ability;
import dominion.DominionGame;
import dominion.DominionPackage;
import dominion.PlayersPlayArea;
import dominion.PlayersTurn;
import dominion.SupplyPile;
import dominion.TrashPile;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Game</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.DominionGameImpl#getPlayersplayarea <em>Playersplayarea</em>}</li>
 *   <li>{@link dominion.impl.DominionGameImpl#getPlayers_turns <em>Players turns</em>}</li>
 *   <li>{@link dominion.impl.DominionGameImpl#getAvaialble_abilities <em>Avaialble abilities</em>}</li>
 *   <li>{@link dominion.impl.DominionGameImpl#getTrashpile <em>Trashpile</em>}</li>
 *   <li>{@link dominion.impl.DominionGameImpl#getSupply_piles <em>Supply piles</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DominionGameImpl extends MinimalEObjectImpl.Container implements DominionGame {
	/**
	 * The cached value of the '{@link #getPlayersplayarea() <em>Playersplayarea</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlayersplayarea()
	 * @generated
	 * @ordered
	 */
	protected EList<PlayersPlayArea> playersplayarea;

	/**
	 * The cached value of the '{@link #getPlayers_turns() <em>Players turns</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlayers_turns()
	 * @generated
	 * @ordered
	 */
	protected EList<PlayersTurn> players_turns;

	/**
	 * The cached value of the '{@link #getAvaialble_abilities() <em>Avaialble abilities</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAvaialble_abilities()
	 * @generated
	 * @ordered
	 */
	protected EList<Ability> avaialble_abilities;

	/**
	 * The cached value of the '{@link #getTrashpile() <em>Trashpile</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrashpile()
	 * @generated
	 * @ordered
	 */
	protected TrashPile trashpile;

	/**
	 * The cached value of the '{@link #getSupply_piles() <em>Supply piles</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSupply_piles()
	 * @generated
	 * @ordered
	 */
	protected EList<SupplyPile> supply_piles;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DominionGameImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.DOMINION_GAME;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PlayersPlayArea> getPlayersplayarea() {
		if (playersplayarea == null) {
			playersplayarea = new EObjectContainmentEList<PlayersPlayArea>(PlayersPlayArea.class, this,
					DominionPackage.DOMINION_GAME__PLAYERSPLAYAREA);
		}
		return playersplayarea;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PlayersTurn> getPlayers_turns() {
		if (players_turns == null) {
			players_turns = new EObjectContainmentEList<PlayersTurn>(PlayersTurn.class, this,
					DominionPackage.DOMINION_GAME__PLAYERS_TURNS);
		}
		return players_turns;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Ability> getAvaialble_abilities() {
		if (avaialble_abilities == null) {
			avaialble_abilities = new EObjectContainmentEList<Ability>(Ability.class, this,
					DominionPackage.DOMINION_GAME__AVAIALBLE_ABILITIES);
		}
		return avaialble_abilities;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TrashPile getTrashpile() {
		return trashpile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetTrashpile(TrashPile newTrashpile, NotificationChain msgs) {
		TrashPile oldTrashpile = trashpile;
		trashpile = newTrashpile;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.DOMINION_GAME__TRASHPILE, oldTrashpile, newTrashpile);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrashpile(TrashPile newTrashpile) {
		if (newTrashpile != trashpile) {
			NotificationChain msgs = null;
			if (trashpile != null)
				msgs = ((InternalEObject) trashpile).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.DOMINION_GAME__TRASHPILE, null, msgs);
			if (newTrashpile != null)
				msgs = ((InternalEObject) newTrashpile).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.DOMINION_GAME__TRASHPILE, null, msgs);
			msgs = basicSetTrashpile(newTrashpile, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.DOMINION_GAME__TRASHPILE,
					newTrashpile, newTrashpile));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SupplyPile> getSupply_piles() {
		if (supply_piles == null) {
			supply_piles = new EObjectContainmentEList<SupplyPile>(SupplyPile.class, this,
					DominionPackage.DOMINION_GAME__SUPPLY_PILES);
		}
		return supply_piles;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void print() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DominionPackage.DOMINION_GAME__PLAYERSPLAYAREA:
			return ((InternalEList<?>) getPlayersplayarea()).basicRemove(otherEnd, msgs);
		case DominionPackage.DOMINION_GAME__PLAYERS_TURNS:
			return ((InternalEList<?>) getPlayers_turns()).basicRemove(otherEnd, msgs);
		case DominionPackage.DOMINION_GAME__AVAIALBLE_ABILITIES:
			return ((InternalEList<?>) getAvaialble_abilities()).basicRemove(otherEnd, msgs);
		case DominionPackage.DOMINION_GAME__TRASHPILE:
			return basicSetTrashpile(null, msgs);
		case DominionPackage.DOMINION_GAME__SUPPLY_PILES:
			return ((InternalEList<?>) getSupply_piles()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.DOMINION_GAME__PLAYERSPLAYAREA:
			return getPlayersplayarea();
		case DominionPackage.DOMINION_GAME__PLAYERS_TURNS:
			return getPlayers_turns();
		case DominionPackage.DOMINION_GAME__AVAIALBLE_ABILITIES:
			return getAvaialble_abilities();
		case DominionPackage.DOMINION_GAME__TRASHPILE:
			return getTrashpile();
		case DominionPackage.DOMINION_GAME__SUPPLY_PILES:
			return getSupply_piles();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.DOMINION_GAME__PLAYERSPLAYAREA:
			getPlayersplayarea().clear();
			getPlayersplayarea().addAll((Collection<? extends PlayersPlayArea>) newValue);
			return;
		case DominionPackage.DOMINION_GAME__PLAYERS_TURNS:
			getPlayers_turns().clear();
			getPlayers_turns().addAll((Collection<? extends PlayersTurn>) newValue);
			return;
		case DominionPackage.DOMINION_GAME__AVAIALBLE_ABILITIES:
			getAvaialble_abilities().clear();
			getAvaialble_abilities().addAll((Collection<? extends Ability>) newValue);
			return;
		case DominionPackage.DOMINION_GAME__TRASHPILE:
			setTrashpile((TrashPile) newValue);
			return;
		case DominionPackage.DOMINION_GAME__SUPPLY_PILES:
			getSupply_piles().clear();
			getSupply_piles().addAll((Collection<? extends SupplyPile>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.DOMINION_GAME__PLAYERSPLAYAREA:
			getPlayersplayarea().clear();
			return;
		case DominionPackage.DOMINION_GAME__PLAYERS_TURNS:
			getPlayers_turns().clear();
			return;
		case DominionPackage.DOMINION_GAME__AVAIALBLE_ABILITIES:
			getAvaialble_abilities().clear();
			return;
		case DominionPackage.DOMINION_GAME__TRASHPILE:
			setTrashpile((TrashPile) null);
			return;
		case DominionPackage.DOMINION_GAME__SUPPLY_PILES:
			getSupply_piles().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.DOMINION_GAME__PLAYERSPLAYAREA:
			return playersplayarea != null && !playersplayarea.isEmpty();
		case DominionPackage.DOMINION_GAME__PLAYERS_TURNS:
			return players_turns != null && !players_turns.isEmpty();
		case DominionPackage.DOMINION_GAME__AVAIALBLE_ABILITIES:
			return avaialble_abilities != null && !avaialble_abilities.isEmpty();
		case DominionPackage.DOMINION_GAME__TRASHPILE:
			return trashpile != null;
		case DominionPackage.DOMINION_GAME__SUPPLY_PILES:
			return supply_piles != null && !supply_piles.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case DominionPackage.DOMINION_GAME___PRINT:
			print();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

} //DominionGameImpl
