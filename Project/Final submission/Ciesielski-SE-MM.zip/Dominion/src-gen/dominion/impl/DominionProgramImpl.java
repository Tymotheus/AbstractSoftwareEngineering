/**
 */
package dominion.impl;

import dominion.CardLibrary;
import dominion.DominionGame;
import dominion.DominionPackage;
import dominion.DominionProgram;
import dominion.Strategy;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Program</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.DominionProgramImpl#getDominiongame <em>Dominiongame</em>}</li>
 *   <li>{@link dominion.impl.DominionProgramImpl#getCard_libraries <em>Card libraries</em>}</li>
 *   <li>{@link dominion.impl.DominionProgramImpl#getStrategies <em>Strategies</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DominionProgramImpl extends MinimalEObjectImpl.Container implements DominionProgram {
	/**
	 * The cached value of the '{@link #getDominiongame() <em>Dominiongame</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDominiongame()
	 * @generated
	 * @ordered
	 */
	protected DominionGame dominiongame;

	/**
	 * The cached value of the '{@link #getCard_libraries() <em>Card libraries</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCard_libraries()
	 * @generated
	 * @ordered
	 */
	protected EList<CardLibrary> card_libraries;

	/**
	 * The cached value of the '{@link #getStrategies() <em>Strategies</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStrategies()
	 * @generated
	 * @ordered
	 */
	protected EList<Strategy> strategies;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DominionProgramImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.DOMINION_PROGRAM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DominionGame getDominiongame() {
		return dominiongame;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDominiongame(DominionGame newDominiongame, NotificationChain msgs) {
		DominionGame oldDominiongame = dominiongame;
		dominiongame = newDominiongame;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.DOMINION_PROGRAM__DOMINIONGAME, oldDominiongame, newDominiongame);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDominiongame(DominionGame newDominiongame) {
		if (newDominiongame != dominiongame) {
			NotificationChain msgs = null;
			if (dominiongame != null)
				msgs = ((InternalEObject) dominiongame).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.DOMINION_PROGRAM__DOMINIONGAME, null, msgs);
			if (newDominiongame != null)
				msgs = ((InternalEObject) newDominiongame).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.DOMINION_PROGRAM__DOMINIONGAME, null, msgs);
			msgs = basicSetDominiongame(newDominiongame, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.DOMINION_PROGRAM__DOMINIONGAME,
					newDominiongame, newDominiongame));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<CardLibrary> getCard_libraries() {
		if (card_libraries == null) {
			card_libraries = new EObjectContainmentEList<CardLibrary>(CardLibrary.class, this,
					DominionPackage.DOMINION_PROGRAM__CARD_LIBRARIES);
		}
		return card_libraries;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Strategy> getStrategies() {
		if (strategies == null) {
			strategies = new EObjectContainmentEList<Strategy>(Strategy.class, this,
					DominionPackage.DOMINION_PROGRAM__STRATEGIES);
		}
		return strategies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DominionPackage.DOMINION_PROGRAM__DOMINIONGAME:
			return basicSetDominiongame(null, msgs);
		case DominionPackage.DOMINION_PROGRAM__CARD_LIBRARIES:
			return ((InternalEList<?>) getCard_libraries()).basicRemove(otherEnd, msgs);
		case DominionPackage.DOMINION_PROGRAM__STRATEGIES:
			return ((InternalEList<?>) getStrategies()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.DOMINION_PROGRAM__DOMINIONGAME:
			return getDominiongame();
		case DominionPackage.DOMINION_PROGRAM__CARD_LIBRARIES:
			return getCard_libraries();
		case DominionPackage.DOMINION_PROGRAM__STRATEGIES:
			return getStrategies();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.DOMINION_PROGRAM__DOMINIONGAME:
			setDominiongame((DominionGame) newValue);
			return;
		case DominionPackage.DOMINION_PROGRAM__CARD_LIBRARIES:
			getCard_libraries().clear();
			getCard_libraries().addAll((Collection<? extends CardLibrary>) newValue);
			return;
		case DominionPackage.DOMINION_PROGRAM__STRATEGIES:
			getStrategies().clear();
			getStrategies().addAll((Collection<? extends Strategy>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.DOMINION_PROGRAM__DOMINIONGAME:
			setDominiongame((DominionGame) null);
			return;
		case DominionPackage.DOMINION_PROGRAM__CARD_LIBRARIES:
			getCard_libraries().clear();
			return;
		case DominionPackage.DOMINION_PROGRAM__STRATEGIES:
			getStrategies().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.DOMINION_PROGRAM__DOMINIONGAME:
			return dominiongame != null;
		case DominionPackage.DOMINION_PROGRAM__CARD_LIBRARIES:
			return card_libraries != null && !card_libraries.isEmpty();
		case DominionPackage.DOMINION_PROGRAM__STRATEGIES:
			return strategies != null && !strategies.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //DominionProgramImpl
