/**
 */
package dominion.impl;

import dominion.Ability;
import dominion.Card;
import dominion.CardLibrary;
import dominion.DominionPackage;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Card Library</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.CardLibraryImpl#getCard <em>Card</em>}</li>
 *   <li>{@link dominion.impl.CardLibraryImpl#getAbilities <em>Abilities</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CardLibraryImpl extends MinimalEObjectImpl.Container implements CardLibrary {
	/**
	 * The cached value of the '{@link #getCard() <em>Card</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCard()
	 * @generated
	 * @ordered
	 */
	protected EList<Card> card;

	/**
	 * The cached value of the '{@link #getAbilities() <em>Abilities</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAbilities()
	 * @generated
	 * @ordered
	 */
	protected EList<Ability> abilities;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CardLibraryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.CARD_LIBRARY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Card> getCard() {
		if (card == null) {
			card = new EObjectContainmentEList<Card>(Card.class, this, DominionPackage.CARD_LIBRARY__CARD);
		}
		return card;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Ability> getAbilities() {
		if (abilities == null) {
			abilities = new EObjectContainmentEList<Ability>(Ability.class, this,
					DominionPackage.CARD_LIBRARY__ABILITIES);
		}
		return abilities;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DominionPackage.CARD_LIBRARY__CARD:
			return ((InternalEList<?>) getCard()).basicRemove(otherEnd, msgs);
		case DominionPackage.CARD_LIBRARY__ABILITIES:
			return ((InternalEList<?>) getAbilities()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.CARD_LIBRARY__CARD:
			return getCard();
		case DominionPackage.CARD_LIBRARY__ABILITIES:
			return getAbilities();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.CARD_LIBRARY__CARD:
			getCard().clear();
			getCard().addAll((Collection<? extends Card>) newValue);
			return;
		case DominionPackage.CARD_LIBRARY__ABILITIES:
			getAbilities().clear();
			getAbilities().addAll((Collection<? extends Ability>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.CARD_LIBRARY__CARD:
			getCard().clear();
			return;
		case DominionPackage.CARD_LIBRARY__ABILITIES:
			getAbilities().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.CARD_LIBRARY__CARD:
			return card != null && !card.isEmpty();
		case DominionPackage.CARD_LIBRARY__ABILITIES:
			return abilities != null && !abilities.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //CardLibraryImpl
