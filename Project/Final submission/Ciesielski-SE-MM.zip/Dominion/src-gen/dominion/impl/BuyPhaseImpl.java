/**
 */
package dominion.impl;

import dominion.BuyPhase;
import dominion.DominionPackage;
import dominion.PlayersAction;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Buy Phase</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.BuyPhaseImpl#getPlayersactions <em>Playersactions</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BuyPhaseImpl extends MinimalEObjectImpl.Container implements BuyPhase {
	/**
	 * The cached value of the '{@link #getPlayersactions() <em>Playersactions</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlayersactions()
	 * @generated
	 * @ordered
	 */
	protected EList<PlayersAction> playersactions;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BuyPhaseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.BUY_PHASE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PlayersAction> getPlayersactions() {
		if (playersactions == null) {
			playersactions = new EObjectContainmentEList<PlayersAction>(PlayersAction.class, this,
					DominionPackage.BUY_PHASE__PLAYERSACTIONS);
		}
		return playersactions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DominionPackage.BUY_PHASE__PLAYERSACTIONS:
			return ((InternalEList<?>) getPlayersactions()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.BUY_PHASE__PLAYERSACTIONS:
			return getPlayersactions();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.BUY_PHASE__PLAYERSACTIONS:
			getPlayersactions().clear();
			getPlayersactions().addAll((Collection<? extends PlayersAction>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.BUY_PHASE__PLAYERSACTIONS:
			getPlayersactions().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.BUY_PHASE__PLAYERSACTIONS:
			return playersactions != null && !playersactions.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //BuyPhaseImpl
