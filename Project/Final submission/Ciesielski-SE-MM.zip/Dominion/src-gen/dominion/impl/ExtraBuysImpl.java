/**
 */
package dominion.impl;

import dominion.DominionPackage;
import dominion.ExtraBuys;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Extra Buys</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.ExtraBuysImpl#getBuyNumber <em>Buy Number</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ExtraBuysImpl extends AbilityImpl implements ExtraBuys {
	/**
	 * The default value of the '{@link #getBuyNumber() <em>Buy Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuyNumber()
	 * @generated
	 * @ordered
	 */
	protected static final int BUY_NUMBER_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getBuyNumber() <em>Buy Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuyNumber()
	 * @generated
	 * @ordered
	 */
	protected int buyNumber = BUY_NUMBER_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ExtraBuysImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.EXTRA_BUYS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getBuyNumber() {
		return buyNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBuyNumber(int newBuyNumber) {
		int oldBuyNumber = buyNumber;
		buyNumber = newBuyNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.EXTRA_BUYS__BUY_NUMBER, oldBuyNumber,
					buyNumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.EXTRA_BUYS__BUY_NUMBER:
			return getBuyNumber();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.EXTRA_BUYS__BUY_NUMBER:
			setBuyNumber((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.EXTRA_BUYS__BUY_NUMBER:
			setBuyNumber(BUY_NUMBER_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.EXTRA_BUYS__BUY_NUMBER:
			return buyNumber != BUY_NUMBER_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (buyNumber: ");
		result.append(buyNumber);
		result.append(')');
		return result.toString();
	}

} //ExtraBuysImpl
