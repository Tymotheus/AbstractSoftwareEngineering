/**
 */
package dominion.impl;

import dominion.DominionPackage;
import dominion.VictoryCard;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Victory Card</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.VictoryCardImpl#getVictoryPoints <em>Victory Points</em>}</li>
 * </ul>
 *
 * @generated
 */
public class VictoryCardImpl extends CardImpl implements VictoryCard {
	/**
	 * The default value of the '{@link #getVictoryPoints() <em>Victory Points</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVictoryPoints()
	 * @generated
	 * @ordered
	 */
	protected static final int VICTORY_POINTS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getVictoryPoints() <em>Victory Points</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVictoryPoints()
	 * @generated
	 * @ordered
	 */
	protected int victoryPoints = VICTORY_POINTS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VictoryCardImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.VICTORY_CARD;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getVictoryPoints() {
		return victoryPoints;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setVictoryPoints(int newVictoryPoints) {
		int oldVictoryPoints = victoryPoints;
		victoryPoints = newVictoryPoints;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.VICTORY_CARD__VICTORY_POINTS,
					oldVictoryPoints, victoryPoints));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.VICTORY_CARD__VICTORY_POINTS:
			return getVictoryPoints();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.VICTORY_CARD__VICTORY_POINTS:
			setVictoryPoints((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.VICTORY_CARD__VICTORY_POINTS:
			setVictoryPoints(VICTORY_POINTS_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.VICTORY_CARD__VICTORY_POINTS:
			return victoryPoints != VICTORY_POINTS_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (victoryPoints: ");
		result.append(victoryPoints);
		result.append(')');
		return result.toString();
	}

} //VictoryCardImpl
