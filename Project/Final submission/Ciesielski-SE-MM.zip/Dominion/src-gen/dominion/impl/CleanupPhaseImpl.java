/**
 */
package dominion.impl;

import dominion.CleanupPhase;
import dominion.DominionPackage;
import dominion.PutCardFromHandToDiscard;

import java.util.Collection;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Cleanup Phase</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.CleanupPhaseImpl#getPut_cards_from_hand_to_discard <em>Put cards from hand to discard</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CleanupPhaseImpl extends MinimalEObjectImpl.Container implements CleanupPhase {
	/**
	 * The cached value of the '{@link #getPut_cards_from_hand_to_discard() <em>Put cards from hand to discard</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPut_cards_from_hand_to_discard()
	 * @generated
	 * @ordered
	 */
	protected EList<PutCardFromHandToDiscard> put_cards_from_hand_to_discard;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CleanupPhaseImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.CLEANUP_PHASE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<PutCardFromHandToDiscard> getPut_cards_from_hand_to_discard() {
		if (put_cards_from_hand_to_discard == null) {
			put_cards_from_hand_to_discard = new EObjectResolvingEList<PutCardFromHandToDiscard>(
					PutCardFromHandToDiscard.class, this,
					DominionPackage.CLEANUP_PHASE__PUT_CARDS_FROM_HAND_TO_DISCARD);
		}
		return put_cards_from_hand_to_discard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.CLEANUP_PHASE__PUT_CARDS_FROM_HAND_TO_DISCARD:
			return getPut_cards_from_hand_to_discard();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.CLEANUP_PHASE__PUT_CARDS_FROM_HAND_TO_DISCARD:
			getPut_cards_from_hand_to_discard().clear();
			getPut_cards_from_hand_to_discard().addAll((Collection<? extends PutCardFromHandToDiscard>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.CLEANUP_PHASE__PUT_CARDS_FROM_HAND_TO_DISCARD:
			getPut_cards_from_hand_to_discard().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.CLEANUP_PHASE__PUT_CARDS_FROM_HAND_TO_DISCARD:
			return put_cards_from_hand_to_discard != null && !put_cards_from_hand_to_discard.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //CleanupPhaseImpl
