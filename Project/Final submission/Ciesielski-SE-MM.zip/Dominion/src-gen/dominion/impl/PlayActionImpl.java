/**
 */
package dominion.impl;

import dominion.Card;
import dominion.DominionPackage;
import dominion.PlayAction;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Play Action</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.PlayActionImpl#getAction_card <em>Action card</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PlayActionImpl extends PlayersActionImpl implements PlayAction {
	/**
	 * The cached value of the '{@link #getAction_card() <em>Action card</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAction_card()
	 * @generated
	 * @ordered
	 */
	protected Card action_card;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PlayActionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.PLAY_ACTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Card getAction_card() {
		if (action_card != null && action_card.eIsProxy()) {
			InternalEObject oldAction_card = (InternalEObject) action_card;
			action_card = (Card) eResolveProxy(oldAction_card);
			if (action_card != oldAction_card) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, DominionPackage.PLAY_ACTION__ACTION_CARD,
							oldAction_card, action_card));
			}
		}
		return action_card;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Card basicGetAction_card() {
		return action_card;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAction_card(Card newAction_card) {
		Card oldAction_card = action_card;
		action_card = newAction_card;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.PLAY_ACTION__ACTION_CARD,
					oldAction_card, action_card));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.PLAY_ACTION__ACTION_CARD:
			if (resolve)
				return getAction_card();
			return basicGetAction_card();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.PLAY_ACTION__ACTION_CARD:
			setAction_card((Card) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.PLAY_ACTION__ACTION_CARD:
			setAction_card((Card) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.PLAY_ACTION__ACTION_CARD:
			return action_card != null;
		}
		return super.eIsSet(featureID);
	}

} //PlayActionImpl
