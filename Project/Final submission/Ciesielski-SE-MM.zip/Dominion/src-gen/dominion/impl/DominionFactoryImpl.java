/**
 */
package dominion.impl;

import dominion.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class DominionFactoryImpl extends EFactoryImpl implements DominionFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static DominionFactory init() {
		try {
			DominionFactory theDominionFactory = (DominionFactory) EPackage.Registry.INSTANCE
					.getEFactory(DominionPackage.eNS_URI);
			if (theDominionFactory != null) {
				return theDominionFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new DominionFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DominionFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case DominionPackage.PLAYERS_DECK:
			return createPlayersDeck();
		case DominionPackage.TREASURE_CARD:
			return createTreasureCard();
		case DominionPackage.VICTORY_CARD:
			return createVictoryCard();
		case DominionPackage.PLAYERS_HAND:
			return createPlayersHand();
		case DominionPackage.CARD_LIBRARY:
			return createCardLibrary();
		case DominionPackage.PLAYERS_PLAY_AREA:
			return createPlayersPlayArea();
		case DominionPackage.CARDS_PLAYED_THIS_TURN:
			return createCardsPlayedThisTurn();
		case DominionPackage.DISCARD_PILE:
			return createDiscardPile();
		case DominionPackage.PUT_CARD_IN_TRASH:
			return createPutCardInTrash();
		case DominionPackage.DRAW_CARDS:
			return createDrawCards();
		case DominionPackage.ACTION_PHASE:
			return createActionPhase();
		case DominionPackage.BUY_PHASE:
			return createBuyPhase();
		case DominionPackage.CLEANUP_PHASE:
			return createCleanupPhase();
		case DominionPackage.PLAYERS_TURN:
			return createPlayersTurn();
		case DominionPackage.BUY_CARD:
			return createBuyCard();
		case DominionPackage.PUT_CARD_FROM_PILE_TO_DISCARD:
			return createPutCardFromPileToDiscard();
		case DominionPackage.EXTRA_BUYS:
			return createExtraBuys();
		case DominionPackage.EXTRA_COINS:
			return createExtraCoins();
		case DominionPackage.EXTRA_ACTIONS:
			return createExtraActions();
		case DominionPackage.DOMINION_GAME:
			return createDominionGame();
		case DominionPackage.PUT_CARD_FROM_HAND_TO_DISCARD:
			return createPutCardFromHandToDiscard();
		case DominionPackage.STRATEGY:
			return createStrategy();
		case DominionPackage.PLAY_ACTION:
			return createPlayAction();
		case DominionPackage.IF_ACTION:
			return createIfAction();
		case DominionPackage.FITTING_CARD:
			return createFittingCard();
		case DominionPackage.ENOUGH_COINS:
			return createEnoughCoins();
		case DominionPackage.WHILE_ACTION:
			return createWhileAction();
		case DominionPackage.ACTION_CARD:
			return createActionCard();
		case DominionPackage.SUPPLY_PILE:
			return createSupplyPile();
		case DominionPackage.TRASH_PILE:
			return createTrashPile();
		case DominionPackage.DOMINION_PROGRAM:
			return createDominionProgram();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlayersDeck createPlayersDeck() {
		PlayersDeckImpl playersDeck = new PlayersDeckImpl();
		return playersDeck;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TreasureCard createTreasureCard() {
		TreasureCardImpl treasureCard = new TreasureCardImpl();
		return treasureCard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VictoryCard createVictoryCard() {
		VictoryCardImpl victoryCard = new VictoryCardImpl();
		return victoryCard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlayersHand createPlayersHand() {
		PlayersHandImpl playersHand = new PlayersHandImpl();
		return playersHand;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CardLibrary createCardLibrary() {
		CardLibraryImpl cardLibrary = new CardLibraryImpl();
		return cardLibrary;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlayersPlayArea createPlayersPlayArea() {
		PlayersPlayAreaImpl playersPlayArea = new PlayersPlayAreaImpl();
		return playersPlayArea;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CardsPlayedThisTurn createCardsPlayedThisTurn() {
		CardsPlayedThisTurnImpl cardsPlayedThisTurn = new CardsPlayedThisTurnImpl();
		return cardsPlayedThisTurn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DiscardPile createDiscardPile() {
		DiscardPileImpl discardPile = new DiscardPileImpl();
		return discardPile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PutCardInTrash createPutCardInTrash() {
		PutCardInTrashImpl putCardInTrash = new PutCardInTrashImpl();
		return putCardInTrash;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DrawCards createDrawCards() {
		DrawCardsImpl drawCards = new DrawCardsImpl();
		return drawCards;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ActionPhase createActionPhase() {
		ActionPhaseImpl actionPhase = new ActionPhaseImpl();
		return actionPhase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BuyPhase createBuyPhase() {
		BuyPhaseImpl buyPhase = new BuyPhaseImpl();
		return buyPhase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CleanupPhase createCleanupPhase() {
		CleanupPhaseImpl cleanupPhase = new CleanupPhaseImpl();
		return cleanupPhase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlayersTurn createPlayersTurn() {
		PlayersTurnImpl playersTurn = new PlayersTurnImpl();
		return playersTurn;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BuyCard createBuyCard() {
		BuyCardImpl buyCard = new BuyCardImpl();
		return buyCard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PutCardFromPileToDiscard createPutCardFromPileToDiscard() {
		PutCardFromPileToDiscardImpl putCardFromPileToDiscard = new PutCardFromPileToDiscardImpl();
		return putCardFromPileToDiscard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExtraBuys createExtraBuys() {
		ExtraBuysImpl extraBuys = new ExtraBuysImpl();
		return extraBuys;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExtraCoins createExtraCoins() {
		ExtraCoinsImpl extraCoins = new ExtraCoinsImpl();
		return extraCoins;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExtraActions createExtraActions() {
		ExtraActionsImpl extraActions = new ExtraActionsImpl();
		return extraActions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DominionGame createDominionGame() {
		DominionGameImpl dominionGame = new DominionGameImpl();
		return dominionGame;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PutCardFromHandToDiscard createPutCardFromHandToDiscard() {
		PutCardFromHandToDiscardImpl putCardFromHandToDiscard = new PutCardFromHandToDiscardImpl();
		return putCardFromHandToDiscard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Strategy createStrategy() {
		StrategyImpl strategy = new StrategyImpl();
		return strategy;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlayAction createPlayAction() {
		PlayActionImpl playAction = new PlayActionImpl();
		return playAction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public IfAction createIfAction() {
		IfActionImpl ifAction = new IfActionImpl();
		return ifAction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FittingCard createFittingCard() {
		FittingCardImpl fittingCard = new FittingCardImpl();
		return fittingCard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EnoughCoins createEnoughCoins() {
		EnoughCoinsImpl enoughCoins = new EnoughCoinsImpl();
		return enoughCoins;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WhileAction createWhileAction() {
		WhileActionImpl whileAction = new WhileActionImpl();
		return whileAction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ActionCard createActionCard() {
		ActionCardImpl actionCard = new ActionCardImpl();
		return actionCard;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SupplyPile createSupplyPile() {
		SupplyPileImpl supplyPile = new SupplyPileImpl();
		return supplyPile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TrashPile createTrashPile() {
		TrashPileImpl trashPile = new TrashPileImpl();
		return trashPile;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DominionProgram createDominionProgram() {
		DominionProgramImpl dominionProgram = new DominionProgramImpl();
		return dominionProgram;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DominionPackage getDominionPackage() {
		return (DominionPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static DominionPackage getPackage() {
		return DominionPackage.eINSTANCE;
	}

} //DominionFactoryImpl
