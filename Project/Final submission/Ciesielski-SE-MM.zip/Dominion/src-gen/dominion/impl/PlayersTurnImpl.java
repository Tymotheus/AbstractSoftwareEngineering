/**
 */
package dominion.impl;

import dominion.ActionPhase;
import dominion.BuyPhase;
import dominion.CleanupPhase;
import dominion.DominionPackage;
import dominion.PlayersHand;
import dominion.PlayersPlayArea;
import dominion.PlayersTurn;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Players Turn</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link dominion.impl.PlayersTurnImpl#getTurnNumber <em>Turn Number</em>}</li>
 *   <li>{@link dominion.impl.PlayersTurnImpl#getPlayer <em>Player</em>}</li>
 *   <li>{@link dominion.impl.PlayersTurnImpl#getPlayers_hand <em>Players hand</em>}</li>
 *   <li>{@link dominion.impl.PlayersTurnImpl#getAction_phase <em>Action phase</em>}</li>
 *   <li>{@link dominion.impl.PlayersTurnImpl#getBuyphase <em>Buyphase</em>}</li>
 *   <li>{@link dominion.impl.PlayersTurnImpl#getCleanupphase <em>Cleanupphase</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PlayersTurnImpl extends MinimalEObjectImpl.Container implements PlayersTurn {
	/**
	 * The default value of the '{@link #getTurnNumber() <em>Turn Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTurnNumber()
	 * @generated
	 * @ordered
	 */
	protected static final int TURN_NUMBER_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getTurnNumber() <em>Turn Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTurnNumber()
	 * @generated
	 * @ordered
	 */
	protected int turnNumber = TURN_NUMBER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPlayer() <em>Player</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlayer()
	 * @generated
	 * @ordered
	 */
	protected PlayersPlayArea player;

	/**
	 * The cached value of the '{@link #getPlayers_hand() <em>Players hand</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlayers_hand()
	 * @generated
	 * @ordered
	 */
	protected PlayersHand players_hand;

	/**
	 * The cached value of the '{@link #getAction_phase() <em>Action phase</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAction_phase()
	 * @generated
	 * @ordered
	 */
	protected ActionPhase action_phase;

	/**
	 * The cached value of the '{@link #getBuyphase() <em>Buyphase</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuyphase()
	 * @generated
	 * @ordered
	 */
	protected BuyPhase buyphase;

	/**
	 * The cached value of the '{@link #getCleanupphase() <em>Cleanupphase</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCleanupphase()
	 * @generated
	 * @ordered
	 */
	protected CleanupPhase cleanupphase;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PlayersTurnImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DominionPackage.Literals.PLAYERS_TURN;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTurnNumber() {
		return turnNumber;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTurnNumber(int newTurnNumber) {
		int oldTurnNumber = turnNumber;
		turnNumber = newTurnNumber;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.PLAYERS_TURN__TURN_NUMBER,
					oldTurnNumber, turnNumber));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlayersPlayArea getPlayer() {
		if (player != null && player.eIsProxy()) {
			InternalEObject oldPlayer = (InternalEObject) player;
			player = (PlayersPlayArea) eResolveProxy(oldPlayer);
			if (player != oldPlayer) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, DominionPackage.PLAYERS_TURN__PLAYER,
							oldPlayer, player));
			}
		}
		return player;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlayersPlayArea basicGetPlayer() {
		return player;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlayer(PlayersPlayArea newPlayer) {
		PlayersPlayArea oldPlayer = player;
		player = newPlayer;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.PLAYERS_TURN__PLAYER, oldPlayer,
					player));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlayersHand getPlayers_hand() {
		if (players_hand != null && players_hand.eIsProxy()) {
			InternalEObject oldPlayers_hand = (InternalEObject) players_hand;
			players_hand = (PlayersHand) eResolveProxy(oldPlayers_hand);
			if (players_hand != oldPlayers_hand) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							DominionPackage.PLAYERS_TURN__PLAYERS_HAND, oldPlayers_hand, players_hand));
			}
		}
		return players_hand;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PlayersHand basicGetPlayers_hand() {
		return players_hand;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlayers_hand(PlayersHand newPlayers_hand) {
		PlayersHand oldPlayers_hand = players_hand;
		players_hand = newPlayers_hand;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.PLAYERS_TURN__PLAYERS_HAND,
					oldPlayers_hand, players_hand));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ActionPhase getAction_phase() {
		return action_phase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAction_phase(ActionPhase newAction_phase, NotificationChain msgs) {
		ActionPhase oldAction_phase = action_phase;
		action_phase = newAction_phase;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.PLAYERS_TURN__ACTION_PHASE, oldAction_phase, newAction_phase);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAction_phase(ActionPhase newAction_phase) {
		if (newAction_phase != action_phase) {
			NotificationChain msgs = null;
			if (action_phase != null)
				msgs = ((InternalEObject) action_phase).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_TURN__ACTION_PHASE, null, msgs);
			if (newAction_phase != null)
				msgs = ((InternalEObject) newAction_phase).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_TURN__ACTION_PHASE, null, msgs);
			msgs = basicSetAction_phase(newAction_phase, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.PLAYERS_TURN__ACTION_PHASE,
					newAction_phase, newAction_phase));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BuyPhase getBuyphase() {
		return buyphase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetBuyphase(BuyPhase newBuyphase, NotificationChain msgs) {
		BuyPhase oldBuyphase = buyphase;
		buyphase = newBuyphase;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.PLAYERS_TURN__BUYPHASE, oldBuyphase, newBuyphase);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBuyphase(BuyPhase newBuyphase) {
		if (newBuyphase != buyphase) {
			NotificationChain msgs = null;
			if (buyphase != null)
				msgs = ((InternalEObject) buyphase).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_TURN__BUYPHASE, null, msgs);
			if (newBuyphase != null)
				msgs = ((InternalEObject) newBuyphase).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_TURN__BUYPHASE, null, msgs);
			msgs = basicSetBuyphase(newBuyphase, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.PLAYERS_TURN__BUYPHASE, newBuyphase,
					newBuyphase));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CleanupPhase getCleanupphase() {
		return cleanupphase;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCleanupphase(CleanupPhase newCleanupphase, NotificationChain msgs) {
		CleanupPhase oldCleanupphase = cleanupphase;
		cleanupphase = newCleanupphase;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					DominionPackage.PLAYERS_TURN__CLEANUPPHASE, oldCleanupphase, newCleanupphase);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCleanupphase(CleanupPhase newCleanupphase) {
		if (newCleanupphase != cleanupphase) {
			NotificationChain msgs = null;
			if (cleanupphase != null)
				msgs = ((InternalEObject) cleanupphase).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_TURN__CLEANUPPHASE, null, msgs);
			if (newCleanupphase != null)
				msgs = ((InternalEObject) newCleanupphase).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - DominionPackage.PLAYERS_TURN__CLEANUPPHASE, null, msgs);
			msgs = basicSetCleanupphase(newCleanupphase, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, DominionPackage.PLAYERS_TURN__CLEANUPPHASE,
					newCleanupphase, newCleanupphase));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case DominionPackage.PLAYERS_TURN__ACTION_PHASE:
			return basicSetAction_phase(null, msgs);
		case DominionPackage.PLAYERS_TURN__BUYPHASE:
			return basicSetBuyphase(null, msgs);
		case DominionPackage.PLAYERS_TURN__CLEANUPPHASE:
			return basicSetCleanupphase(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case DominionPackage.PLAYERS_TURN__TURN_NUMBER:
			return getTurnNumber();
		case DominionPackage.PLAYERS_TURN__PLAYER:
			if (resolve)
				return getPlayer();
			return basicGetPlayer();
		case DominionPackage.PLAYERS_TURN__PLAYERS_HAND:
			if (resolve)
				return getPlayers_hand();
			return basicGetPlayers_hand();
		case DominionPackage.PLAYERS_TURN__ACTION_PHASE:
			return getAction_phase();
		case DominionPackage.PLAYERS_TURN__BUYPHASE:
			return getBuyphase();
		case DominionPackage.PLAYERS_TURN__CLEANUPPHASE:
			return getCleanupphase();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case DominionPackage.PLAYERS_TURN__TURN_NUMBER:
			setTurnNumber((Integer) newValue);
			return;
		case DominionPackage.PLAYERS_TURN__PLAYER:
			setPlayer((PlayersPlayArea) newValue);
			return;
		case DominionPackage.PLAYERS_TURN__PLAYERS_HAND:
			setPlayers_hand((PlayersHand) newValue);
			return;
		case DominionPackage.PLAYERS_TURN__ACTION_PHASE:
			setAction_phase((ActionPhase) newValue);
			return;
		case DominionPackage.PLAYERS_TURN__BUYPHASE:
			setBuyphase((BuyPhase) newValue);
			return;
		case DominionPackage.PLAYERS_TURN__CLEANUPPHASE:
			setCleanupphase((CleanupPhase) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case DominionPackage.PLAYERS_TURN__TURN_NUMBER:
			setTurnNumber(TURN_NUMBER_EDEFAULT);
			return;
		case DominionPackage.PLAYERS_TURN__PLAYER:
			setPlayer((PlayersPlayArea) null);
			return;
		case DominionPackage.PLAYERS_TURN__PLAYERS_HAND:
			setPlayers_hand((PlayersHand) null);
			return;
		case DominionPackage.PLAYERS_TURN__ACTION_PHASE:
			setAction_phase((ActionPhase) null);
			return;
		case DominionPackage.PLAYERS_TURN__BUYPHASE:
			setBuyphase((BuyPhase) null);
			return;
		case DominionPackage.PLAYERS_TURN__CLEANUPPHASE:
			setCleanupphase((CleanupPhase) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case DominionPackage.PLAYERS_TURN__TURN_NUMBER:
			return turnNumber != TURN_NUMBER_EDEFAULT;
		case DominionPackage.PLAYERS_TURN__PLAYER:
			return player != null;
		case DominionPackage.PLAYERS_TURN__PLAYERS_HAND:
			return players_hand != null;
		case DominionPackage.PLAYERS_TURN__ACTION_PHASE:
			return action_phase != null;
		case DominionPackage.PLAYERS_TURN__BUYPHASE:
			return buyphase != null;
		case DominionPackage.PLAYERS_TURN__CLEANUPPHASE:
			return cleanupphase != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (turnNumber: ");
		result.append(turnNumber);
		result.append(')');
		return result.toString();
	}

} //PlayersTurnImpl
