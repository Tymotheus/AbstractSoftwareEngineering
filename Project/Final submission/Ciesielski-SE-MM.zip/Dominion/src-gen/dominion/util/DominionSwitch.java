/**
 */
package dominion.util;

import dominion.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see dominion.DominionPackage
 * @generated
 */
public class DominionSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static DominionPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DominionSwitch() {
		if (modelPackage == null) {
			modelPackage = DominionPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case DominionPackage.PLAYERS_DECK: {
			PlayersDeck playersDeck = (PlayersDeck) theEObject;
			T result = casePlayersDeck(playersDeck);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.CARD: {
			Card card = (Card) theEObject;
			T result = caseCard(card);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.TREASURE_CARD: {
			TreasureCard treasureCard = (TreasureCard) theEObject;
			T result = caseTreasureCard(treasureCard);
			if (result == null)
				result = caseCard(treasureCard);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.VICTORY_CARD: {
			VictoryCard victoryCard = (VictoryCard) theEObject;
			T result = caseVictoryCard(victoryCard);
			if (result == null)
				result = caseCard(victoryCard);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.PLAYERS_HAND: {
			PlayersHand playersHand = (PlayersHand) theEObject;
			T result = casePlayersHand(playersHand);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.CARD_LIBRARY: {
			CardLibrary cardLibrary = (CardLibrary) theEObject;
			T result = caseCardLibrary(cardLibrary);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.PLAYERS_PLAY_AREA: {
			PlayersPlayArea playersPlayArea = (PlayersPlayArea) theEObject;
			T result = casePlayersPlayArea(playersPlayArea);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.CARDS_PLAYED_THIS_TURN: {
			CardsPlayedThisTurn cardsPlayedThisTurn = (CardsPlayedThisTurn) theEObject;
			T result = caseCardsPlayedThisTurn(cardsPlayedThisTurn);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.DISCARD_PILE: {
			DiscardPile discardPile = (DiscardPile) theEObject;
			T result = caseDiscardPile(discardPile);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.ABILITY: {
			Ability ability = (Ability) theEObject;
			T result = caseAbility(ability);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.PUT_CARD_IN_TRASH: {
			PutCardInTrash putCardInTrash = (PutCardInTrash) theEObject;
			T result = casePutCardInTrash(putCardInTrash);
			if (result == null)
				result = caseAbility(putCardInTrash);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.DRAW_CARDS: {
			DrawCards drawCards = (DrawCards) theEObject;
			T result = caseDrawCards(drawCards);
			if (result == null)
				result = caseAbility(drawCards);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.ACTION_PHASE: {
			ActionPhase actionPhase = (ActionPhase) theEObject;
			T result = caseActionPhase(actionPhase);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.BUY_PHASE: {
			BuyPhase buyPhase = (BuyPhase) theEObject;
			T result = caseBuyPhase(buyPhase);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.CLEANUP_PHASE: {
			CleanupPhase cleanupPhase = (CleanupPhase) theEObject;
			T result = caseCleanupPhase(cleanupPhase);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.PLAYERS_TURN: {
			PlayersTurn playersTurn = (PlayersTurn) theEObject;
			T result = casePlayersTurn(playersTurn);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.BUY_CARD: {
			BuyCard buyCard = (BuyCard) theEObject;
			T result = caseBuyCard(buyCard);
			if (result == null)
				result = casePlayersAction(buyCard);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.PUT_CARD_FROM_PILE_TO_DISCARD: {
			PutCardFromPileToDiscard putCardFromPileToDiscard = (PutCardFromPileToDiscard) theEObject;
			T result = casePutCardFromPileToDiscard(putCardFromPileToDiscard);
			if (result == null)
				result = caseAbility(putCardFromPileToDiscard);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.EXTRA_BUYS: {
			ExtraBuys extraBuys = (ExtraBuys) theEObject;
			T result = caseExtraBuys(extraBuys);
			if (result == null)
				result = caseAbility(extraBuys);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.EXTRA_COINS: {
			ExtraCoins extraCoins = (ExtraCoins) theEObject;
			T result = caseExtraCoins(extraCoins);
			if (result == null)
				result = caseAbility(extraCoins);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.EXTRA_ACTIONS: {
			ExtraActions extraActions = (ExtraActions) theEObject;
			T result = caseExtraActions(extraActions);
			if (result == null)
				result = caseAbility(extraActions);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.DOMINION_GAME: {
			DominionGame dominionGame = (DominionGame) theEObject;
			T result = caseDominionGame(dominionGame);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.PUT_CARD_FROM_HAND_TO_DISCARD: {
			PutCardFromHandToDiscard putCardFromHandToDiscard = (PutCardFromHandToDiscard) theEObject;
			T result = casePutCardFromHandToDiscard(putCardFromHandToDiscard);
			if (result == null)
				result = caseAbility(putCardFromHandToDiscard);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.STRATEGY: {
			Strategy strategy = (Strategy) theEObject;
			T result = caseStrategy(strategy);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.PLAYERS_ACTION: {
			PlayersAction playersAction = (PlayersAction) theEObject;
			T result = casePlayersAction(playersAction);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.PLAY_ACTION: {
			PlayAction playAction = (PlayAction) theEObject;
			T result = casePlayAction(playAction);
			if (result == null)
				result = casePlayersAction(playAction);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.IF_ACTION: {
			IfAction ifAction = (IfAction) theEObject;
			T result = caseIfAction(ifAction);
			if (result == null)
				result = casePlayersAction(ifAction);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.EXPRESSION: {
			Expression expression = (Expression) theEObject;
			T result = caseExpression(expression);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.FITTING_CARD: {
			FittingCard fittingCard = (FittingCard) theEObject;
			T result = caseFittingCard(fittingCard);
			if (result == null)
				result = caseExpression(fittingCard);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.ENOUGH_COINS: {
			EnoughCoins enoughCoins = (EnoughCoins) theEObject;
			T result = caseEnoughCoins(enoughCoins);
			if (result == null)
				result = caseExpression(enoughCoins);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.WHILE_ACTION: {
			WhileAction whileAction = (WhileAction) theEObject;
			T result = caseWhileAction(whileAction);
			if (result == null)
				result = casePlayersAction(whileAction);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.ACTION_CARD: {
			ActionCard actionCard = (ActionCard) theEObject;
			T result = caseActionCard(actionCard);
			if (result == null)
				result = caseCard(actionCard);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.SUPPLY_PILE: {
			SupplyPile supplyPile = (SupplyPile) theEObject;
			T result = caseSupplyPile(supplyPile);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.TRASH_PILE: {
			TrashPile trashPile = (TrashPile) theEObject;
			T result = caseTrashPile(trashPile);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case DominionPackage.DOMINION_PROGRAM: {
			DominionProgram dominionProgram = (DominionProgram) theEObject;
			T result = caseDominionProgram(dominionProgram);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Players Deck</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Players Deck</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePlayersDeck(PlayersDeck object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Card</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Card</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCard(Card object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Treasure Card</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Treasure Card</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTreasureCard(TreasureCard object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Victory Card</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Victory Card</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseVictoryCard(VictoryCard object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Players Hand</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Players Hand</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePlayersHand(PlayersHand object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Card Library</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Card Library</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCardLibrary(CardLibrary object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Players Play Area</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Players Play Area</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePlayersPlayArea(PlayersPlayArea object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Cards Played This Turn</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Cards Played This Turn</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCardsPlayedThisTurn(CardsPlayedThisTurn object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Discard Pile</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Discard Pile</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDiscardPile(DiscardPile object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Ability</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Ability</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAbility(Ability object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Put Card In Trash</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Put Card In Trash</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePutCardInTrash(PutCardInTrash object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Draw Cards</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Draw Cards</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDrawCards(DrawCards object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Action Phase</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Action Phase</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseActionPhase(ActionPhase object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Buy Phase</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Buy Phase</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBuyPhase(BuyPhase object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Cleanup Phase</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Cleanup Phase</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCleanupPhase(CleanupPhase object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Players Turn</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Players Turn</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePlayersTurn(PlayersTurn object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Buy Card</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Buy Card</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBuyCard(BuyCard object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Put Card From Pile To Discard</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Put Card From Pile To Discard</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePutCardFromPileToDiscard(PutCardFromPileToDiscard object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Extra Buys</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Extra Buys</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseExtraBuys(ExtraBuys object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Extra Coins</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Extra Coins</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseExtraCoins(ExtraCoins object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Extra Actions</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Extra Actions</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseExtraActions(ExtraActions object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Game</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Game</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDominionGame(DominionGame object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Put Card From Hand To Discard</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Put Card From Hand To Discard</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePutCardFromHandToDiscard(PutCardFromHandToDiscard object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Strategy</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Strategy</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStrategy(Strategy object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Players Action</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Players Action</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePlayersAction(PlayersAction object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Play Action</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Play Action</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePlayAction(PlayAction object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>If Action</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>If Action</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIfAction(IfAction object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Expression</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Expression</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseExpression(Expression object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Fitting Card</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Fitting Card</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFittingCard(FittingCard object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Enough Coins</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Enough Coins</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEnoughCoins(EnoughCoins object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>While Action</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>While Action</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseWhileAction(WhileAction object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Action Card</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Action Card</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseActionCard(ActionCard object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Supply Pile</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Supply Pile</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSupplyPile(SupplyPile object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Trash Pile</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Trash Pile</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTrashPile(TrashPile object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Program</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Program</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDominionProgram(DominionProgram object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //DominionSwitch
