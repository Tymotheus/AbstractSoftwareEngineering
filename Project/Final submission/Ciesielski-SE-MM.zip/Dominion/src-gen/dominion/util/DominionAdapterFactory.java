/**
 */
package dominion.util;

import dominion.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see dominion.DominionPackage
 * @generated
 */
public class DominionAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static DominionPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public DominionAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = DominionPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DominionSwitch<Adapter> modelSwitch = new DominionSwitch<Adapter>() {
		@Override
		public Adapter casePlayersDeck(PlayersDeck object) {
			return createPlayersDeckAdapter();
		}

		@Override
		public Adapter caseCard(Card object) {
			return createCardAdapter();
		}

		@Override
		public Adapter caseTreasureCard(TreasureCard object) {
			return createTreasureCardAdapter();
		}

		@Override
		public Adapter caseVictoryCard(VictoryCard object) {
			return createVictoryCardAdapter();
		}

		@Override
		public Adapter casePlayersHand(PlayersHand object) {
			return createPlayersHandAdapter();
		}

		@Override
		public Adapter caseCardLibrary(CardLibrary object) {
			return createCardLibraryAdapter();
		}

		@Override
		public Adapter casePlayersPlayArea(PlayersPlayArea object) {
			return createPlayersPlayAreaAdapter();
		}

		@Override
		public Adapter caseCardsPlayedThisTurn(CardsPlayedThisTurn object) {
			return createCardsPlayedThisTurnAdapter();
		}

		@Override
		public Adapter caseDiscardPile(DiscardPile object) {
			return createDiscardPileAdapter();
		}

		@Override
		public Adapter caseAbility(Ability object) {
			return createAbilityAdapter();
		}

		@Override
		public Adapter casePutCardInTrash(PutCardInTrash object) {
			return createPutCardInTrashAdapter();
		}

		@Override
		public Adapter caseDrawCards(DrawCards object) {
			return createDrawCardsAdapter();
		}

		@Override
		public Adapter caseActionPhase(ActionPhase object) {
			return createActionPhaseAdapter();
		}

		@Override
		public Adapter caseBuyPhase(BuyPhase object) {
			return createBuyPhaseAdapter();
		}

		@Override
		public Adapter caseCleanupPhase(CleanupPhase object) {
			return createCleanupPhaseAdapter();
		}

		@Override
		public Adapter casePlayersTurn(PlayersTurn object) {
			return createPlayersTurnAdapter();
		}

		@Override
		public Adapter caseBuyCard(BuyCard object) {
			return createBuyCardAdapter();
		}

		@Override
		public Adapter casePutCardFromPileToDiscard(PutCardFromPileToDiscard object) {
			return createPutCardFromPileToDiscardAdapter();
		}

		@Override
		public Adapter caseExtraBuys(ExtraBuys object) {
			return createExtraBuysAdapter();
		}

		@Override
		public Adapter caseExtraCoins(ExtraCoins object) {
			return createExtraCoinsAdapter();
		}

		@Override
		public Adapter caseExtraActions(ExtraActions object) {
			return createExtraActionsAdapter();
		}

		@Override
		public Adapter caseDominionGame(DominionGame object) {
			return createDominionGameAdapter();
		}

		@Override
		public Adapter casePutCardFromHandToDiscard(PutCardFromHandToDiscard object) {
			return createPutCardFromHandToDiscardAdapter();
		}

		@Override
		public Adapter caseStrategy(Strategy object) {
			return createStrategyAdapter();
		}

		@Override
		public Adapter casePlayersAction(PlayersAction object) {
			return createPlayersActionAdapter();
		}

		@Override
		public Adapter casePlayAction(PlayAction object) {
			return createPlayActionAdapter();
		}

		@Override
		public Adapter caseIfAction(IfAction object) {
			return createIfActionAdapter();
		}

		@Override
		public Adapter caseExpression(Expression object) {
			return createExpressionAdapter();
		}

		@Override
		public Adapter caseFittingCard(FittingCard object) {
			return createFittingCardAdapter();
		}

		@Override
		public Adapter caseEnoughCoins(EnoughCoins object) {
			return createEnoughCoinsAdapter();
		}

		@Override
		public Adapter caseWhileAction(WhileAction object) {
			return createWhileActionAdapter();
		}

		@Override
		public Adapter caseActionCard(ActionCard object) {
			return createActionCardAdapter();
		}

		@Override
		public Adapter caseSupplyPile(SupplyPile object) {
			return createSupplyPileAdapter();
		}

		@Override
		public Adapter caseTrashPile(TrashPile object) {
			return createTrashPileAdapter();
		}

		@Override
		public Adapter caseDominionProgram(DominionProgram object) {
			return createDominionProgramAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.PlayersDeck <em>Players Deck</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.PlayersDeck
	 * @generated
	 */
	public Adapter createPlayersDeckAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.Card <em>Card</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.Card
	 * @generated
	 */
	public Adapter createCardAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.TreasureCard <em>Treasure Card</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.TreasureCard
	 * @generated
	 */
	public Adapter createTreasureCardAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.VictoryCard <em>Victory Card</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.VictoryCard
	 * @generated
	 */
	public Adapter createVictoryCardAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.PlayersHand <em>Players Hand</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.PlayersHand
	 * @generated
	 */
	public Adapter createPlayersHandAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.CardLibrary <em>Card Library</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.CardLibrary
	 * @generated
	 */
	public Adapter createCardLibraryAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.PlayersPlayArea <em>Players Play Area</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.PlayersPlayArea
	 * @generated
	 */
	public Adapter createPlayersPlayAreaAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.CardsPlayedThisTurn <em>Cards Played This Turn</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.CardsPlayedThisTurn
	 * @generated
	 */
	public Adapter createCardsPlayedThisTurnAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.DiscardPile <em>Discard Pile</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.DiscardPile
	 * @generated
	 */
	public Adapter createDiscardPileAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.Ability <em>Ability</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.Ability
	 * @generated
	 */
	public Adapter createAbilityAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.PutCardInTrash <em>Put Card In Trash</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.PutCardInTrash
	 * @generated
	 */
	public Adapter createPutCardInTrashAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.DrawCards <em>Draw Cards</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.DrawCards
	 * @generated
	 */
	public Adapter createDrawCardsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.ActionPhase <em>Action Phase</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.ActionPhase
	 * @generated
	 */
	public Adapter createActionPhaseAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.BuyPhase <em>Buy Phase</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.BuyPhase
	 * @generated
	 */
	public Adapter createBuyPhaseAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.CleanupPhase <em>Cleanup Phase</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.CleanupPhase
	 * @generated
	 */
	public Adapter createCleanupPhaseAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.PlayersTurn <em>Players Turn</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.PlayersTurn
	 * @generated
	 */
	public Adapter createPlayersTurnAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.BuyCard <em>Buy Card</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.BuyCard
	 * @generated
	 */
	public Adapter createBuyCardAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.PutCardFromPileToDiscard <em>Put Card From Pile To Discard</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.PutCardFromPileToDiscard
	 * @generated
	 */
	public Adapter createPutCardFromPileToDiscardAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.ExtraBuys <em>Extra Buys</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.ExtraBuys
	 * @generated
	 */
	public Adapter createExtraBuysAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.ExtraCoins <em>Extra Coins</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.ExtraCoins
	 * @generated
	 */
	public Adapter createExtraCoinsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.ExtraActions <em>Extra Actions</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.ExtraActions
	 * @generated
	 */
	public Adapter createExtraActionsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.DominionGame <em>Game</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.DominionGame
	 * @generated
	 */
	public Adapter createDominionGameAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.PutCardFromHandToDiscard <em>Put Card From Hand To Discard</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.PutCardFromHandToDiscard
	 * @generated
	 */
	public Adapter createPutCardFromHandToDiscardAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.Strategy <em>Strategy</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.Strategy
	 * @generated
	 */
	public Adapter createStrategyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.PlayersAction <em>Players Action</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.PlayersAction
	 * @generated
	 */
	public Adapter createPlayersActionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.PlayAction <em>Play Action</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.PlayAction
	 * @generated
	 */
	public Adapter createPlayActionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.IfAction <em>If Action</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.IfAction
	 * @generated
	 */
	public Adapter createIfActionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.Expression <em>Expression</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.Expression
	 * @generated
	 */
	public Adapter createExpressionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.FittingCard <em>Fitting Card</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.FittingCard
	 * @generated
	 */
	public Adapter createFittingCardAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.EnoughCoins <em>Enough Coins</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.EnoughCoins
	 * @generated
	 */
	public Adapter createEnoughCoinsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.WhileAction <em>While Action</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.WhileAction
	 * @generated
	 */
	public Adapter createWhileActionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.ActionCard <em>Action Card</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.ActionCard
	 * @generated
	 */
	public Adapter createActionCardAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.SupplyPile <em>Supply Pile</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.SupplyPile
	 * @generated
	 */
	public Adapter createSupplyPileAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.TrashPile <em>Trash Pile</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.TrashPile
	 * @generated
	 */
	public Adapter createTrashPileAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link dominion.DominionProgram <em>Program</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see dominion.DominionProgram
	 * @generated
	 */
	public Adapter createDominionProgramAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //DominionAdapterFactory
