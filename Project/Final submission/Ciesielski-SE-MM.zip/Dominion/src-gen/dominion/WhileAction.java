/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>While Action</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.WhileAction#getCondition <em>Condition</em>}</li>
 *   <li>{@link dominion.WhileAction#getPlayersaction <em>Playersaction</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getWhileAction()
 * @model
 * @generated
 */
public interface WhileAction extends PlayersAction {
	/**
	 * Returns the value of the '<em><b>Condition</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Condition</em>' containment reference.
	 * @see #setCondition(Expression)
	 * @see dominion.DominionPackage#getWhileAction_Condition()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Expression getCondition();

	/**
	 * Sets the value of the '{@link dominion.WhileAction#getCondition <em>Condition</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Condition</em>' containment reference.
	 * @see #getCondition()
	 * @generated
	 */
	void setCondition(Expression value);

	/**
	 * Returns the value of the '<em><b>Playersaction</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Playersaction</em>' containment reference.
	 * @see #setPlayersaction(PlayersAction)
	 * @see dominion.DominionPackage#getWhileAction_Playersaction()
	 * @model containment="true" required="true"
	 * @generated
	 */
	PlayersAction getPlayersaction();

	/**
	 * Sets the value of the '{@link dominion.WhileAction#getPlayersaction <em>Playersaction</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Playersaction</em>' containment reference.
	 * @see #getPlayersaction()
	 * @generated
	 */
	void setPlayersaction(PlayersAction value);

} // WhileAction
