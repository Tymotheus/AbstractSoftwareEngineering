/**
 */
package dominion;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Players Action</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dominion.DominionPackage#getPlayersAction()
 * @model abstract="true"
 * @generated
 */
public interface PlayersAction extends EObject {
} // PlayersAction
