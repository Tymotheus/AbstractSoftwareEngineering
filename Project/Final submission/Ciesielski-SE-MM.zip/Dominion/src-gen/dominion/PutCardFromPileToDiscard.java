/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Put Card From Pile To Discard</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.PutCardFromPileToDiscard#getDiscard_pile <em>Discard pile</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getPutCardFromPileToDiscard()
 * @model
 * @generated
 */
public interface PutCardFromPileToDiscard extends Ability {
	/**
	 * Returns the value of the '<em><b>Discard pile</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Discard pile</em>' reference.
	 * @see #setDiscard_pile(DiscardPile)
	 * @see dominion.DominionPackage#getPutCardFromPileToDiscard_Discard_pile()
	 * @model required="true"
	 * @generated
	 */
	DiscardPile getDiscard_pile();

	/**
	 * Sets the value of the '{@link dominion.PutCardFromPileToDiscard#getDiscard_pile <em>Discard pile</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Discard pile</em>' reference.
	 * @see #getDiscard_pile()
	 * @generated
	 */
	void setDiscard_pile(DiscardPile value);

} // PutCardFromPileToDiscard
