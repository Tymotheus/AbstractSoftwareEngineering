/**
 */
package dominion;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see dominion.DominionPackage
 * @generated
 */
public interface DominionFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DominionFactory eINSTANCE = dominion.impl.DominionFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Players Deck</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Players Deck</em>'.
	 * @generated
	 */
	PlayersDeck createPlayersDeck();

	/**
	 * Returns a new object of class '<em>Treasure Card</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Treasure Card</em>'.
	 * @generated
	 */
	TreasureCard createTreasureCard();

	/**
	 * Returns a new object of class '<em>Victory Card</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Victory Card</em>'.
	 * @generated
	 */
	VictoryCard createVictoryCard();

	/**
	 * Returns a new object of class '<em>Players Hand</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Players Hand</em>'.
	 * @generated
	 */
	PlayersHand createPlayersHand();

	/**
	 * Returns a new object of class '<em>Card Library</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Card Library</em>'.
	 * @generated
	 */
	CardLibrary createCardLibrary();

	/**
	 * Returns a new object of class '<em>Players Play Area</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Players Play Area</em>'.
	 * @generated
	 */
	PlayersPlayArea createPlayersPlayArea();

	/**
	 * Returns a new object of class '<em>Cards Played This Turn</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Cards Played This Turn</em>'.
	 * @generated
	 */
	CardsPlayedThisTurn createCardsPlayedThisTurn();

	/**
	 * Returns a new object of class '<em>Discard Pile</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Discard Pile</em>'.
	 * @generated
	 */
	DiscardPile createDiscardPile();

	/**
	 * Returns a new object of class '<em>Put Card In Trash</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Put Card In Trash</em>'.
	 * @generated
	 */
	PutCardInTrash createPutCardInTrash();

	/**
	 * Returns a new object of class '<em>Draw Cards</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Draw Cards</em>'.
	 * @generated
	 */
	DrawCards createDrawCards();

	/**
	 * Returns a new object of class '<em>Action Phase</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Action Phase</em>'.
	 * @generated
	 */
	ActionPhase createActionPhase();

	/**
	 * Returns a new object of class '<em>Buy Phase</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Buy Phase</em>'.
	 * @generated
	 */
	BuyPhase createBuyPhase();

	/**
	 * Returns a new object of class '<em>Cleanup Phase</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Cleanup Phase</em>'.
	 * @generated
	 */
	CleanupPhase createCleanupPhase();

	/**
	 * Returns a new object of class '<em>Players Turn</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Players Turn</em>'.
	 * @generated
	 */
	PlayersTurn createPlayersTurn();

	/**
	 * Returns a new object of class '<em>Buy Card</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Buy Card</em>'.
	 * @generated
	 */
	BuyCard createBuyCard();

	/**
	 * Returns a new object of class '<em>Put Card From Pile To Discard</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Put Card From Pile To Discard</em>'.
	 * @generated
	 */
	PutCardFromPileToDiscard createPutCardFromPileToDiscard();

	/**
	 * Returns a new object of class '<em>Extra Buys</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Extra Buys</em>'.
	 * @generated
	 */
	ExtraBuys createExtraBuys();

	/**
	 * Returns a new object of class '<em>Extra Coins</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Extra Coins</em>'.
	 * @generated
	 */
	ExtraCoins createExtraCoins();

	/**
	 * Returns a new object of class '<em>Extra Actions</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Extra Actions</em>'.
	 * @generated
	 */
	ExtraActions createExtraActions();

	/**
	 * Returns a new object of class '<em>Game</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Game</em>'.
	 * @generated
	 */
	DominionGame createDominionGame();

	/**
	 * Returns a new object of class '<em>Put Card From Hand To Discard</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Put Card From Hand To Discard</em>'.
	 * @generated
	 */
	PutCardFromHandToDiscard createPutCardFromHandToDiscard();

	/**
	 * Returns a new object of class '<em>Strategy</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Strategy</em>'.
	 * @generated
	 */
	Strategy createStrategy();

	/**
	 * Returns a new object of class '<em>Play Action</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Play Action</em>'.
	 * @generated
	 */
	PlayAction createPlayAction();

	/**
	 * Returns a new object of class '<em>If Action</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>If Action</em>'.
	 * @generated
	 */
	IfAction createIfAction();

	/**
	 * Returns a new object of class '<em>Fitting Card</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fitting Card</em>'.
	 * @generated
	 */
	FittingCard createFittingCard();

	/**
	 * Returns a new object of class '<em>Enough Coins</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Enough Coins</em>'.
	 * @generated
	 */
	EnoughCoins createEnoughCoins();

	/**
	 * Returns a new object of class '<em>While Action</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>While Action</em>'.
	 * @generated
	 */
	WhileAction createWhileAction();

	/**
	 * Returns a new object of class '<em>Action Card</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Action Card</em>'.
	 * @generated
	 */
	ActionCard createActionCard();

	/**
	 * Returns a new object of class '<em>Supply Pile</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Supply Pile</em>'.
	 * @generated
	 */
	SupplyPile createSupplyPile();

	/**
	 * Returns a new object of class '<em>Trash Pile</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Trash Pile</em>'.
	 * @generated
	 */
	TrashPile createTrashPile();

	/**
	 * Returns a new object of class '<em>Program</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Program</em>'.
	 * @generated
	 */
	DominionProgram createDominionProgram();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	DominionPackage getDominionPackage();

} //DominionFactory
