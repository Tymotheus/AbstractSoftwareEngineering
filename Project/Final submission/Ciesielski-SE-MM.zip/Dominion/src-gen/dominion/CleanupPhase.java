/**
 */
package dominion;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Cleanup Phase</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.CleanupPhase#getPut_cards_from_hand_to_discard <em>Put cards from hand to discard</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getCleanupPhase()
 * @model
 * @generated
 */
public interface CleanupPhase extends EObject {
	/**
	 * Returns the value of the '<em><b>Put cards from hand to discard</b></em>' reference list.
	 * The list contents are of type {@link dominion.PutCardFromHandToDiscard}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Put cards from hand to discard</em>' reference list.
	 * @see dominion.DominionPackage#getCleanupPhase_Put_cards_from_hand_to_discard()
	 * @model
	 * @generated
	 */
	EList<PutCardFromHandToDiscard> getPut_cards_from_hand_to_discard();

} // CleanupPhase
