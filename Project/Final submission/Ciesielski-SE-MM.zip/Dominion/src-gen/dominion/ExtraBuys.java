/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Extra Buys</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.ExtraBuys#getBuyNumber <em>Buy Number</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getExtraBuys()
 * @model
 * @generated
 */
public interface ExtraBuys extends Ability {
	/**
	 * Returns the value of the '<em><b>Buy Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Buy Number</em>' attribute.
	 * @see #setBuyNumber(int)
	 * @see dominion.DominionPackage#getExtraBuys_BuyNumber()
	 * @model required="true"
	 * @generated
	 */
	int getBuyNumber();

	/**
	 * Sets the value of the '{@link dominion.ExtraBuys#getBuyNumber <em>Buy Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Buy Number</em>' attribute.
	 * @see #getBuyNumber()
	 * @generated
	 */
	void setBuyNumber(int value);

} // ExtraBuys
