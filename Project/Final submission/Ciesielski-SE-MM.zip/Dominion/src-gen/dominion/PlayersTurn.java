/**
 */
package dominion;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Players Turn</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.PlayersTurn#getTurnNumber <em>Turn Number</em>}</li>
 *   <li>{@link dominion.PlayersTurn#getPlayer <em>Player</em>}</li>
 *   <li>{@link dominion.PlayersTurn#getPlayers_hand <em>Players hand</em>}</li>
 *   <li>{@link dominion.PlayersTurn#getAction_phase <em>Action phase</em>}</li>
 *   <li>{@link dominion.PlayersTurn#getBuyphase <em>Buyphase</em>}</li>
 *   <li>{@link dominion.PlayersTurn#getCleanupphase <em>Cleanupphase</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getPlayersTurn()
 * @model
 * @generated
 */
public interface PlayersTurn extends EObject {
	/**
	 * Returns the value of the '<em><b>Turn Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Turn Number</em>' attribute.
	 * @see #setTurnNumber(int)
	 * @see dominion.DominionPackage#getPlayersTurn_TurnNumber()
	 * @model
	 * @generated
	 */
	int getTurnNumber();

	/**
	 * Sets the value of the '{@link dominion.PlayersTurn#getTurnNumber <em>Turn Number</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Turn Number</em>' attribute.
	 * @see #getTurnNumber()
	 * @generated
	 */
	void setTurnNumber(int value);

	/**
	 * Returns the value of the '<em><b>Player</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Player</em>' reference.
	 * @see #setPlayer(PlayersPlayArea)
	 * @see dominion.DominionPackage#getPlayersTurn_Player()
	 * @model required="true"
	 * @generated
	 */
	PlayersPlayArea getPlayer();

	/**
	 * Sets the value of the '{@link dominion.PlayersTurn#getPlayer <em>Player</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Player</em>' reference.
	 * @see #getPlayer()
	 * @generated
	 */
	void setPlayer(PlayersPlayArea value);

	/**
	 * Returns the value of the '<em><b>Players hand</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Players hand</em>' reference.
	 * @see #setPlayers_hand(PlayersHand)
	 * @see dominion.DominionPackage#getPlayersTurn_Players_hand()
	 * @model required="true"
	 * @generated
	 */
	PlayersHand getPlayers_hand();

	/**
	 * Sets the value of the '{@link dominion.PlayersTurn#getPlayers_hand <em>Players hand</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Players hand</em>' reference.
	 * @see #getPlayers_hand()
	 * @generated
	 */
	void setPlayers_hand(PlayersHand value);

	/**
	 * Returns the value of the '<em><b>Action phase</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Action phase</em>' containment reference.
	 * @see #setAction_phase(ActionPhase)
	 * @see dominion.DominionPackage#getPlayersTurn_Action_phase()
	 * @model containment="true" required="true"
	 * @generated
	 */
	ActionPhase getAction_phase();

	/**
	 * Sets the value of the '{@link dominion.PlayersTurn#getAction_phase <em>Action phase</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Action phase</em>' containment reference.
	 * @see #getAction_phase()
	 * @generated
	 */
	void setAction_phase(ActionPhase value);

	/**
	 * Returns the value of the '<em><b>Buyphase</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Buyphase</em>' containment reference.
	 * @see #setBuyphase(BuyPhase)
	 * @see dominion.DominionPackage#getPlayersTurn_Buyphase()
	 * @model containment="true" required="true"
	 * @generated
	 */
	BuyPhase getBuyphase();

	/**
	 * Sets the value of the '{@link dominion.PlayersTurn#getBuyphase <em>Buyphase</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Buyphase</em>' containment reference.
	 * @see #getBuyphase()
	 * @generated
	 */
	void setBuyphase(BuyPhase value);

	/**
	 * Returns the value of the '<em><b>Cleanupphase</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cleanupphase</em>' containment reference.
	 * @see #setCleanupphase(CleanupPhase)
	 * @see dominion.DominionPackage#getPlayersTurn_Cleanupphase()
	 * @model containment="true" required="true"
	 * @generated
	 */
	CleanupPhase getCleanupphase();

	/**
	 * Sets the value of the '{@link dominion.PlayersTurn#getCleanupphase <em>Cleanupphase</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cleanupphase</em>' containment reference.
	 * @see #getCleanupphase()
	 * @generated
	 */
	void setCleanupphase(CleanupPhase value);

} // PlayersTurn
