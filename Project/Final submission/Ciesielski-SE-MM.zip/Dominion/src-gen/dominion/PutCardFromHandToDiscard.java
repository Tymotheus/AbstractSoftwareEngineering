/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Put Card From Hand To Discard</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see dominion.DominionPackage#getPutCardFromHandToDiscard()
 * @model
 * @generated
 */
public interface PutCardFromHandToDiscard extends Ability {
} // PutCardFromHandToDiscard
