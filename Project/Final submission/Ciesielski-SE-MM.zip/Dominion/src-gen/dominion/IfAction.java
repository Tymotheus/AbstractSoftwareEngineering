/**
 */
package dominion;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>If Action</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link dominion.IfAction#getCondition <em>Condition</em>}</li>
 *   <li>{@link dominion.IfAction#getConsequent_action <em>Consequent action</em>}</li>
 * </ul>
 *
 * @see dominion.DominionPackage#getIfAction()
 * @model
 * @generated
 */
public interface IfAction extends PlayersAction {
	/**
	 * Returns the value of the '<em><b>Condition</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Condition</em>' containment reference.
	 * @see #setCondition(Expression)
	 * @see dominion.DominionPackage#getIfAction_Condition()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Expression getCondition();

	/**
	 * Sets the value of the '{@link dominion.IfAction#getCondition <em>Condition</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Condition</em>' containment reference.
	 * @see #getCondition()
	 * @generated
	 */
	void setCondition(Expression value);

	/**
	 * Returns the value of the '<em><b>Consequent action</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Consequent action</em>' containment reference.
	 * @see #setConsequent_action(PlayersAction)
	 * @see dominion.DominionPackage#getIfAction_Consequent_action()
	 * @model containment="true" required="true"
	 * @generated
	 */
	PlayersAction getConsequent_action();

	/**
	 * Sets the value of the '{@link dominion.IfAction#getConsequent_action <em>Consequent action</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Consequent action</em>' containment reference.
	 * @see #getConsequent_action()
	 * @generated
	 */
	void setConsequent_action(PlayersAction value);

} // IfAction
